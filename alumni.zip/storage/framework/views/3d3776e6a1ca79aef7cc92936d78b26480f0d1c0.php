

<?php $__env->startSection('title', 'Les enseignants du CPET DON BOSCO '.config('app.site')); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>

    <section class="breadcrumb-section">
        <div class="container">
            <h1>Nos enseignants</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('Index')); ?>">Accueil</a></li>
                <li class="breadcrumb-item">Nos enseignants</li>
            </ol>
        </div><!-- /.container -->
    </section> 
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="sg-page-content">         
    <div class="sa-section">
        <div class="section-content section-padding_ py-5 mt-2">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="row">
                            <?php if(isset($datas)): ?>
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <div class="col-md-4 p-1 mb-3">
                                    <div class="row border mx-1 rounded-3 shadow-sm mb-2">
                                        <div class="col-12 col-sm-12 px-0">
                                            <div class="sa-courses card_membre ">                             
                                                <div class="entry-thumbnail px-0">
                                                    <a href="<?php echo e(route('enseignant',$d['id'])); ?>"> 
                                                        <?php if($d['photo'] && $d['photo']!=""): ?>
                                                        <img src="<?php echo e(asset($d['photo'])); ?>" alt="<?php echo e($d['titre']); ?>" class="img-fluid ">
                                                        <?php else: ?>
                                                        <img src="<?php echo e(asset('assets/images/cpet/actualite-default.jpg')); ?>" alt="<?php echo e($d['titre']); ?>" class="img-fluid">
                                                        <?php endif; ?>
                                                        </a>
                                                </div>
                                                <div class="course-info_ px-2 py-3">
                                                    <a href="<?php echo e(route('enseignant',$d['id'])); ?>">
                                                    <div class="info text-center">
                                                        <?php if(isset($d->site)): ?>                                                
                                                        <span class="badgebg-secondary rounded-pill fs-xs fw-semibold text-lowercase">SITE DE <?php echo e($d->site); ?></span>   <br-->
                                                        <?php endif; ?>
                                                        <h5 class="title fs-sm mt-0 mb-0"><a href="<?php echo e(route('enseignant',($d->slug!="")?$d->slug:$d->id)); ?>"><?php echo e($d->nom.' '.$d->prenom); ?></a></h5>
                                                        <small><b>Spécialité:</b> <?php echo e($d->specialite); ?></small>
                                                       <small class="text-muted">
                                                           <?php echo e(substr(strip_tags($d->contenu),0,100)); ?>

                                                       </small>
                                                    </div>
                                                    </a>
                                                </div><!-- /.course-info -->
                                            </div><!-- /.sg-course -->                                      
                                        </div>
                                    </div>
                                    </div>                               
                                   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                
                            </div><!-- /.row --> 

                        <div class="sg-pagination text-center">
                            <?php echo e($datas->links()); ?>

                        </div>                                                                 
                    </div>
                    <div class="col-lg-4">
                        <?php echo $__env->make('includes.right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div><!-- /.row -->                     
            </div><!-- /.container -->
        </div><!-- /.section-content -->
    </div><!-- /.sa-section -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cfpsdonboscobenin\resources\views/web/enseignants.blade.php ENDPATH**/ ?>