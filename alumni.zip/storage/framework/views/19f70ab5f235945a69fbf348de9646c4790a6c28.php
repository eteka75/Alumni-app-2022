

<?php $__env->startSection('title', 'Les Communiqués'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>

    <section class="breadcrumb-section">
        <div class="container">
            <h1>Communiqués</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('Index')); ?>">Accueil</a></li>
                <li class="breadcrumb-item">Communiqués</li>
            </ol>
        </div><!-- /.container -->
    </section> 
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="sg-page-content">         
    <div class="sa-section">
        <div class="section-content section-padding_ py-5 mt-2">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="row">
                            <?php if(isset($datas)): ?>
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <div class="col-md-6 ">
                                    <div class="row border mx-1 h-100 rounded-3 shadow-sm mb-2">
                                        <div class="col-12 col-sm-12">
                                            <div class="sa-courses">                             
                
                                                <div class="course-info_ px-2 py-3">
                                                    <div class="info">
                                                        
                                                        <h5 class="title fs-sm my-0"><a href="<?php echo e(route('categorie',($d->slug!="")?$d->slug:$d->id)); ?>"><?php echo e($d->nom); ?></a></h5>
                                                       <small class="text-muted">
                                                           <?php echo e(substr(strip_tags($d->description),0,100)); ?>

                                                           
                                                       </small>
                                                    </div>
                                                </div><!-- /.course-info -->
                                            </div><!-- /.sg-course -->                                      
                                        </div>
                                    </div>
                                    </div>                               
                                   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                
                            </div><!-- /.row --> 

                        <div class="sg-pagination text-center">
                            <?php echo e($datas->links()); ?>

                        </div>                                                                 
                    </div>
                    <div class="col-lg-4">
                        <?php echo $__env->make('includes.right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div><!-- /.row -->                     
            </div><!-- /.container -->
        </div><!-- /.section-content -->
    </div><!-- /.sa-section -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cfpsdonboscobenin\resources\views/web/categories.blade.php ENDPATH**/ ?>