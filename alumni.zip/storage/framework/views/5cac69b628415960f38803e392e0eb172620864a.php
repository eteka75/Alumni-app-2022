

<?php $__env->startSection('title', 'Galerie Images du CPET DON BOSCO '.config('app.site')); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>

    <section class="breadcrumb-section">
        <div class="container">
            <h1>Galerie Images</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('Index')); ?>">Accueil</a></li>
                <li class="breadcrumb-item">Galerie Images</li>
            </ol>
        </div><!-- /.container -->
    </section>    
    <?php $__env->startSection('scripts'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/storage/vendor/lightbox/css/lightbox.css')); ?>">
    
    <script src="<?php echo e(asset('/storage/vendor/lightbox/js/lightbox.js')); ?>"></script>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>

    <div class="sg-section">
        <div class="section-content course-details bg-white section-padding_ py-4">
            <div class="container">
                <div class="row p-3">
                <div class="col-md-8  col-12 col-xl-8">
                    <div class="row ">
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($d->image && $d->image!=""): ?>
                        <div class="col-12  col-sm-4 px-0 col-lg-3  mb-1">
                            <div class="course-thumb">
                                
                                <a href="<?php echo e(asset($d->image)); ?>" data-lightbox="image-1" data-title="<?php echo e($d->titre .'-'.$d->description); ?>"> 
                                    <img src="<?php echo e(asset($d->image)); ?>" alt="<?php echo e($d->titre); ?>" class="img-fluid mx-1">
                                </a>
                            </div><!-- /.course-thumb -->
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="sg-pagination float-end  px-1 ">
                        <?php echo e($datas->links()); ?>

                    </div> 
                </div>
                <div class="col-lg-4">
                    
                    <?php echo $__env->make('includes.right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                 </div>
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.section-content -->
    </div>
    <?php $__env->stopSection(); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cfpsdonboscobenin\resources\views/web/galerie-images.blade.php ENDPATH**/ ?>