

<?php $__env->startSection('title', 'Site de Parakou'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>

    <section class="breadcrumb-section">
        <div class="container">
            <h1>CFPS DON BOSCO PARAKOU</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('Index')); ?>">Accueil</a></li>
                <li class="breadcrumb-item">Site de Parakou</li>
            </ol>
        </div><!-- /.container -->
    </section> 
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cfpsdonboscobenin\resources\views/web/parakou.blade.php ENDPATH**/ ?>