

<?php $__env->startSection('title', 'Profil et Formation'); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-white">
        <div class="container">
            <!-- Related posts carousel -->

            <div class="row justify-content-center_">
                <div class="col-md-12">
                    <div class="card border-0  _box-shadow">
                        <div class="card-body ">

                            <div class="row ">
                                <div class="col-lg-3 col-sm-6 mb-4">
                                    <div class="media align-items-center ">
                                        <div class="bg-secondary rounded-circle border text-center"
                                            style="width: 60px; height: 60px; line-height: 54px;"><i
                                                class="fe-user-check font-size-xl text-muted"></i></div>
                                        <div class="media-body pl-3"><span class="badge badge-success badge-pill mb-1"><i
                                                    class="fe-check mr-1"></i>Effectué</span>
                                            <h6 class="text-muted mb-0">Création de compte</h6>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6">
                                    <div class="media align-items-center mb-4">
                                        <div class="rounded-circle border border-primary text-center"
                                            style="width: 60px; height: 60px; line-height: 54px;"><i
                                                class="fe-list font-size-xl text-primary_"></i></div>
                                        <div class="media-body pl-3">
                                            <span class="badge badge-success badge-pill mb-1"><i
                                                class="fe-check mr-1"></i>Effectué</span>
                                            <h6 class=" mb-0">Profil et Formation</h6>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6">
                                    <div class="media align-items-center mb-4">
                                        <div class="rounded-circle border text-center"
                                            style="width: 60px; height: 60px; line-height: 54px;"><i
                                                class="fe-star font-size-xl"></i></div>
                                        <div class="media-body pl-3"><span class="badge badge-primary badge-pill mb-1">En
                                            cours</span>
                                            <h6 class="mb-0 text-primary">Profession</h6>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6">
                                    <div class="media align-items-center mb-4">
                                        <div class="rounded-circle border text-center"
                                            style="width: 60px; height: 60px; line-height: 54px;"><i
                                                class="fe-package font-size-xl"></i></div>
                                        <div class="media-body pl-3"><span
                                                class="d-block text-muted font-size-ms mb-1">Quatrième étape</span>
                                            <h6 class="mb-0">Paramètres du compte</h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
              
                        </div>
                    </div>
                </div>
                <div class="col-md-10 col-xl-8  p-sm-4 py-sm-5 mb-5 rounded  shadow-sm col-12 mx-auto ">
                    <div class="card_p-5 box-shadowrounded mb-5">

                        <div class=" px-4">
                            <div class="text-center mb-4">
                                <h3 class="mb-0">Renseignements sur votre Profession</h3>
                               <small>Renseignez les informations sur vos occupations professionnelles</small>

                            </div>
                             <?php if($errors->any()): ?>
                            <div class="alert alert-danger rounded-sm mb-4 text-sm">
                            <ul class="list-unstyled p-0 m-0 text-sm ">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($i+1); ?>- <?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                            <?php echo Form::open(['method' => 'POST', 'url' => request()->url(), 'class' => 'form-horizontal', 'files' => true]); ?>


                                <?php echo csrf_field(); ?>
                                <label class="text-uppercase text-muted"> Renseignez sur votre Profession</label>
                                <hr class="p-0 mb-4">
                                <!-- Text input -->
                                <div class="form-group row">
                                <div class="col-md-6 form-group">
                                    <label for="text-input">Fonction actuelle  (*)</label>
                                    <input id="fonction" type="text" name="fonction" value="<?php echo e(old('fonction')); ?>" placeholder="Administrateur des impôts" class="form-control <?php $__errorArgs = ['fonction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  required autocomplete="fonction">

                                    <?php $__errorArgs = ['fonction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label for="text-input">Nom de la structure  (*)</label>
                                    <input id="structure" type="text" name="structure" value="<?php echo e(old('structure')); ?>" placeholder="Ministère des finances" class="form-control <?php $__errorArgs = ['structure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  required autocomplete="structure">

                                    <?php $__errorArgs = ['structure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-12 form-group <?php echo e($errors->has('secteur_id') ? 'has-error' : ''); ?>">
                                    <label for="text-input">Secteur d'activités (*)</label>
                                    <?php echo Form::select('secteur_id', isset($secteurs)?($secteurs):[''=>"Choisir secteur d'activité"], null,'' == 'required' ? ['class' => 'form-control  custom-select rounded-1', 'required' => 'required'] : ['class' => 'form-control  custom-select']); ?>

                                   
                                    <?php $__errorArgs = ['secteur_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="col-md-6 form-group">
                                    <label for="text-input">Lieu de travail  </label>
                                    <input id="lieu_poste" type="text" name="lieu_poste" value="<?php echo e(old('lieu_poste')); ?>" placeholder="Parakou" class="form-control <?php $__errorArgs = ['lieu_poste'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  autocomplete="lieu_poste">

                                    <?php $__errorArgs = ['lieu_poste'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label for="text-input">Depuis quelle année vous occupez ce poste  </label>
                                    <input id="annee_poste" type="text" name="annee_poste" value="<?php echo e(old('annee_poste')); ?>" placeholder="<?php echo e(date('Y')-3); ?>" class="form-control <?php $__errorArgs = ['annee_poste'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  autocomplete="annee_poste">

                                    <?php $__errorArgs = ['annee_poste'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label for="text-input">Site web  de la structure</label>
                                    <input id="site_web" type="text" name="site_web" value="<?php echo e(old('site_web')); ?>" placeholder="http://dgei.bj" class="form-control <?php $__errorArgs = ['site_web'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  autocomplete="site_web">

                                    <?php $__errorArgs = ['site_web'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label for="text-input">Contact de la structure (Tél, email) </label>
                                    <input id="contact" type="text" name="contact" value="<?php echo e(old('contact')); ?>" placeholder="96007766 - email@domaine.com" class="form-control <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  autocomplete="contact">

                                    <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                </div>
                                <!-- Text input -->
                                

                                <!-- Textarea -->
                                <div class="form-group">
                                    <label for="textarea-input">Autres renseignements sur la structure</label>
                                    <textarea class="form-control"  name="renseignements" id="textarea-input" rows="5"><?php echo old('renseignements'); ?></textarea>
                                    <?php $__errorArgs = ['renseignements'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="row mb-0">
                                    <div class="col-md-12 offset-md-0">
                                        <button type="submit" class="btn d-sm-inlin d-block btn-primary">
                                            <?php echo e(__('Sauvegarder')); ?>

                                        </button>


                                    </div>
                                </div>
                        </div>
                        </form>
                    </div>
                </div>
              
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\2022\alumni\resources\views/auth/enregistrement2.blade.php ENDPATH**/ ?>