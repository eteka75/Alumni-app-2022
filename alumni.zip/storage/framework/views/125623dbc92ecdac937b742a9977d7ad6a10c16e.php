<div class="form-group<?php echo e($errors->has('nom') ? 'has-error' : ''); ?>">
    <?php echo Form::label('nom', 'Nom', ['class' => 'control-label']); ?>

    <?php echo Form::text('nom', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('nom', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group<?php echo e($errors->has('slug') ? 'has-error' : ''); ?>">
    <?php echo Form::label('slug', 'Slug', ['class' => 'control-label']); ?>

    <?php echo Form::text('slug', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('slug', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group<?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
    <?php echo Form::label('description', 'Description', ['class' => 'control-label']); ?>

    <?php echo Form::textarea('description', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('description', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <?php echo Form::submit($formMode === 'edit' ? 'Mettre à jour' : 'Enrégistrer', ['class' => 'btn btn-primary']); ?>

</div>
<?php /**PATH C:\laragon\www\2022\alumni\resources\views/admin/secteur/form.blade.php ENDPATH**/ ?>