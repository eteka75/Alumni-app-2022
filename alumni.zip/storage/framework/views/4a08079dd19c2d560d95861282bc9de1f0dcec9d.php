<div class="b-shadow sidebar course-sidebar">
    <div class="widget-area">
        <div class="widget mb-3 video-widget">
            <div class="course-video">
                <iframe width="560" height="315" src="https://www.youtube.com/embed/LK47lO2JooQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
                                                     
        </div><!-- /.widget -->
      
<?php if(isset($categories) && $categories->count()): ?>
        <div class="widget widget_categories">
            <h3 class="widget_title">Catégories</h3>
            <ul>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('categorie',$cat->slug!=""?$cat->slug:$cat->id)); ?>"><?php echo e($cat->nom); ?></a>(<?php echo e($cat->activites->count()); ?>)</li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div><!-- /.widget -->    
<?php endif; ?>
        <div class="widget widget_recent_entries">
            <h3 class="widget_title">Actualités</h3>
            <ul>
                <?php $__currentLoopData = $actus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                    
                <li class="media">
                    <div class="entry-thumbnail">
                        <a href="<?php echo e(route('activite',$act->slug)); ?>">
                        <?php if($act->image && $act->image!=""): ?>
                        <img src="<?php echo e(asset($act->image)); ?>" alt="<?php echo e($act->titre); ?>" class="img-fluid">
                        <?php else: ?>
                        <img src="<?php echo e(asset('assets/images/cpet/actualite-default.jpg')); ?>" alt="<?php echo e($act->titre); ?>" class="img-fluid">
                        <?php endif; ?>
                        </a>
                    </div>
                    <div class="media-body">
                        <small class="post-date fs-xs"><?php echo e($act->created_at->diffForHumans()); ?></small><br>
                        <a href="<?php echo e(route('activite',$act->slug)); ?>"><?php echo e(substr($act->titre,0,100)); ?></a>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
            </ul>
        </div><!-- /.widget -->                                                                    
    </div><!-- /.widget-area -->  
</div><!-- /.course-sidebar -->    <?php /**PATH C:\laragon\www\cfpsdonboscobenin\parakou\resources\views/includes/right.blade.php ENDPATH**/ ?>