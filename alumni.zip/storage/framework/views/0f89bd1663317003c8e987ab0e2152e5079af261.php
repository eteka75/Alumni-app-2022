<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#0b9999">

        <title>CPET DON BOSCO <?php echo e(config('app.site')); ?> - <?php echo $__env->yieldContent('title','Le site Officiel'); ?></title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <Meta name="robots " content="index, follow"/>
<meta name=title content="CPET DON BOSCO <?php echo e(config('app.site')); ?>  • <?php echo $__env->yieldContent('title'); ?>">
<meta name=description content=" Le Collège Privé d'Enseignement Technique (CPET) «DON BOSCO» - est un centre de formation professionnel au Bénin. Nous avons deux sites : le Site de Parakou et celui de Cotonou.">

        <!-- Styles -->
        <style>
            /*! normalize.css v8.0.1 | MIT License | github.com/necolas/normalize.css */html{line-height:1.15;-webkit-text-size-adjust:100%}body{margin:0}a{background-color:transparent}[hidden]{display:none}html{font-family:system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;line-height:1.5}*,:after,:before{box-sizing:border-box;border:0 solid #e2e8f0}a{color:inherit;text-decoration:inherit}svg,video{display:block;vertical-align:middle}video{max-width:100%;height:auto}.bg-white{--bg-opacity:1;background-color:#fff;background-color:rgba(255,255,255,var(--bg-opacity))}.bg-gray-100{--bg-opacity:1;background-color:#f7fafc;background-color:rgba(247,250,252,var(--bg-opacity))}.border-gray-200{--border-opacity:1;border-color:#edf2f7;border-color:rgba(237,242,247,var(--border-opacity))}.border-t{border-top-width:1px}.flex{display:flex}.grid{display:grid}.hidden{display:none}.items-center{align-items:center}.justify-center{justify-content:center}.font-semibold{font-weight:600}.h-5{height:1.25rem}.h-8{height:2rem}.h-16{height:4rem}.text-sm{font-size:.875rem}.text-lg{font-size:1.125rem}.leading-7{line-height:1.75rem}.mx-auto{margin-left:auto;margin-right:auto}.ml-1{margin-left:.25rem}.mt-2{margin-top:.5rem}.mr-2{margin-right:.5rem}.ml-2{margin-left:.5rem}.mt-4{margin-top:1rem}.ml-4{margin-left:1rem}.mt-8{margin-top:2rem}.ml-12{margin-left:3rem}.-mt-px{margin-top:-1px}.max-w-6xl{max-width:72rem}.min-h-screen{min-height:100vh}.overflow-hidden{overflow:hidden}.p-6{padding:1.5rem}.py-4{padding-top:1rem;padding-bottom:1rem}.px-6{padding-left:1.5rem;padding-right:1.5rem}.pt-8{padding-top:2rem}.fixed{position:fixed}.relative{position:relative}.top-0{top:0}.right-0{right:0}.shadow{box-shadow:0 1px 3px 0 rgba(0,0,0,.1),0 1px 2px 0 rgba(0,0,0,.06)}.text-center{text-align:center}.text-gray-200{--text-opacity:1;color:#edf2f7;color:rgba(237,242,247,var(--text-opacity))}.text-gray-300{--text-opacity:1;color:#e2e8f0;color:rgba(226,232,240,var(--text-opacity))}.text-gray-400{--text-opacity:1;color:#cbd5e0;color:rgba(203,213,224,var(--text-opacity))}.text-gray-500{--text-opacity:1;color:#a0aec0;color:rgba(160,174,192,var(--text-opacity))}.text-gray-600{--text-opacity:1;color:#718096;color:rgba(113,128,150,var(--text-opacity))}.text-gray-700{--text-opacity:1;color:#4a5568;color:rgba(74,85,104,var(--text-opacity))}.text-gray-900{--text-opacity:1;color:#1a202c;color:rgba(26,32,44,var(--text-opacity))}.underline{text-decoration:underline}.antialiased{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.w-5{width:1.25rem}.w-8{width:2rem}.w-auto{width:auto}.grid-cols-1{grid-template-columns:repeat(1,minmax(0,1fr))}@media (min-width:640px){.sm\:rounded-lg{border-radius:.5rem}.sm\:block{display:block}.sm\:items-center{align-items:center}.sm\:justify-start{justify-content:flex-start}.sm\:justify-between{justify-content:space-between}.sm\:h-20{height:5rem}.sm\:ml-0{margin-left:0}.sm\:px-6{padding-left:1.5rem;padding-right:1.5rem}.sm\:pt-0{padding-top:0}.sm\:text-left{text-align:left}.sm\:text-right{text-align:right}}@media (min-width:768px){.md\:border-t-0{border-top-width:0}.md\:border-l{border-left-width:1px}.md\:grid-cols-2{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (min-width:1024px){.lg\:px-8{padding-left:2rem;padding-right:2rem}}@media (prefers-color-scheme:dark){.dark\:bg-gray-800{--bg-opacity:1;background-color:#2d3748;background-color:rgba(45,55,72,var(--bg-opacity))}.dark\:bg-gray-900{--bg-opacity:1;background-color:#1a202c;background-color:rgba(26,32,44,var(--bg-opacity))}.dark\:border-gray-700{--border-opacity:1;border-color:#4a5568;border-color:rgba(74,85,104,var(--border-opacity))}.dark\:text-white{--text-opacity:1;color:#fff;color:rgba(255,255,255,var(--text-opacity))}.dark\:text-gray-400{--text-opacity:1;color:#cbd5e0;color:rgba(203,213,224,var(--text-opacity))}.dark\:text-gray-500{--tw-text-opacity:1;color:#6b7280;color:rgba(107,114,128,var(--tw-text-opacity))}}
        </style>

        <!-- CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/all.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/YTPlayer.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/slick.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/structure.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">

        <!-- font -->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:100,300,400,500,600,700,800,900" rel="stylesheet">

        <!-- icons -->
        <link rel="icon" href="images/ico/favicon.ico">
        <link rel="apple-touch-icon" sizes="144x144" href="../images/ico/apple-touch-icon-precomposed.html">
        <link rel="apple-touch-icon" sizes="114x114" href="../images/ico/apple-touch-icon-114-precomposed.html">
        <link rel="apple-touch-icon" sizes="72x72" href="../images/ico/apple-touch-icon-72-precomposed.html">
        <link rel="apple-touch-icon" sizes="57x57" href="../images/ico/apple-touch-icon-57-precomposed.html">
        <!-- icons -->

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <!-- Template Developed By ChtStudio -->
        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }
        </style>
        <script async defer crossorigin="anonymous" src="https://connect.facebook.net/fr_FR/sdk.js#xfbml=1&version=v13.0&appId=808192846614159&autoLogAppEvents=1" nonce="T8C3ouJN"></script>

    </head>
    <body class="antialiased">
        <!--div class="relative flex items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center py-4 sm:pt-0">
            <?php if(Route::has('login')): ?>
                <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>" class="text-sm text-gray-700 dark:text-gray-500 underline">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 dark:text-gray-500 underline">Log in</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>" class="ml-4 text-sm text-gray-700 dark:text-gray-500 underline">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>


        </div-->

        <!--div id="preloader">
            <img src="<?php echo e(asset('assets/images/preloader-cfps.gif')); ?>" alt="Chargement..." class="tr-preloader img-fluid">
        </div--><!-- preloader -->
        
        <?php $__env->startSection('sidebar'); ?>
          
        <header class="sa-header">
            <?php if(Session::has('flash_message')): ?>
                <div class="messages">
                    <div class="alert alert-success mb-0">
                        <?php echo Session::get('flash_message'); ?>

                    </div>
                </div>
            <?php endif; ?>
            <div class="sa-topbar">
                <div class="container">
                    <div class="topbar-content">
                        <div class="left-content">
                            <ul class="global-list">
                                <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-graduation-cap"></i>CPET DON BOSCO - <?php echo e(config('app.site')); ?></a></li>
                                <li><a href="mailto:cotonou@cfpsdonboscobenin.com"><i class="far fa-envelope"></i><?php echo e(strtolower(config('app.site'))); ?>@cfpsdonboscobenin.com</a></li>
                                
                            </ul>
                        </div>
                        <div class="right-content">
                            <ul class="global-list social">
                                <li><a href="#"><i class="fab fa-facebook"></i> Facebook</a></li>
                                <!--li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li-->
                            </ul>
                            <ul class="global-list">
                                <li><a href="<?php echo e(url('inscription/fiche')); ?>" class="btn btn-default text-white-hover">Imprimer ma fiche <i class="fas fa-register"></i></a></li>
                                <li><a href="<?php echo e(url('inscription/')); ?>" class="btn btn-primary">S'inscrire en ligne <i class="fas fa-sign-in-alt"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div><!-- /.container -->
            </div><!-- /.top-bar -->

            <div class="sa-menu">
                <nav class="navbar navbar-expand-lg">
                    <div class="container">
                        <a class="navbar-brand" href="http://cfpsdonboscobenin.com">
                            <img src="<?php echo e(asset('assets/images/logo.jpg')); ?>" alt="CFPS DON BOSCO" class="img-fluid">
                        </a>

                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"><i class="fas fa-bars"></i></span>
                        </button>

                        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                            <ul class="navbar-nav">
                                <li class="nav-item <?php echo e((isset($page)&& $page=='accueil')?'active':''); ?>">
                                    <a href="<?php echo e(route('Index')); ?>">Accueil</a>
                                </li>
                                 <li class="sa-dropdown <?php echo e((isset($page)&& $page=='apropos')?'active':''); ?>">
                                    <a href="#">A propos</a>
                                    <ul class="sa-dropdown-menu">
                                        <li><a href="<?php echo e(url('notre-histoire')); ?>">Historique</a></li>
                                        <li><a href="<?php echo e(url('notre-mission')); ?>">Notre mission</a></li>
                                        <li><a href="<?php echo e(url('notre-vision')); ?>">Notre vision</a></li>
                                         <li><a href="<?php echo e(url('nos-valeurs')); ?>">Nos valeurs</a></li>
                                        <li><a href="<?php echo e(url('membres-administratifs')); ?>">Les Membres de l'administration</a></li>
                                        <li><a href="<?php echo e(url('enseignants')); ?>">Nos enseignants</a></li>
                                    </ul>
                                </li>
                                <li class="nav-item <?php echo e((isset($page)&& $page=='formations')?'active':''); ?>">
                                    <a href="<?php echo e(route('formations')); ?>">Nos formations</a>
                                </li>
                                <li class="nav-item <?php echo e((isset($page)&& $page=='activites')?'active':''); ?>"><a href="<?php echo e(route('activites')); ?>">Nos activités</a></li>
                                <!--li class="sa-dropdown">
                                    <a href="index-2.html">Renseignements</a>
                                    <ul class="sa-dropdown-menu">
                                        <li><a href="#catagory">Renseignements 1</a></li>
                                        <li><a href="profile.html">Renseignements 2</a></li>
                                        <li><a href="#blog-details">Renseignements 3</a></li>
                                        <li><a href="tutor-details.html">Renseignements 4</a></li>
                                        <li><a href="congrats.html">Congrats<span class="badge rounded-pill bg-dark">New</span></a></li>
                                        <li><a href="sign-up.html">S'inscrire</a></li>
                                    </ul>
                                </li-->
                                
                                <li class="sa-dropdown <?php echo e((isset($page)&& $page=='autres')?'active':''); ?>">
                                    <a href="#">Autres</a>
                                    <ul class="sa-dropdown-menu">
                                        <li><a href="<?php echo e(url('evenements')); ?>">Evènements</a></li>
                                        <li><a href="<?php echo e(url('communiques')); ?>">Communiqués</a></li>
                                        <li><a href="<?php echo e(url('fichiers-a-telecharger')); ?>">Fichiers à télécharger</a></li>
                                        <li><a href="<?php echo e(url('galerie-images')); ?>">Galerie Images</a></li>
                                        <li><a href="<?php echo e(url('galerie-videos')); ?>">Galerie Vidéos</a></li>
                                    </ul>
                                <i class="fas fa-chevron-down icon"></i></li>
                                <li class="<?php echo e((isset($page)&& $page=='contact')?'active':''); ?>"><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                            </ul>
                        </div>

                        <div class="right-content">
                            <div class="user-option">
                                <ul class="global-list">
                                    <!--li class="sa-dropdown">
                                        <span class="cart-number">5</span>
                                        <i class="fas fa-cart-plus"></i>
                                        <div class="sa-dropdown-menu">
                                            <ul class="global-list">
                                                <li class="remove-item">
                                                    <span class="remove-icon"><i class="fas fa-times"></i></span>
                                                    <div class="sa-course">
                                                        <div class="course-thumb">
                                                            <img src="<?php echo e(asset('assets/images/course/1.jpg')); ?>" alt="Image" class="img-fluid">
                                                        </div>

                                                        <div class="course-info">
                                                            <div class="info">
                                                                <h2 class="title"><a href="#" >Visual Basic Web Course With Live Project</a></h2>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="remove-item">
                                                    <span class="remove-icon"><i class="fas fa-times"></i></span>
                                                    <div class="sa-course">
                                                        <div class="course-thumb">
                                                            <img src="assets/images/course/2.jpg" alt="Image" class="img-fluid">
                                                        </div>

                                                        <div class="course-info">
                                                            <div class="info">
                                                                <h2 class="title"><a href="#">Computer Technologies Course With Live Project</a></h2>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="remove-item">
                                                    <span class="remove-icon"><i class="fas fa-times"></i></span>
                                                    <div class="sa-course">
                                                        <div class="course-thumb">
                                                            <img src="assets/images/course/3.jpg" alt="Image" class="img-fluid">
                                                        </div>

                                                        <div class="course-info">
                                                            <div class="info">
                                                                <h2 class="title"><a href="#" >Visual Basic Web Course With Live Project</a></h2>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                            <div class="total-price">
                                                <span><strong>Total Price: </strong>$598:00</span>
                                            </div>
                                            <div class="buttons">
                                                <a class="btn btn-primary cart-button" href="#">View Cart</a>
                                                <a class="btn btn-primary" href="#">Checkout</a>
                                            </div>
                                        </div>
                                    </li>
                                    <li><i class="far fa-bell"></i></li-->
                                    <li>
                                        <div class="sa-search-form">
                                            <div class="search-icon">
                                                <i class="fas fa-search"></i>
                                            </div>
                                            <div class="search-form text-center open-search">
                                                <div class="close-search">
                                                    <span class="remove-icon"><i class="fas fa-times"></i></span>
                                                </div>
                                                <form action="<?php echo e(url('search')); ?>" id="search" method="get">
                                                    <input name="search" type="text" placeholder="Entrer un mot clé...">
                                                    <button type="submit"><i class="fas fa-search"></i></button>
                                                </form>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div><!-- /.container -->
                </nav><!-- /.navbar -->
            </div><!-- /.sa-menu -->
        </header><!-- /.sa-header -->
        <?php echo $__env->yieldSection(); ?>

        <div class="main bg-white_">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
       
        <div class="footer">
            <div class="footer-top">
                <div class="container">
                    <div class="footer-content">
                        <div class="row">
                            <div class="col-md-6 col-lg-3">
                                <div class="footer-widget">
                                    <div class="footer-logo">
                                        <a href="http://cfpsdonboscobenin.com"><img src="<?php echo e(asset("assets/images/logo.jpg")); ?>" alt="Logo" class="img-fluid"></a>
                                    </div>
                                    <p>
                                    Le Collège Privé d'Enseignement Technique (CPET) «DON BOSCO» - est un centre de formation professionnel dont le numéro d'autorisation est : 2006 N°061/MESFP/DC/ SGM/DPP/DET/DFQP/SA
    
                                    </p>

                                </div>
                            </div>
                            <div class="col-md-6 col-lg-3">
                                <div class="footer-widget px-md-4">
                                    <h3>Liens utiles</h3>
                                    <ul class="global-list">
                                        <li><a href="<?php echo e(route('formations')); ?>">Nos formations</a></li>
                                        <li><a href="<?php echo e(route('Apropos')); ?>">A propos de nous</a></li>
                                        <!--li><a href="<?php echo e(url('http://parakou.cfpsdonboscobenin.com/')); ?>">Site de Parakou</a></li-->
                                        
                                        <li><a href="<?php echo e(route('enseignants')); ?>">Nos enseignants</a></li>
                                        <li><a href="<?php echo e(route('evenements')); ?>">Evènements</a></li>
                                        <li><a href="<?php echo e(route('membres-administratifs')); ?>">Personnel Administratif</a></li>
                                        
                                        <li><a href="<?php echo e(url('http://cotonou.cfpsdonboscobenin.com/')); ?>">Site de Cotonou</a></li>
                                        <li><a href="<?php echo e(route('login')); ?>">Administration du site</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-3">
                                <div class="footer-widget">
                                    <h3>Médias</h3>
                                    <ul class="global-list">
                                        <li><a href="<?php echo e(route('activites')); ?>">Nos activités</a></li>
                                        <li><a href="<?php echo e(route('communiques')); ?>">Communiqués</a></li>
                                        <li><a href="<?php echo e(route('galerie-images')); ?>">Galerie images</a></li>
                                        <li><a href="<?php echo e(route('galerie-videos')); ?>">Galerie vidéos</a></li>
                                        <li><a href="<?php echo e(route('fichiers-a-telecharger')); ?>">Fichiers téléchargeables</a></li>
                                        <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-3">
                                <div class="footer-widget">
                                    <!--h3>Newsletter</h3>
                                    <h6 class="text-white"><small>S'inscrire à la Newsletter</small></h6>
                                    <form action="#" class="sa-form">
                                        <input type="email" class="form-control" placeholder="Adress email" required="">
                                        <button type="submit"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
                                    </form-->
                                    
                                    <div class="payment-gateway">
                                        <h4>Rejoignez-nous </h4>
                                        
        <div class="b-shadow sidebar course-sidebar">
            <div class="mb-3 mx-auto">
                <div class="fb-page img-fluid" data-href="https://web.facebook.com/Odacesoft/?_rdc=1&amp;_rdr" data-tabs="journal" data-width="400" data-height="" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://web.facebook.com/Odacesoft/?_rdc=1&amp;_rdr" class="fb-xfbml-parse-ignore"><a href="https://web.facebook.com/Odacesoft/?_rdc=1&amp;_rdr">Odacesoft</a></blockquote></div>
            
            </div>
                                        <!--div class="footer-social">
                                            <ul class="global-list">
                                                <li><a href="#"><i class="fab fa-facebook-f"></i></a><br></li>
                                                <li><a href="#"><i class="fab fa-twitter"></i></a><br></li>
                                            </ul>
                                        </div-->
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.row -->
                    </div>
                </div><!-- /.container -->
            </div>
            <div class="footer-bottom">
                <div class="container text-center">
                    <span>Copyright &copy; <?php echo e(date('Y')); ?> CFPS DON BOSCO <?php echo e(config('app.site')); ?> - Tout droit réservé.</span>
                </div><!-- /.container -->
            </div>
        </div><!-- /.footer -->

        <!-- JS -->
        <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jarallax.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/inview.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/slick.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery-ui-min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/counterup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/waypoints.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/YTPlayer.min.js')); ?>"></script>
        <!--script src="<?php echo e(asset('assets/js/validate.js')); ?>"></script-->
        <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>
<?php /**PATH C:\laragon\www\cfpsdonboscobenin\resources\views/layouts/web.blade.php ENDPATH**/ ?>