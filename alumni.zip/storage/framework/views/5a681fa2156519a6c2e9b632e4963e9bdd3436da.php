<div class="form-group<?php echo e($errors->has('nom') ? 'has-error' : ''); ?>">
    <?php echo Form::label('nom', 'Nom', ['class' => 'control-label']); ?>

    <?php echo Form::text('nom', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('nom', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group<?php echo e($errors->has('sigle') ? 'has-error' : ''); ?>">
    <?php echo Form::label('sigle', 'Sigle', ['class' => 'control-label']); ?>

    <?php echo Form::text('sigle', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('sigle', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group<?php echo e($errors->has('logo') ? 'has-error' : ''); ?>">
    <?php echo Form::label('logo', 'Logo', ['class' => 'control-label']); ?>

    <?php echo Form::file('logo',  ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('logo', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group mt-4 <?php echo e($errors->has('description') ? 'has-error' : ''); ?> mb-3">
    <?php echo Form::label('description', 'Description', ['class' => 'control-label']); ?>

    <?php echo Form::textarea('description', null, ('' == 'required') ? ['class' => 'form-control crud-richtext', 'required' => 'required'] : ['class' => 'form-control crud-richtext','rows'=>'3']); ?>

    <?php echo $errors->first('description', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group<?php echo e($errors->has('etat') ? 'has-error' : ''); ?> ">
    <?php echo Form::label('etat', 'Etat', ['class' => 'control-label']); ?>

    <div class="checkbox">
    <label><?php echo Form::radio('etat', '1'); ?> Activé</label>
</div>
<div class="checkbox">
    <label><?php echo Form::radio('etat', '0', true); ?> Désactivé</label>
</div>
    <?php echo $errors->first('etat', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <?php echo Form::submit($formMode === 'edit' ? 'Mettre à jour' : 'Enrégistrer', ['class' => 'btn btn-primary']); ?>

</div>
<?php /**PATH C:\laragon\www\2022\alumni\resources\views/admin/entite/form.blade.php ENDPATH**/ ?>