

<?php $__env->startSection('title', isset($data,$data['title'])?$data['title']:'Site de Cotonou'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>

    <section class="breadcrumb-section">
        <div class="container">
            <h1><?php echo e(isset($data,$data['title'])?$data['title']:'Site de Cotonou'); ?></h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('Index')); ?>">Accueil</a></li>
                <li class="breadcrumb-item"><?php echo e(isset($data,$data['title'])?$data['title']:'Site de Cotonou'); ?></li>
            </ol>
        </div><!-- /.container -->
    </section> 
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="sg-section">
    <div class="section-content course-details bg-white section-padding_ py-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="sa-course_">
                        <div class="course-thumb">
                            <?php if(isset($data,$data['image'])): ?>
                            <img src="<?php echo e(asset(isset($data,$data['image'])?$data['image']:'')); ?>" alt="Image" class="img-fluid">
                            <?php endif; ?>
                        </div>
                        <div class="course-info">
                            <?php echo isset($data,$data['content'])?$data['content']:'-'; ?>

                           
                        </div>
                    </div><!-- /.sa-course -->                           
                </div>
                <div class="col-lg-4">
                   <?php echo $__env->make('includes.right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cfpsdonboscobenin\resources\views/web/sitecotonou.blade.php ENDPATH**/ ?>