

<?php $__env->startSection('title', 'Editer Test1  #'.$test1->id  ); ?>


<?php $__env->startSection('sidebar'); ?>
    <div class="d-flex flex-column flex-md-row justify-content-md-between align-items-md-center py-2 text-center text-md-start">

        <div class="flex-grow-1 mb-1 mb-md-0">
            <h1 class="h3 fw-bold mb-1">                
                 Test1 #<?php echo e($test1->id); ?>

            </h1>
            <h2 class="h6 fw-medium fw-medium text-muted mb-0">
               Edition de Test1 #<?php echo e($test1->id); ?>

            </h2>
        </div>
        <div class="mt-3 mt-md-0 ms-md-3 space-x-1">
            <?php echo Form::open(['method' => 'GET', 'url' => '/admin/test1', 'class' => 'd-none d-sm-inline-block', 'role' => 'search']); ?>


            <div class="input-group input-group-sm">
                <input type="text" class="form-control form-control-alt_" placeholder="Rechercher.."
                    id="page-header-search-input2" name="search" value="<?php echo e(request('search')); ?>"
                    name="page-header-search-input2">
                <button type="submit" class="input-group-text border-1 bg-primary text-white">
                    <i class="fa fa-fw fa-search"></i>
                </button>
            </div>
            <?php echo Form::close(); ?>


            <a class="btn btn-sm btn-alt-secondary bg-white border space-x-1" href="<?php echo e(url('/admin/test1/create')); ?>">
                <i class="fa fa-plus opacity-50"></i>
                <span>Ajouter</span>
            </a>            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="row">
            <div class="col-md-9">
                <div class="block block-rounded">
                    
                    <div class="card-body">
                        <a href="<?php echo e(url('/admin/test1')); ?>" title="Back"><button class="btn btn-secondary btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i> Retour</button></a>
                        <br />
                        <br />

                        <?php if($errors->any()): ?>
                            <ul class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>

                        <?php echo Form::model($test1, [
                            'method' => 'PATCH',
                            'url' => ['/admin/test1', $test1->id],
                            'class' => 'form-horizontal',
                            'files' => true
                        ]); ?>


                        <?php echo $__env->make('admin.test1.form', ['formMode' => 'edit'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php echo Form::close(); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cfpsdonboscobenin\resources\views/admin/test1/edit.blade.php ENDPATH**/ ?>