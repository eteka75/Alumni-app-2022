<div class="row">
    <div class="col-md-6">
        <div class="form-group  <?php echo e($errors->has('site') ? 'has-error' : ''); ?>">
            <?php echo Form::label('site', 'Site', ['class' => 'control-label']); ?>

            <?php echo Form::select('site', ['PARAKOU'=>"Site de Parakou","COTONOU"=>"Site de Cotonou"],null,('required' == 'required') ? ['class' => 'form-select', 'required' => 'required'] : ['class' => 'form-control ']); ?>

            <?php echo $errors->first('site', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>   
</div>
<div class="row">
    <div class="col-md-6">
        <div class="form-group<?php echo e($errors->has('nom') ? 'has-error' : ''); ?>">
            <?php echo Form::label('nom', 'Nom', ['class' => 'control-label']); ?>

            <?php echo Form::text('nom', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('nom', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="col-md-6">
      <div class="form-group<?php echo e($errors->has('prenom') ? 'has-error' : ''); ?>">
        <?php echo Form::label('prenom', 'Prénom', ['class' => 'control-label']); ?>

        <?php echo Form::text('prenom', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

        <?php echo $errors->first('prenom', '<p class="help-block">:message</p>'); ?>

       </div>
   </div>
</div>
<div class="row mb-2">
    <div class="col-md-6">
        <div class="form-group  <?php echo e($errors->has('sexe') ? 'has-error' : ''); ?>">
            <?php echo Form::label('sexe', 'Sexe', ['class' => 'control-label']); ?>

            <?php echo Form::select('sexe', ['M'=>"Masculin","F"=>"Féminin"],null,('required' == 'required') ? ['class' => 'form-select', 'required' => 'required'] : ['class' => 'form-control ']); ?>

            <?php echo $errors->first('sexe', '<p class="help-block">:sexe</p>'); ?>

        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group<?php echo e($errors->has('specialite') ? 'has-error' : ''); ?>">
            <?php echo Form::label('specialite', 'Spécialité', ['class' => 'control-label']); ?>

            <?php echo Form::text('specialite', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('specialite', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>   
</div>
<div class="row mb-2">
    <div class="col-md-6">
<div class="form-group<?php echo e($errors->has('ecole') ? 'has-error' : ''); ?>">
    <?php echo Form::label('ecole', 'Ecole', ['class' => 'control-label']); ?>

    <?php echo Form::text('ecole', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('ecole', '<p class="help-block">:message</p>'); ?>

</div>
</div>
    <div class="col-md-6">
       <div class="form-group<?php echo e($errors->has('poste') ? 'has-error' : ''); ?>">
    <?php echo Form::label('poste', 'Poste', ['class' => 'control-label']); ?>

    <?php echo Form::text('poste', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('poste', '<p class="help-block">:message</p>'); ?>

    </div>
  </div>
</div>
<div class="row mb-2">
    <div class="col-md-6">
<div class="form-group<?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
    <?php echo Form::label('email', 'Email', ['class' => 'control-label']); ?>

    <?php echo Form::text('email', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('email', '<p class="help-block">:message</p>'); ?>

</div>
</div>
    <div class="col-md-6">
<div class="form-group<?php echo e($errors->has('telephone') ? 'has-error' : ''); ?>">
    <?php echo Form::label('telephone', 'Téléphone', ['class' => 'control-label']); ?>

    <?php echo Form::text('telephone', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('telephone', '<p class="help-block">:message</p>'); ?>

</div>
</div>
</div>
<div class="row mb-2">
    <div class="col-md-6">
<div class="form-group<?php echo e($errors->has('lien_facebook') ? 'has-error' : ''); ?>">
    <?php echo Form::label('lien_facebook', 'Lien Facebook', ['class' => 'control-label']); ?>

    <?php echo Form::text('lien_facebook', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('lien_facebook', '<p class="help-block">:message</p>'); ?>

</div>
</div>

<div class="col-md-6">
<div class="form-group<?php echo e($errors->has('lien_linkedin') ? 'has-error' : ''); ?>">
    <?php echo Form::label('lien_linkedin', 'Lien Linkedin', ['class' => 'control-label']); ?>

    <?php echo Form::text('lien_linkedin', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('lien_linkedin', '<p class="help-block">:message</p>'); ?>

</div>
</div>
</div>
<div class="form-group<?php echo e($errors->has('photo') ? 'has-error' : ''); ?>">
    <?php echo Form::label('photo', 'Photo', ['class' => 'control-label']); ?>

    <?php echo Form::file('photo',  ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('photo', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group<?php echo e($errors->has('biographie') ? 'has-error' : ''); ?>">
    <?php echo Form::label('biographie', 'Biographie', ['class' => 'control-label']); ?>

    <?php echo Form::textarea('biographie', null, ('' == 'required') ? ['class' => 'form-control crud-richtext','rows'=>"10", 'required' => 'required'] : ['class' => 'form-control crud-richtext','rows'=>"15"]); ?>

    <?php echo $errors->first('biographie', '<p class="help-block">:message</p>'); ?>

</div>

<div class="row clearfix form-group mt-3 mb-4<?php echo e($errors->has('etat') ? 'has-error' : ''); ?>">
    <?php echo Form::label('etat', 'Activé', ['class' => 'float-start d-flex flex _control-label']); ?> 
    
    <div class="checkbox  col-sm-2 col-md-1">
    <label><?php echo Form::radio('etat', '1'); ?> Oui</label>
</div>
<div class="checkbox col-sm-3 col-md-1">
    <label><?php echo Form::radio('etat', '0', true); ?> Non</label>
</div>
    <?php echo $errors->first('etat', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group">
    <?php echo Form::submit($formMode === 'edit' ? 'Mettre à jour' : 'Enrégistrer', ['class' => 'btn btn-primary']); ?>

</div>
<?php /**PATH C:\laragon\www\cfpsdonboscobenin\resources\views/admin/enseignant/form.blade.php ENDPATH**/ ?>