<div class="form-group<?php echo e($errors->has('titre') ? 'has-error' : ''); ?>">
    <?php echo Form::label('titre', 'Titre', ['class' => 'control-label']); ?>

    <?php echo Form::text('titre', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('titre', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group<?php echo e($errors->has('user_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('user_id', 'User Id', ['class' => 'control-label']); ?>

    <?php echo Form::number('user_id', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('user_id', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <?php echo Form::submit($formMode === 'edit' ? 'Mettre à jour' : 'Enrégistrer', ['class' => 'btn btn-primary']); ?>

</div>
<?php /**PATH C:\laragon\www\cfpsdonboscobenin\resources\views/admin/test5/form.blade.php ENDPATH**/ ?>