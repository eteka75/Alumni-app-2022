<div class="form-group<?php echo e($errors->has('nom') ? 'has-error' : ''); ?>">
    <?php echo Form::label('nom', 'Nom', ['class' => 'control-label']); ?>

    <?php echo Form::text('nom', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('nom', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <?php echo Form::submit($formMode === 'edit' ? 'Mettre à jour' : 'Enrégistrer', ['class' => 'btn btn-primary']); ?>

</div>
<?php /**PATH C:\laragon\www\cfpsdonboscobenin\resources\views/admin/test/form.blade.php ENDPATH**/ ?>