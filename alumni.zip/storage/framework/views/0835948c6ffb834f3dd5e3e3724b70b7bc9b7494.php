
<?php $__env->startSection('title', 'Accueil'); ?>
<?php $__env->startSection('content'); ?>
<style>
  .img_ucover{
    height: 280px;
    overflow: hidden;
  }
  .card-curved-body{
    height: 360px;
  }
</style>
        <!-- Page content-->
        <section class="cs-sidebar text-white mb-n4" style="background: url('<?php echo e(asset('storage/assets/web/img/bg_amphi1000.jpeg')); ?>') no-repeat; background-size:cover">        
            <div class="container pt-4">
                <!--nav aria-label="breadcrumb">
                    <ol class="py-1 my-2 breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item"><a href="shop-ls.html">Shop</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Order tracking</li>
                    </ol>
                </nav-->
                <!-- Details-->
                <div class="row">
                    <div class="col-sm-12 col-xl-10 col-xxl-9 mx-auto text-center">
                        <h1 class="display-3 text-uppercase_  text-white mt-5"><?php echo e(__("Plateforme des Alumnis de l'Université de Parakou")); ?></h1>
                        
                    </div>
                </div>
                <div class="row mb-4">

                    <div class="col-sm-7 col-xl-6 col-xxl-5 mx-auto ">
                        <div class="text-white py-3 px-4 text-center">
                            Cette plateforme vous permet de découvrir sur cette plateforme vos anciens camarades d'universités, des opportunités de travail, etc. 
                            Si vous êtes un alumni, vous avez la possibilité de rejoindre la communauté afin de partager des opportunités.
                    <div>
                        <div class="my-4 mb-6">
                          <?php if(!Auth::user()): ?>                            
                          <a class=" btn btn-primary shadow-lg  py-2  px-4" href="<?php echo e(route('register')); ?>"><?php echo e(__('Nous rejoindre')); ?></a> 
                          <?php endif; ?>
                            <a class=" btn btn-default py-2  px-4text-dark bg-white border mx-3" href="#"><?php echo e(__('En savoir plus')); ?></a> 
                        </div>

                        
                    </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="bg-secondary py-5 py-md-6">
            <div class="container py-2 py-md-0">
              <div class="row align-items-center">
                <div class="col-xl-4 text-center text-xl-left">
                  <h2 class="mb-4 mb-xl-0">Quelques statiques sur la plateforme:</h2>
                </div>
                <div class="col-xl-8">
                  <div class="cs-countdown h2 display-2 justify-content-center justify-content-xl-start" data-countdown="10/01/2021 07:00:00 PM">
                    <div class="cs-countdown-days mb-0 mt-3 mr-0 px-4 border-right"><span class="cs-countdown-value font-weight-normal px-4">123</span><span class="cs-countdown-label font-size-lg text-body">Membres</span></div>
                    <div class="cs-countdown-hours mb-0 mt-3 mr-0 px-4 border-right"><span class="cs-countdown-value font-weight-normal px-4">12</span><span class="cs-countdown-label font-size-lg text-body">Entreprises</span></div>
                    <div class="cs-countdown-minutes mb-0 mt-3 mr-0 px-4 border-right"><span class="cs-countdown-value font-weight-normal px-4">23</span><span class="cs-countdown-label font-size-lg text-body">Opportunités</span></div>
                    <div class="cs-countdown-seconds mb-0 mt-3 mr-0 px-4"><span class="cs-countdown-value font-weight-normal px-4">8</span><span class="cs-countdown-label font-size-lg text-body">Activités</span></div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <section class="container py-4 py-md-4 py-lg-5 my-4">
              <div class="row">
                
                <div class="col-sm-4">
                    <div class="bg-light box-shadow-lg rounded-lg p-4 mb-grid-gutter text-center text-sm-left"><img class="d-inline-block mb-4 mt-2" width="100" src="<?php echo e(asset('storage/assets/web/img/demo/business-consulting/services/01.svg')); ?>" alt="Icon">
                      <h3 class="h5 mb-2">Strategy &amp; Innovation</h3>
                      <p class="font-size-sm">Find aute irure dolor in reprehend in voluptate velit esse cillum dolore eu fugiat nulla pariatur. </p>
                    </div>                    
                  </div>
                <div class="col-sm-4">
                    <div class="bg-light box-shadow-lg rounded-lg p-4 mb-grid-gutter text-center text-sm-left"><img class="d-inline-block mb-4 mt-2" width="100" src="<?php echo e(asset('storage/assets/web/img/demo/business-consulting/services/01.svg')); ?>" alt="Icon">
                      <h3 class="h5 mb-2">Strategy &amp; Innovation</h3>
                      <p class="font-size-sm">Find aute irure dolor in reprehend in voluptate velit esse cillum dolore eu fugiat nulla pariatur. </p>
                    </div>                    
                  </div>
                <div class="col-sm-4">
                    <div class="bg-light box-shadow-lg rounded-lg p-4 mb-grid-gutter text-center text-sm-left"><img class="d-inline-block mb-4 mt-2" width="100" src="<?php echo e(asset('storage/assets/web/img/demo/business-consulting/services/01.svg')); ?>" alt="Icon">
                      <h3 class="h5 mb-2">Strategy &amp; Innovation</h3>
                      <p class="font-size-sm">Find aute irure dolor in reprehend in voluptate velit esse cillum dolore eu fugiat nulla pariatur. </p>
                    </div>                    
                  </div>
              </div>
          </section>
          <?php if(isset($membres) && count($membres)): ?>
          <section class="bg-success">
          <div class="container pt-3 pb-2 pb-md-3 pb-lg-4 pt-md-4 pt-lg-5">
            <h2 class="text-center_ pt-2 pt-md-0 mb-5 text-uppercase_ display-5 text-white" >Quelques alumnis</h2>        
            <div class="row pb-3 pb-md-0">
              <?php $__currentLoopData = $membres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $membre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-3 col-md-4 col-sm-6 mb-grid-gutter">
                <div class="card card-curved-body card-hover border-0 box-shadow mx-auto" style="max-width: 20rem;">
                  <div class="card-img-top text-center card-img-gradient">
                    <div class="img_ucover">                      
                      <img src="<?php echo e(asset($membre->profile_photo_path)); ?>" class="img-fluid mx-auto" alt="<?php echo e($membre->nom_prenom()); ?>">
                    </div>
                  </div>
                  <div class="card-body text-center">
                    <h3 class="h6 card-title mb-2"><?php echo e($membre->nom_prenom()); ?></h3>
                    <p class="font-size-xs text-body mb-0"><?php echo e($membre->getPoste()); ?></p>
                  </div>
                    </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              

              <div class="col-md-12 text-right">
                <a class="btn bg-white  mb-4" href="#"><span class="fe-plus"></span> Plus de membres</a>
          </div>
            </div>
        </div>
          </section>
          <?php endif; ?>
          <section class="py-6 border-bottom_">
              <div class="container">
                  <div class="row">
                      <div class="col-md-12">
                          <h2 class="mb-5">Quelques activités</h2>
                      </div>
                    <div class="col-md-3 col-12 shuffle-item shuffle-item--visible mb-4" >
                        <article class="card card-hover"><a class="card-img-top" href="blog-single-rs.html"><img src="<?php echo e(asset('storage/assets/web/img/blog/01.jpg')); ?>" alt="Post thumbnail"></a>
                          <div class="card-body"><a class="meta-link font-size-sm mb-2" href="#">Digital design</a>
                            <h2 class="h5 nav-heading mb-4"><a href="blog-single-rs.html">Designers should always keep their users in mind</a></h2><a class="media meta-link font-size-sm align-items-center pt-3" href="#"><img class="rounded-circle" width="36" src="<?php echo e(asset('storage/assets/web/img/blog/avatar/01.jpg')); ?>" alt="Emma Brown">
                              <div class="media-body pl-2 ml-1 mt-n1">by<span class="font-weight-semibold ml-1">Emma Brown</span></div></a>
                            <div class="mt-3 text-right text-nowrap"><a class="meta-link font-size-xs" href="#"><i class="fe-message-square mr-1"></i>&nbsp;6</a><span class="meta-divider"></span><a class="meta-link font-size-xs" href="#"><i class="fe-calendar mr-1 mt-n1"></i>&nbsp;Feb 19</a></div>
                          </div>
                        </article>
                      </div>
                    <div class="col-md-3 col-12 shuffle-item shuffle-item--visible mb-4" >
                        <article class="card card-hover"><a class="card-img-top" href="blog-single-rs.html"><img src="<?php echo e(asset('storage/assets/web/img/blog/01.jpg')); ?>" alt="Post thumbnail"></a>
                          <div class="card-body"><a class="meta-link font-size-sm mb-2" href="#">Digital design</a>
                            <h2 class="h5 nav-heading mb-4"><a href="blog-single-rs.html">Designers should always keep their users in mind</a></h2><a class="media meta-link font-size-sm align-items-center pt-3" href="#"><img class="rounded-circle" width="36" src="<?php echo e(asset('storage/assets/web/img/blog/avatar/01.jpg')); ?>" alt="Emma Brown">
                              <div class="media-body pl-2 ml-1 mt-n1">by<span class="font-weight-semibold ml-1">Emma Brown</span></div></a>
                            <div class="mt-3 text-right text-nowrap"><a class="meta-link font-size-xs" href="#"><i class="fe-message-square mr-1"></i>&nbsp;6</a><span class="meta-divider"></span><a class="meta-link font-size-xs" href="#"><i class="fe-calendar mr-1 mt-n1"></i>&nbsp;Feb 19</a></div>
                          </div>
                        </article>
                      </div>
                    <div class="col-md-3 col-12 shuffle-item shuffle-item--visible mb-4" >
                        <article class="card card-hover"><a class="card-img-top" href="blog-single-rs.html"><img src="<?php echo e(asset('storage/assets/web/img/blog/01.jpg')); ?>" alt="Post thumbnail"></a>
                          <div class="card-body"><a class="meta-link font-size-sm mb-2" href="#">Digital design</a>
                            <h2 class="h5 nav-heading mb-4"><a href="blog-single-rs.html">Designers should always keep their users in mind</a></h2><a class="media meta-link font-size-sm align-items-center pt-3" href="#"><img class="rounded-circle" width="36" src="<?php echo e(asset('storage/assets/web/img/blog/avatar/01.jpg')); ?>" alt="Emma Brown">
                              <div class="media-body pl-2 ml-1 mt-n1">by<span class="font-weight-semibold ml-1">Emma Brown</span></div></a>
                            <div class="mt-3 text-right text-nowrap"><a class="meta-link font-size-xs" href="#"><i class="fe-message-square mr-1"></i>&nbsp;6</a><span class="meta-divider"></span><a class="meta-link font-size-xs" href="#"><i class="fe-calendar mr-1 mt-n1"></i>&nbsp;Feb 19</a></div>
                          </div>
                        </article>
                      </div>
                    <div class="col-md-3 col-12 shuffle-item shuffle-item--visible mb-4" >
                        <article class="card card-hover"><a class="card-img-top" href="blog-single-rs.html"><img src="<?php echo e(asset('storage/assets/web/img/blog/01.jpg')); ?>" alt="Post thumbnail"></a>
                          <div class="card-body"><a class="meta-link font-size-sm mb-2" href="#">Digital design</a>
                            <h2 class="h5 nav-heading mb-4"><a href="blog-single-rs.html">Designers should always keep their users in mind</a></h2><a class="media meta-link font-size-sm align-items-center pt-3" href="#"><img class="rounded-circle" width="36" src="<?php echo e(asset('storage/assets/web/img/blog/avatar/01.jpg')); ?>" alt="Emma Brown">
                              <div class="media-body pl-2 ml-1 mt-n1">by<span class="font-weight-semibold ml-1">Emma Brown</span></div></a>
                            <div class="mt-3 text-right text-nowrap"><a class="meta-link font-size-xs" href="#"><i class="fe-message-square mr-1"></i>&nbsp;6</a><span class="meta-divider"></span><a class="meta-link font-size-xs" href="#"><i class="fe-calendar mr-1 mt-n1"></i>&nbsp;Feb 19</a></div>
                          </div>
                        </article>
                      </div>
                  </div>
                  <div class="col-md-12 text-right">
                        <a  class="btn btn-primary mt-4" href="#"><span class="fe-plus"></span> Plus d'activité</a>
                  </div>
              </div>
          </section>
         
         <section class="d-none bg-gradient position-relative pt-6 pb-5 py-sm-6">
            <div class="bg-overlay bg-size-cover opacity-100" style="background-color: transparent; background-image: url(<?php echo e(asset('storage/assets/web/img/demo/booking/bg-pattern01.png')); ?>);"></div>
            <div class="bg-overlay-content container py-2">
              <div class="row align-items-center">
                <div class="col-lg-5 offset-lg-1 order-lg-2 pb-5 pb-lg-0 text-center text-lg-left">
                  <h2 class="text-light">What is Around?</h2>
                  <p class="text-light mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
                </div>
                <div class="col-lg-6 order-lg-1">
                  <div class="row">
                    <div class="col-sm-4 mb-2 pb-4 mb-sm-0 pb-sm-0">
                      <div class="px-2 text-center"><img class="bg-light rounded-circle mb-2" width="105" src="<?php echo e(asset('storage/assets/web/img/demo/booking/icons/01.svg')); ?>" alt="Tickets">
                        <p class="font-size-sm font-weight-medium text-light mb-0 pt-1">Make it easier to experience the world</p>
                      </div>
                    </div>
                    <div class="col-sm-4 mb-2 pb-4 mb-sm-0 pb-sm-0">
                      <div class="px-2 text-center"><img class="bg-light rounded-circle mb-2" width="105" src="<?php echo e(asset('storage/assets/web/img/demo/booking/icons/02.svg')); ?>" alt="Search">
                        <p class="font-size-sm font-weight-medium text-light mb-0 pt-1">Advanced searching with filters</p>
                      </div>
                    </div>
                    <div class="col-sm-4 mb-2 pb-4 mb-sm-0 pb-sm-0">
                      <div class="px-2 text-center"><img class="bg-light rounded-circle mb-2" width="105" src="<?php echo e(asset('storage/assets/web/img/demo/booking/icons/03.svg')); ?>" alt="Flight">
                        <p class="font-size-sm font-weight-medium text-light mb-0 pt-1">Find the cheapest regular flights</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <div class="bg-primary_ border-top shadow-lg ">
          <section class="container py-6 pt-md-0 pb-5 pb-md-6 pb-lg-7">
            <h2 class="text-center mb-5 pt-5">Nos partenaires</h2>
            <div class="row">
              <div class="col-md-3 col-sm-4 col-6 text-center"><a class="cs-swap-image mb-grid-gutter" href="#"><img class="cs-swap-to" width="176" src="<?php echo e(asset('storage/assets/web/img/demo/event-landing/partners/01_color.png')); ?>" alt="Logo"><img class="cs-swap-from" width="176" src="<?php echo e(asset('storage/assets/web/img/demo/event-landing/partners/01_gray.png')); ?>" alt="Logo"></a></div>
              <div class="col-md-3 col-sm-4 col-6 text-center"><a class="cs-swap-image mb-grid-gutter" href="#"><img class="cs-swap-to" width="176" src="<?php echo e(asset('storage/assets/web/img/demo/event-landing/partners/02_color.png')); ?>" alt="Logo"><img class="cs-swap-from" width="176" src="<?php echo e(asset('storage/assets/web/img/demo/event-landing/partners/02_gray.png')); ?>" alt="Logo"></a></div>
              <div class="col-md-3 col-sm-4 col-6 text-center"><a class="cs-swap-image mb-grid-gutter" href="#"><img class="cs-swap-to" width="176" src="<?php echo e(asset('storage/assets/web/img/demo/event-landing/partners/03_color.png')); ?>" alt="Logo"><img class="cs-swap-from" width="176" src="<?php echo e(asset('storage/assets/web/img/demo/event-landing/partners/03_gray.png')); ?>" alt="Logo"></a></div>
              <div class="col-md-3 col-sm-4 col-6 text-center"><a class="cs-swap-image mb-grid-gutter" href="#"><img class="cs-swap-to" width="176" src="<?php echo e(asset('storage/assets/web/img/demo/event-landing/partners/04_color.png')); ?>" alt="Logo"><img class="cs-swap-from" width="176" src="<?php echo e(asset('storage/assets/web/img/demo/event-landing/partners/04_gray.png')); ?>" alt="Logo"></a></div>
              <div class="col-md-3 col-sm-4 col-6 text-center"><a class="cs-swap-image mb-grid-gutter" href="#"><img class="cs-swap-to" width="176" src="<?php echo e(asset('storage/assets/web/img/demo/event-landing/partners/05_color.png')); ?>" alt="Logo"><img class="cs-swap-from" width="176" src="<?php echo e(asset('storage/assets/web/img/demo/event-landing/partners/05_gray.png')); ?>" alt="Logo"></a></div>
              <div class="col-md-3 col-sm-4 col-6 text-center"><a class="cs-swap-image mb-grid-gutter" href="#"><img class="cs-swap-to" width="176" src="<?php echo e(asset('storage/assets/web/img/demo/event-landing/partners/06_color.png')); ?>" alt="Logo"><img class="cs-swap-from" width="176" src="<?php echo e(asset('storage/assets/web/img/demo/event-landing/partners/06_gray.png')); ?>" alt="Logo"></a></div>
              <div class="col-md-3 col-sm-4 col-6 text-center"><a class="cs-swap-image mb-grid-gutter" href="#"><img class="cs-swap-to" width="176" src="<?php echo e(asset('storage/assets/web/img/demo/event-landing/partners/07_color.png')); ?>" alt="Logo"><img class="cs-swap-from" width="176" src="<?php echo e(asset('storage/assets/web/img/demo/event-landing/partners/07_gray.png')); ?>" alt="Logo"></a></div>
              <div class="col-md-3 col-sm-4 col-6 text-center"><a class="cs-swap-image mb-grid-gutter" href="#"><img class="cs-swap-to" width="176" src="<?php echo e(asset('storage/assets/web/img/demo/event-landing/partners/08_color.png')); ?>" alt="Logo"><img class="cs-swap-from" width="176" src="<?php echo e(asset('storage/assets/web/img/demo/event-landing/partners/08_gray.png')); ?>" alt="Logo"></a></div>
            </div>
          </section>
        </div>
          <section>
              <div class="container">
                  
              </div>
          </section>
          <section class="position-relative bg-secondary py-5 py-md-6 py-lg-7" style="margin-top: 00px;">
            <div style="height: 30px;"></div>
            <div class="cs-shape cs-shape-top cs-shape-curve bg-body">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 3000 185.4">
                <path fill="currentColor" d="M3000,185.4V0H0v185.4C496.4,69.8,996.4,12,1500,12S2503.6,69.8,3000,185.4z"></path>
              </svg>
            </div>
            <div class="container mt-n4 py-3 py-md-2">
              <h2 class="text-center mb-5">Questions &amp; Réponses</h2>
              <div class="row justify-content-center">
                <div class="col-lg-8 col-md-9">
                  <div class="accordion accordion-alt" id="faq">
                    <div class="card border-0 box-shadow card-active">
                      <div class="card-header">
                        <h3 class="accordion-heading"><a href="#faq-1" role="button" data-toggle="collapse" aria-expanded="true" aria-controls="faq-1">Can I import my projects from Teamwork?<span class="accordion-indicator"></span></a></h3>
                      </div>
                      <div class="collapse show" id="faq-1" data-parent="#faq">
                        <div class="card-body font-size-sm">
                          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim.</p>
                          <p class="mb-0">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.</p>
                        </div>
                      </div>
                    </div>
                    <div class="card border-0 box-shadow">
                      <div class="card-header">
                        <h3 class="accordion-heading"><a class="collapsed" href="#faq-2" role="button" data-toggle="collapse" aria-expanded="true" aria-controls="faq-2">What are correct file permissions?<span class="accordion-indicator"></span></a></h3>
                      </div>
                      <div class="collapse" id="faq-2" data-parent="#faq">
                        <div class="card-body font-size-sm">
                          <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.</p>
                          <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim.</p>
                        </div>
                      </div>
                    </div>
                    <div class="card border-0 box-shadow">
                      <div class="card-header">
                        <h3 class="accordion-heading"><a class="collapsed" href="#faq-3" role="button" data-toggle="collapse" aria-expanded="true" aria-controls="faq-3">How to set default projects for new users?<span class="accordion-indicator"></span></a></h3>
                      </div>
                      <div class="collapse" id="faq-3" data-parent="#faq">
                        <div class="card-body font-size-sm">
                          <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.</p>
                          <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim.</p>
                        </div>
                      </div>
                    </div>
                    <div class="card border-0 box-shadow">
                      <div class="card-header">
                        <h3 class="accordion-heading"><a class="collapsed" href="#faq-4" role="button" data-toggle="collapse" aria-expanded="true" aria-controls="faq-4">Is it possible to upload files from Google Drive?<span class="accordion-indicator"></span></a></h3>
                      </div>
                      <div class="collapse" id="faq-4" data-parent="#faq">
                        <div class="card-body font-size-sm">
                          <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.</p>
                          <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="text-center py-5">
                    <a href="<?php echo e(url('faq')); ?>" class=" btn btn-primary">Plus de questions <i class="fe-plus"></i></a>
                  </div>
                </div>
              </div>
            </div>
          </section>
<?php $__env->stopSection(); ?>
    
        

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\2022\alumni\resources\views/web/index.blade.php ENDPATH**/ ?>