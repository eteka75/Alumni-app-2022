<?php $__env->startSection('title', 'Réinitialisation de mot de passe'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4 mt-5">
                <div class="card_p-5 shadow-smç rounded-3 border mb-5">
                   
                    <div class="card-body p-5">
                    <div class="text-center mb-4">
                        <h3><?php echo e(__('Réinitialisation de mot de passe')); ?></h3>
                        <small>Entrez votre adresse email pour réinitialiser le mot de passe de votre compte.</small>
                       
                    </div>
                    <form method="POST" action="<?php echo e(route('password.email')); ?>">
                            <?php echo csrf_field(); ?>
    
                            <div class="row mb-3">
                                <label for="email" class="col-md-12 col-form-label text-md-end"><?php echo e(__('Email de votre compte')); ?></label>
    
                                <div class="col-md-12">
                                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
    
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
    
                            <div class="row mb-0">
                                <div class="col-md-12 ">
                                    <button type="submit" class="btn btn-secondary w-100">
                                        <?php echo e(__('Envoyer le lien de réinitiamisation')); ?>

                                    </button>
                                </div>
                            </div>
                            <div class="row mb-0">
                                    
                                <div class="col-md-12 text-center mt-3 offset-md-0">
                                    <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link" href="<?php echo e(route('login')); ?>">
                                        <?php echo e(__('Se connecter')); ?>

                                    </a>
                                    <?php endif; ?>
    <br>
                                    <small> <a href="<?php echo e(route('register')); ?>">Nouveau ?, créer un compte</a>
                                </div>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\2022\alumni\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>