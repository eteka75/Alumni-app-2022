

<?php $__env->startSection('title', 'Annuaires'); ?>

<?php $__env->startSection('sidebar'); ?>
    <section class="breadcrumb-section py-5">
        <div class="container">
            <h2 class="h2"><?php echo e('Annuaires'); ?></h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('Index')); ?>">Accueil</a></li>
                <li class="breadcrumb-item">Annuaires</li>
            </ol>
        </div><!-- /.container -->
    </section> 
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  
  <!-- Team-->
  <section class="container mb-5 pb-3 pb-lg-0 mb-lg-7">
    <?php if(isset($content)): ?>
    <?php echo $content; ?>

    <?php endif; ?>
  </section>
  <!-- Clients-->
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\2022\alumni\resources\views/web/annuaires.blade.php ENDPATH**/ ?>