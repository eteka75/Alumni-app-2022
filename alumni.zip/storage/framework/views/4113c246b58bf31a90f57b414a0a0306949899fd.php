

<?php $__env->startSection('title', 'Nos Evènements au CPET DON BOSCO '.config('app.site')); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>

    <section class="breadcrumb-section">
        <div class="container">
            <h1>Evènements</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('Index')); ?>">Accueil</a></li>
                <li class="breadcrumb-item">Evènements</li>
            </ol>
        </div><!-- /.container -->
    </section>    
    
    <?php $__env->startSection('content'); ?>
    <div class="sg-section">
        <div class="section-content course-details bg-white section-padding_ py-4">
            <div class="container">
                <div class="row p-3">
                <div class="col-md-8 col-12 col-xl-8">
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row border-0 mx-1 py-2  border-bottom rounded-3shadow-0">
                        <div class="col-12 col-sm-4 col-md-3 p-0">
                            <div class="course-thumb">
                                
                                <a href="<?php echo e(route('evenement',$d->id)); ?>"> 
                                    <?php if($d->photo && $d->photo!=""): ?>
                                    <img src="<?php echo e(asset($d->photo)); ?>" alt="<?php echo e($d->titre); ?>" class="img-fluid">
                                    <?php else: ?>
                                    <img src="<?php echo e(asset('assets/images/cpet/actualite-default.jpg')); ?>" alt="<?php echo e($d->titre); ?>" class="img-fluid">
                                    <?php endif; ?>
                                    </a>
                            </div><!-- /.course-thumb -->
                        </div>
                        <div class="col-12 col-sm-8 col-md-9">
                            <div class="sa-courses">                             

                                <div class="course-info_ px-2 py-3">
                                    <div class="info">
                                       
                                        <h5 class="title fs-sm mt-1 text-success"><a href="<?php echo e(route('evenement',($d->slug!="")?$d->slug:$d->id)); ?>"><?php echo e($d->titre); ?></a></h5>
                                        <ul class="list-inline mt-3pt-2 text-muted  h6 border-top_">
                                            <li class="list-inline-item"><small><i>DATE : <?php echo e(date('d/m/Y H:i',strtotime($d->date))); ?></i></small></li>
                                            <li class="list-inline-item"><small><i>LIEU : <?php echo e($d->lieu); ?></i></small></li>
                                        </ul>
                                        <h2 class="entry-title_ h6 text-muted fw-normal fs-xs"><a href="<?php echo e(route('evenement',($d->slug!="")?$d->slug:$d->id)); ?>"><?php echo isset($d->description)? substr(strip_tags($d->description),0,200):''; ?>... </a></h2>
                                       
                                    </div>
                                </div><!-- /.course-info -->
                            </div><!-- /.sg-course -->                                      
                        </div>
                    </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="sg-pagination float-end  px-1 ">
                            <?php echo e($datas->links()); ?>

                        </div> 
                </div>
                <div class="col-lg-4">
                    
                    <?php echo $__env->make('includes.right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                 </div>
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.section-content -->
    </div>
    <?php $__env->stopSection(); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cfpsdonboscobenin\resources\views/web/evenements.blade.php ENDPATH**/ ?>