<?php $__env->startSection('title', 'Accueil'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(isset($slides) && $slides->count() ): ?>
<?php
    $n=$i=0;
?>
<div id="hero-slider" class="carousel slide hero-content" data-bs-ride="carousel">
    <div class="carousel-inner">
        <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="carousel-item text-center <?php echo e($n++==0?'active':''); ?>">
            <div class="carousel-item-content section-before"  style="background-image: url(<?php echo e(asset($slide->image)); ?>);">
                <div class="container">
                    <div class="hero-text">
                        <h1 data-animation="animated fadeInDown"><?php echo e($slide->titre); ?> </h1>
                        <p data-animation="animated fadeInDown"><?php echo e($slide->sous_titre); ?></p>
                        <!--div class="buttons">
                            <a href="#" class="btn btn-primary"  data-animation="animated fadeInRight">Nos diplomés</a>
                            <a href="#" class="btn btn-white"  data-animation="animated fadeInLeft">En savoir plus</a>
                        </div-->
                    </div><!-- /.hero-text -->
                </div><!-- /.container -->
            </div><!-- /.carousel-item-content -->
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        

    </div><!-- /.carousel-inner -->

    <div class="carousel-indicators">
        <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <button type="button" data-bs-target="#hero-slider" data-bs-slide-to="<?php echo e($i++); ?>" class="<?php echo e($i==1?'active':''); ?>" aria-current="<?php echo e($i==1?'true':''); ?>" aria-label="<?php echo e($s->trire); ?>"></button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <button class="carousel-control-prev" type="button" data-bs-target="#hero-slider" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#hero-slider" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div><!-- /#hero-slider -->
<?php endif; ?>
<?php if(isset($mot) && $mot->count()): ?>

<div class="sa-section py-5" >
    <div class="section-content sa-about">
        <div class="container">
            <div class="row">
                
                <div class="col-lg-6 align-self-center">
                    <div class="section-header">
                        <div class="title">
                            <h1>Mot de Bienvenue</h1>
                            <span>Mot de bienvenue</span>
                        </div>
                    </div>
                    <div class="about-info fs-5">
                        <h2 class="h4"><?php echo e($mot->title); ?></h2>
                        <?php echo isset($mot)? substr(strip_tags($mot->content),0,700):''; ?>...
                        <br>
                        <a href="<?php echo e(route("page",$mot->slug)); ?>" class="btn btn-primary btn-sm mt-3">En savoir plus  <i class="fa fa-arrow-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <?php if($mot->image && $mot->image!=''): ?>
                    <div class="about-thumb">
                        <img src="<?php echo e(asset($mot->image)); ?>" alt="<?php echo e($mot->title); ?>" class="img-fluid">
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div>
    
<?php endif; ?>
<div class="sa-sectionpy-4">
    <div class="section-content bg-white shadow-lg sa-about section-padding">
        <div class="container">
            <div class="row">


                <div class="col-lg-6 text-center">
                    <div class="section-header">
                        <div class="title">
                            <h1>SITE DE COTONOU</h1>
                            <span>COTONOU</span>
                        </div>
                    </div>
                    <div class="about-thumb p-0">
                       <a href="<?php echo e(route('siteCotonou')); ?>"> <img src="assets/images/cpet/cpet_cotonou.jpg" alt="Image" class="img-fluid rounded-3"></a>
                    </div>
                </div>
                <div class="col-lg-6  text-center">
                    <div class="section-header">
                        <div class="title">
                            <h1>SITE DE PARAKOU</h1>
                            <span>PARAKOU</span>
                        </div>
                    </div>
                    <div class="about-thumb p-0">
                        <a href="<?php echo e(route('siteParakou')); ?>"> <img src="assets/images/cpet/cpet_parakou.jpg" alt="Image" class="img-fluid rounded-3"></a>
                    </div>
                </div>
            </div>
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div><!-- /.sa-section -->

<?php if(isset($formations) && $formations->count()): ?>
<div class="sa-section mb-4 bg_actu__bg-secondary bg-white border-top_ bg-black-10shadow-sm py-5">
    <div class="section-content py-2">
        <div class="container">
            <div class="section-header justify-content-between">
                <div class="title">
                    <h1>Nos domaines de formation</h1>
                    <span>Nos domaines</span>
                </div>
                <div class="view-all align-self-center">
                    <a href="<?php echo e(route('formations')); ?>" class="btn btn-primary">Voir tout</a>
                </div>
            </div><!-- /.section-header -->

            <div class="sg-category-content">
                <div class="row">
                    <?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6 col-12 col-lg-3 mb-3">
                        <div class="p-3 h-100 card border-1 shadow-sm rounded-2">
                            <a href="#catagory">
                                <!--span class="icon">
                                    <i class="fas fa-desktop"></i>
                                </span-->
                                <div>
                                    <h5><?php echo e($f->titre); ?></h5>

                                </div>
                                <div class="py-2">
                                    <small class="text-muted"><?php echo e(substr(strip_tags($f->description),0,100)); ?> ...<span class="text-promary font-weight-bold">[lire la suite]</span></small>
                                </div>
                            </a>
                        </div><!-- /.sg-category -->
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div><!-- /.row -->
            </div><!-- /.sg-category-content -->
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div><!-- /.sa-section -->
<?php endif; ?>

<?php if(isset($activites) && $activites->count()): ?>
<div class="sa-section py-5 ">
    <div class="section-content section-padding padding-top-0 py-2">
        <div class="container">
            <div class="section-header text-center justify-content-between">
                <div class="title align-self-center">
                    <h1>Nos activités</h1>
                    <span>Activités</span>
                </div>
                <div class="view-all align-self-center">
                    <a href="<?php echo e(route('activites')); ?>" class="btn btn-primary">Voir Tout</a>
                </div>
            </div><!-- /.section-header -->

            <div class="sa-course-content">
                <div class="sa-course-sliders row">
                    <?php $__currentLoopData = $activites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $data=$act
                    ?>
                     <div class="col-lg-4  col-md-4 col-sm-6 col-12">
                        <div class="sa-post border-1">
                            <div class="entry-header">
                                <div class="entry-thumbnail">
                                    <a href="<?php echo e(route('activite',$data['slug'])); ?>"> 
                                    <?php if($act->image && $act->image!=""): ?>
                                    <img src="<?php echo e(asset($act->image)); ?>" alt="<?php echo e($act->titre); ?>" class="img-fluid">
                                    <?php else: ?>
                                    <img src="<?php echo e(asset('assets/images/cpet/actualite-default.jpg')); ?>" alt="<?php echo e($act->titre); ?>" class="img-fluid">
                                    <?php endif; ?>
                                    </a>
                                </div>
                                <div class="entry-meta">
                                    <a href="<?php echo e(route('activite',$data['slug'])); ?>"><?php echo e(date('d',strtotime($data['created_at']))); ?> <span><?php echo e(date('M.y',strtotime($data['created_at']))); ?> </span></a>
                                </div>   
                            </div>                               
                            <div class="entry-content">  
                                <?php if(isset($data['site'])): ?>                                                
                                <?php endif; ?>
                                <span class="badge bg-danger mt-n3 float-end rounded-pill"><?php echo e(isset($data->categorie)?$data->categorie->nom:''); ?></span>   <br>
                                <h2 class="entry-title_ h6"><a href="<?php echo e(route('activite',$data['slug'])); ?>"><?php echo e($data['titre']); ?> </a></h2>
                                
                                <a class="read-more" href="<?php echo e(route('activite',($data->slug!="")?$data->slug:$data->id)); ?>">En savoir plus <span class="fa fa-arrow-right"></span></a>
                            </div>
                        </div><!-- /.sa-post -->                            
                    </div>
                    <!--div class="sa-course card">

                        <div class="course-thumb border">
                        <div class="">
                            <?php if($act->image && $act->image!=""): ?>
                            <img src="<?php echo e(asset($act->image)); ?>" alt="<?php echo e($act->titre); ?>" class="img-fluid">
                            <?php else: ?>
                            <img src="<?php echo e(asset('assets/images/cpet/actualite-default.jpg')); ?>" alt="<?php echo e($act->titre); ?>" class="img-fluid">
                            <?php endif; ?>
                        </div>
                            <div class="overlay ">
                                <div class="icons">
                                    <ul class="global-list">
                                        <li><a href="<?php echo e(route('activite',$act->slug)); ?>" class="ms-4"><i class="fas fa-info"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rating-date bg-dark align-self-end">
                                <div class="date ">
                                    <small><i class="far fa-clock"></i><?php echo e(date('d M Y H:i',strtotime($act->created_at))); ?></small>
                                </div>
                            </div>
                        </div>

                        <div class="course-info h-100 text-center">
                            <div class="info">
                                <h2 class="title fw-normal"><a href="<?php echo e(route('activite',$act->slug)); ?>"><?php echo e($act->titre); ?></a></h2>
                                <p><span class="badge"><?php echo e(isset($act->categorie)?$act->categorie->nom:''); ?></span></p>
                            </div>
                            <div class="sa-meta">
                                <ul class="global-list fw-normal fs-sm">
                                    <li><span><i class="far fa-user"></i></span><?php echo e(isset($act->user)?$act->user->name:''); ?></span></li>
                                    <li><span><i class="far fa-eye"></i></span><?php echo e((int)$act->view_count); ?></li>
                                </ul>
                            </div>
                        </div>
                    </div-->
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div><!-- /.sg-course-slider -->
            </div><!-- /sg-course-content -->

        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div><!-- /.sa-section -->
<?php endif; ?>

<?php if(isset($enseignants) && $enseignants->count()): ?>
<div class="section-content download-content  section-before jarallax" style="background-image: none;" data-jarallax-original-styles="background-image: url(<?php echo e(asset('assets/images/bg/bg2.jpg')); ?>);">
<div class="sa-section py-5">
    <div class="section-content tutor-content text-center py-2">
        <div class="container">
            <div class="section-header justify-content-between">
                <div class="title align-self-center">
                    <h1>Nos enseignants </h1>
                    <span>Nos Enseignants</span>
                </div>
                <div class="view-all align-self-center">
                    <a href="<?php echo e(route('enseignants')); ?>" class="btn bg-white btn-sm px-3">Voir tout</a>
                </div>
            </div>

            <div class="tutor-slider">
                
                <?php $__currentLoopData = $enseignants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="sa-tutor col-md-4 col-sm-6">
                    <div class="tutor-thumb">
                        <a href="tutor-details.html">
                            <?php if($e->photo && $e->photo!=""): ?>
                            <img src="<?php echo e(asset($e->photo)); ?>" alt="<?php echo e($e->titre); ?>" class="img-fluid">
                            <?php else: ?>
                            <img src="<?php echo e(asset('assets/images/cpet/enseignant-default.jpg')); ?>" alt="<?php echo e($e->titre); ?>" class="img-fluid">
                            <?php endif; ?>
                        </a>
                    </div><!-- /.tutor-thumb -->
                    <div class="tutor-info">
                        <h2><a href="tutor-details.html"><?php echo e($e->nom .' '.$e->prenom); ?></a></h2>
                        <?php if($e->specialite): ?>
                        <small><b>Spécialité :</b><?php echo e($e->specialite); ?></small><br>
                        <?php endif; ?>
                        <?php if($e->poste): ?>
                        <small><b>Poste :</b> <?php echo e($e->poste); ?></small>
                        <?php endif; ?>
                        <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p> -->
                    </div>
                    <?php if(($e->lien_facebook && $e->lien_facebook!="") || ($e->lien_linkedin && $e->lien_linkedin!="")): ?>
                    <div class="tutor-social">
                        <ul class="global-list">
                            <?php if($e->lien_facebook && $e->lien_facebook!=""): ?>
                            <li><a href="<?php echo e(($e->lien_facebook)); ?>" target="_blanck"><i class="fab fa-facebook-f"></i></a></li>
                            <?php endif; ?>
                            <?php if($e->lien_linkedin && $e->lien_linkedin!=""): ?>
                            <li><a href="<?php echo e(($e->lien_linkedin)); ?>" target="_blanck"><i class="fab fa-linkedin-in"></i></a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                </div><!-- /.sg-tutor -->
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div><!-- /.tutor-slider -->
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div>
</div>
<?php endif; ?>

<?php if(isset($partenaires) && $partenaires->count()): ?>
<div class="sa-section">
    <div class="section-content section-padding text-center">
        <div class="container">
            <div class="section-header">
                <div class="title align-self-center">
                    <h1>Nos partenaires</h1>
                    <span>Partenaires</span>
                </div>
            </div>

            <div class="brand-slider">
                <?php $__currentLoopData = $partenaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="brand">
                   <a href="<?php echo e(route('partenaire',$p->slug)); ?>" target="_blanck"> <img src="<?php echo e(asset($p->logo)); ?>" alt="Image" class="img-fluid"></a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div><!-- /.tutor-slider -->
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div><!-- /.sa-section -->
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cfpsdonboscobenin\parakou\resources\views/web/index.blade.php ENDPATH**/ ?>