

<?php $__env->startSection('title', "Fichiers"); ?>

<?php $__env->startSection('sidebar'); ?>
    <div
        class="d-flex flex-column flex-md-row justify-content-md-between align-items-md-center py-2 text-center text-md-start">
        <div class="flex-grow-1 mb-1 mb-md-0">
            <h1 class="h3 fw-bold mb-1">
            Fichiers
            </h1>
            <h2 class="h6 fw-medium fw-medium text-muted mb-0">
                Création et gestion des Fichiers
            </h2>
        </div>
        <div class="mt-3 mt-md-0 ms-md-3 space-x-1">
            <?php echo Form::open(['method' => 'GET', 'url' => '/admin/fichier', 'class' => 'd-none d-sm-inline-block', 'role' => 'search']); ?>


            <div class="input-group input-group-sm">
                <input type="text" class="form-control form-control-alt_" placeholder="Rechercher.."
                    id="page-header-search-input2" name="search"  placeholder="Rechercher..." value="<?php echo e(request('search')); ?>"
                    name="page-header-search-input2">
                <button type="submit" class="input-group-text border-1 bg-primary text-white">
                    <i class="fa fa-fw fa-search"></i>
                </button>
            </div>
            <?php echo Form::close(); ?>


            <a class="btn btn-sm btn-alt-secondary bg-white border space-x-1" href="<?php echo e(url('/admin/fichier/create')); ?>" autofocus>
                <i class="fa fa-plus opacity-50"></i>
                <span>Ajouter</span>
            </a>

           
            <div class="dropdown d-inline-block">
                <button type="button" class="btn btn-sm btn-alt-secondary bg-white space-x-1"
                    id="dropdown-analytics-overview" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-fw fa-list-alt opacity-50"></i>
                    <span>Afficher</span>
                    <i class="fa fa-fw fa-angle-down"></i>
                </button>
                <div class="dropdown-menu dropdown-menu-end fs-sm" aria-labelledby="dropdown-analytics-overview">
                   
                    <a class="dropdown-item fw-medium" href="<?php echo e(url('/admin/fichier')); ?>?nb=5&order=<?php echo e(isset($order)?$order:"ASC"); ?>&search=<?php echo e(isset($search)?$search:null); ?>">5 enrégistrements <?php echo (isset($nb) && $nb==5)?'<i class="fa fa-check"></i>':''; ?></a>
                    <a class="dropdown-item fw-medium" href="<?php echo e(url('/admin/fichier')); ?>?nb=10&order=<?php echo e(isset($order)?$order:"ASC"); ?>&search=<?php echo e(isset($search)?$search:null); ?>">10 enrégistrements <?php echo (isset($nb) && $nb==10)?'<i class="fa fa-check"></i>':''; ?></a>
                    <a class="dropdown-item fw-medium" href="<?php echo e(url('/admin/fichier')); ?>?nb=20&order=<?php echo e(isset($order)?$order:"ASC"); ?>&search=<?php echo e(isset($search)?$search:null); ?>">20 enrégistrements <?php echo (isset($nb) && $nb==20)?'<i class="fa fa-check"></i>':''; ?></a>
                    <a class="dropdown-item fw-medium" href="<?php echo e(url('/admin/fichier')); ?>?nb=30&order=<?php echo e(isset($order)?$order:"ASC"); ?>&search=<?php echo e(isset($search)?$search:null); ?>">30 enrégistrements <?php echo (isset($nb) && $nb==30)?'<i class="fa fa-check"></i>':''; ?></a>
                    
                    <!--a class="dropdown-item fw-medium d-flex align-items-center justify-content-between"
                            href="javascript:void(0)">
                            <span>All time</span>
                            <i class="fa fa-check"></i>
                        </a-->
                </div>
                <div  class="dropdown d-inline-block">
                    <?php if(Request::input('order')=="DESC"): ?>
                        <a href="<?php echo e(url('/admin/fichier')); ?>?order=ASC&nb=<?php echo e(isset($nb)?$nb:5); ?>&search=<?php echo e(isset($search)?$search:null); ?>" target="_self" class="btn btn-sm btn-alt-secondary bg-white border space-x-1">
                            <i  title="Trie croissant" class="fa fa-arrow-up"></i>
                        </a>
                    <?php else: ?>
                        <a href="<?php echo e(url('/admin/fichier')); ?>?order=DESC&nb=<?php echo e(isset($nb)?$nb:5); ?>&search=<?php echo e(isset($search)?$search:null); ?>"  target="_self" class="btn btn-sm btn-alt-secondary bg-white border space-x-1">
                            <i  title="Trie décroissant" class="fa fa-arrow-down"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <div class="">
        <div class="row">

            <div class="col-md-12">
                <div class="block block-rounded">
                    <div class="block-header block-header-default">
                        <h3 class="block-title"><?php echo e(isset($nb)?$nb:''); ?> Enrégistrements <?php echo e(isset($nb)?'par page':''); ?></h3>  <?php echo isset($search) && $search!="" ?'<span class=" float-end "><span class="text-capitalize">Recherche : </span><span class="text-primary">'.$search.'</span></span>':''; ?>

                        <div class="block-options space-x-1">
                            <button type="button" class="btn btn-sm btn-alt-secondary" data-toggle="class-toggle"
                                data-target="#one-dashboard-search-orders" data-class="d-none">
                                <i class="fa fa-search"></i>
                            </button>

                        </div>
                    </div>
                    <div id="one-dashboard-search-orders" class="block-content border-bottom d-none">
                         <?php echo Form::open(['method' => 'GET', 'url' => '/admin/fichier', 'class' => 'd-none d-none d-sm-block', 'role' => 'search']); ?>


                        <div class="push">
                            <div class="input-group">
                                <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                                    class="form-control form-control-alt" id="one-ecom-orders-search"
                                    placeholder="Rechercher...">
                                <button type="submit" class="input-group-text bg-body border-0">
                                    <i class="fa fa-search"></i>
                                </button>
                            </div>
                        </div>
                        </form>
                    </div>
                    <div class="block-content block-content-full">
                        <div class="table-responsive">
                            <table class="table table-hover table-vcenter">
                                <thead>
                                    <tr>
                                        <th class="text-start">#</th><th>Site</th><th>Titre</th>
                                        <th>Etat</th>
                                        
                                        <th class="d-none d-sm-table-cell text-start">Date d'ajout</th>
                                        <th class="d-none d-xl-table-cell text-end">Actions</th>
                                    </tr>
                                </thead>
                                 <tbody class="fs-sm">
                                <?php $__currentLoopData = $fichier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-start"><?php echo e($loop->iteration or $item->id); ?></td>
                                        <td><?php echo e($item->site); ?></td><td><?php echo e($item->titre); ?></td>
                                        <td>
                                            <?php if($item->etat==1): ?>
                                            <span class="badge bg-success rounded-pill">Activé</span>
                                            <?php else: ?>
                                            <span class="badge bg-secondary rounded-pill">Inactif</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="">
                                        <div class="text-sm text-dark"><?php echo e(date('d/m/Y à H\h i\m\i\n',strtotime($item->created_at))); ?></div>
                                        <?php if(Auth::user()->hasRole('SuperU')): ?>
                                        <small class="text-muted"> <span class="badgebg-secondaryrounded-pill"><i class="si si-user-following"></i></span> <?php echo e(($item->user)?$item->user->name:''); ?></small>
                                        <?php endif; ?>
                                        </td>
                                        <td class="text-end">
                                         <?php if(Auth::user()->hasRole('Redacteur') || Auth::user()->hasRole('Admin')|| Auth::user()->hasRole('SuperU')): ?>
                                            <a href="<?php echo e(url('/admin/fichier/' . $item->id)); ?>" title="Voir Fichier"><button class="btn btn-alt-primary btn-sm"><i class="si si-eye" aria-hidden="true"></i></button></a>
                                            
                                            <a href="<?php echo e(url('/admin/fichier/' . $item->id . '/edit')); ?>" title="Editer Fichier"><button class="btn btn-alt-primary btn-sm"><i class="si si-note" aria-hidden="true"></i></button></a>
                                           <?php endif; ?>
                                            <?php if(Auth::user()->hasRole('SuperU') || Auth::user()->hasRole('Admin')): ?>
                                            <?php echo Form::open([
                                                'method' => 'DELETE',
                                                'url' => ['/admin/fichier', $item->id],
                                                'style' => 'display:inline'
                                            ]); ?>

                                                <?php echo Form::button('<i class="si si-trash" aria-hidden="true"></i>', array(
                                                        'type' => 'submit',
                                                        'class' => 'btn btn-danger btn-sm',
                                                        'title' => 'Supprimer Fichier',
                                                        'onclick'=>'return confirm("Voulez-vous supprimer cet enrégistrements ?")'
                                                )); ?>

                                            <?php echo Form::close(); ?>

                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if($fichier->count()==0): ?>
                                     <td class="text-center" colspan="8">
                                        Aucun enrégistrement disponible !<br>
                                        <?php if(!(isset($search) && $search!="")): ?>
                                         <a accesskey="n"  class="btn btn-sm btn-alt-secondary  border space-x-1" href="<?php echo e(url('/admin/fichier/create')); ?>">
                                            <i class="fa fa-plus opacity-50"></i>
                                            <span>Ajouter</span>
                                        </a> 
                                        <?php endif; ?>
                                     </td>
                                <?php endif; ?>
                                </tbody>
                            </table>
                            </div>
                            

                    </div>
                    <?php if($fichier->lastPage()>1): ?>
                        <div class="block-content block-content-full bg-body-light">
                            <?php echo e($fichier->appends(['search' => $search,'nb'=>isset($nb)?$nb:'',"order"=>isset($order)?$order:''])->links('vendor.pagination.custom')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cfpsdonboscobenin\resources\views/admin/fichier/index.blade.php ENDPATH**/ ?>