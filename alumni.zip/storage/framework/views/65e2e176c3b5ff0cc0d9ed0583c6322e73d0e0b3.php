<div class="form-group<?php echo e($errors->has('nom_prenom') ? 'has-error' : ''); ?>">
    <?php echo Form::label('nom_prenom', 'Nom et prénom', ['class' => 'control-label']); ?>

    <?php echo Form::text('nom_prenom', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('nom_prenom', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group<?php echo e($errors->has('photo') ? 'has-error' : ''); ?>">
    <?php echo Form::label('photo', 'Photo (Carrée)', ['class' => 'control-label']); ?>

    <?php echo Form::file('photo',  ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('photo', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group<?php echo e($errors->has('fonction') ? 'has-error' : ''); ?>">
    <?php echo Form::label('fonction', 'Fonction', ['class' => 'control-label']); ?>

    <?php echo Form::text('fonction', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('fonction', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group<?php echo e($errors->has('avis') ? 'has-error' : ''); ?>">
    <?php echo Form::label('avis', 'Avis', ['class' => 'control-label']); ?>

    <?php echo Form::textarea('avis', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('avis', '<p class="help-block">:message</p>'); ?>

</div>

<div class="form-group mb-4 <?php echo e($errors->has('etat') ? 'has-error' : ''); ?>">
    <?php echo Form::label('etat', 'Etat', ['class' => 'control-label']); ?>

    <div class="checkbox">
    <label><?php echo Form::radio('etat', '1'); ?> Activé</label>
</div>
<div class="checkbox">
    <label><?php echo Form::radio('etat', '0', true); ?> Désactivé</label>
</div>
    <?php echo $errors->first('etat', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <?php echo Form::submit($formMode === 'edit' ? 'Mettre à jour' : 'Enrégistrer', ['class' => 'btn btn-primary']); ?>

</div>
<?php /**PATH C:\laragon\www\cfpsdonboscobenin\resources\views/admin/avis/form.blade.php ENDPATH**/ ?>