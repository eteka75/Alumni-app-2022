

<?php $__env->startSection('title', 'Renseignements sur votre Profil et Formation'); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('storage/assets/web/vendor/cleave.js/dist/cleave.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="bg-white">
        <div class="container">
            <!-- Related posts carousel -->

            <div class="row justify-content-center_">
                <div class="col-md-12">
                    <div class="card border-0  _box-shadow">
                        <div class="card-body">

                            <div class="row ">
                                <div class="col-lg-3 col-sm-6 mb-4">
                                    <div class="media align-items-center ">
                                        <div class="bg-secondary rounded-circle border text-center"
                                            style="width: 60px; height: 60px; line-height: 54px;"><i
                                                class="fe-user-check font-size-xl text-muted"></i></div>
                                        <div class="media-body pl-3"><span class="badge badge-success badge-pill mb-1"><i
                                                    class="fe-check mr-1"></i>Effectué</span>
                                            <h6 class="text-muted mb-0">Création de compte</h6>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6">
                                    <div class="media align-items-center mb-4">
                                        <div class="rounded-circle border border-primary text-center"
                                            style="width: 60px; height: 60px; line-height: 54px;"><i
                                                class="fe-list font-size-xl text-primary_"></i></div>
                                        <div class="media-body pl-3"><span class="badge badge-primary badge-pill mb-1">En
                                                cours</span>
                                            <h6 class="text-primary mb-0">Profil et Formation</h6>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6">
                                    <div class="media align-items-center mb-4">
                                        <div class="rounded-circle border text-center"
                                            style="width: 60px; height: 60px; line-height: 54px;"><i
                                                class="fe-star font-size-xl"></i></div>
                                        <div class="media-body pl-3"><span
                                                class="d-block text-muted font-size-ms mb-1">Troisième étape</span>
                                            <h6 class="mb-0">Profession</h6>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6">
                                    <div class="media align-items-center mb-4">
                                        <div class="rounded-circle border text-center"
                                            style="width: 60px; height: 60px; line-height: 54px;"><i
                                                class="fe-package font-size-xl"></i></div>
                                        <div class="media-body pl-3"><span
                                                class="d-block text-muted font-size-ms mb-1">Quatrième étape</span>
                                            <h6 class="mb-0">Paramètres du compte</h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-10 col-xl-8 py-3  p-sm-4 mb-5 py-sm-5 rounded shadow-sm col-12 mx-auto">
                    <div class="card_p-5 box-shadowrounded mb-5">

                        <div class=" px-4">
                            <div class="text-center mb-4">
                                <h3 class="mb-0">Renseignements sur votre profil & formation </h3>
                               <small>Renseignez les informations sur votre profil et votre formation à l'UP</small>

                            
                            </div>
                            <?php if($errors->any()): ?>
                            <div class="alert alert-danger mb-4 text-sm">
                            <ul class="list-unstyled ">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($i+1); ?>- <?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                            <?php echo Form::open(['method' => 'POST', 'url' => request()->url(), 'class' => 'form-horizontal', 'files' => true]); ?>


                                <label class="text-uppercase text-muted"> Renseignez sur votre PROFIL</label>
                                <hr class="p-0 mb-4">
                                <!-- Text input -->
                                <label for="text-input">Photo de profil</label>
                                <div class="form-group">
                                    <div class="cs-file-drop-area">
                                        <div class="cs-file-drop-icon czi-cloud-upload">

                                            <div class="cs-file-drop-icon fe-upload"></div>
                                        </div>
                                        <span class="cs-file-drop-message">Déplacez et déposez votre photo ici</span>
                                        <input name="photo" id="photo" type="file" accept=".jpeg,.png,.jpg,.webp,.gif" class="cs-file-drop-input">
                                        <button type="button" class="cs-file-drop-btn btn btn-primary btn-sm">ou sélectionnez un fichier</button>
                                      </div>
                                      <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                               
                                <!-- Text input -->
                                <div class="form-group row">
                                    <div class="col-md-6 <?php echo e($errors->has('sexe') ? 'has-error' : ''); ?>">
                                        <label for="text-input">Sexe  (*)</label>
                                        <?php echo Form::select('sexe', [''=>"-Sélectionnez-",'M'=>'Masculin','F'=>'Féminin'], null,'required' == 'required' ? ['class' => 'form-control  custom-select rounded-1', 'required' => 'required'] : ['class' => 'form-control  custom-select']); ?>

                                 
                                        <?php $__errorArgs = ['sexe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                   </div>
                                    <div class="col-md-6 <?php echo e($errors->has('telephone') ? 'has-error' : ''); ?>">
                                        <label for="text-input">Numéro de téléphone  (*)</label>
                                        <input id="telephone" type="text" required name="telephone" placeholder="+229 97000000" value="<?php echo e(old('telephone')); ?>" class="form-control <?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"   autocomplete="telephone">
    
                                        <?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                  
                                   <div class="col-md-6 <?php echo e($errors->has('age') ? 'has-error' : ''); ?>">
                                    <label for="text-input">Votre âge actuel (*)</label>
                                    <input id="age" type="number" id="format-card-cvc" data-format="cvc" name="age" value="<?php echo e(old('age')); ?>" placeholder="25" class="form-control <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  required autocomplete="age">

                                    <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                   </div>
                                <div class="col-md-6 <?php echo e($errors->has('site_web') ? 'has-error' : ''); ?>">
                                    <label for="text-input">Site web </label>
                                    <input id="site_web" type="url" value="<?php echo e(old('site_web')); ?>" name="site_web" placeholder="https://www.monsiteweb.com/monprofil" class="form-control <?php $__errorArgs = ['site_web'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"   autocomplete="site_web">

                                    <?php $__errorArgs = ['site_web'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                </div>
                                <label class="text-uppercase d-block text-muted"> Renseignez sur votre formation</label>
                                <hr class="p-0 mb-4">
                                <!-- Text input -->
                                <div class="form-group row">
                                <div class="form-group col-md-6 <?php echo e($errors->has('annee_academique') ? 'has-error' : ''); ?>">
                                    <label for="text-input">Année académique </label>
                                    <input id="annee_academique" value="<?php echo e(old('annee_academique')); ?>" data-format="custom" data-delimiter="-" data-blocks="4 4"  type="text" name="annee_academique" placeholder="<?php echo e(date('Y')-5); ?>-<?php echo e(date('Y')-6); ?>" class="form-control <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  required autocomplete="annee_academique">
                                    
                                    <?php $__errorArgs = ['annee_academique'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                               
                                <div class="col-md-6 <?php echo e($errors->has('etablissement_id') ? 'has-error' : ''); ?>">
                                    <label for="text-input">Etablissement principale (*)</label>
                                    
                                    <?php echo Form::select('etablissement_id', isset($etablissements)?($etablissements):[''=>"Choisir établissement"], null,'required' == 'required' ? ['class' => 'form-control  custom-select rounded-1', 'required' => 'required'] : ['class' => 'form-control  custom-select']); ?>

                                    <?php $__errorArgs = ['etablissement_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="col-md-6 <?php echo e($errors->has('filiere_id') ? 'has-error' : ''); ?>">
                                    <label for="filiere_id">Filière (*)</label>
                                    <?php echo Form::select('filiere_id', isset($filieres)?($filieres):[''=>'Choisir filière'], null,'required' == 'required' ? ['class' => 'form-control  custom-select rounded-1', 'required' => 'required'] : ['class' => 'form-control  custom-select']); ?>

                                    
                                    <?php $__errorArgs = ['filiere_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 <?php echo e($errors->has('diplome') ? 'has-error' : ''); ?>">
                                    <label for="text-input">Diplôme (*)</label>
                                    <div>
  
                                        <!-- Inline radio buttons -->
                                        <div class="custom-control custom-radio custom-control-inline">
                                            <input class="custom-control-input" <?php echo e(old('diplome')=='LICENCE'?"checked":''); ?>  value="LICENCE" type="radio" id="ex-radio-4" name="diplome" required>
                                            <label class="custom-control-label" for="ex-radio-4">LICENCE</label>
                                        </div>
                                        <div class="custom-control custom-radio custom-control-inline">
                                            <input class="custom-control-input" <?php echo e(old('diplome')=='MASTER'?"checked":''); ?> value="MASTER" type="radio" id="ex-radio-5" name="diplome" required>
                                            <label class="custom-control-label" for="ex-radio-5">MASTER</label>
                                        </div>
                                        <div class="custom-control custom-radio custom-control-inline">
                                            <input class="custom-control-input" <?php echo e(old('diplome')=='DOCTORAT'?"checked":''); ?>  value="DOCTORAT" type="radio" id="ex-radio-6" name="diplome" required>
                                            <label class="custom-control-label" for="ex-radio-6">DOCTORAT</label>
                                        </div>
                                        <div class="custom-control custom-radio custom-control-inline">
                                            <input class="custom-control-input" <?php echo e(old('diplome')=='AUTRE'?"checked":''); ?>  value="AUTRE" type="radio" id="ex-radio-7" name="diplome" required>
                                            <label class="custom-control-label" for="ex-radio-7">AUTRE</label>
                                        </div>
                                        </div>
                                    <?php $__errorArgs = ['diplome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    
                                </div>
                                </div>

                                <!-- Textarea -->
                                <div class="form-group <?php echo e($errors->has('theme_memoire') ? 'has-error' : ''); ?>">
                                    <label for="theme_memoire">Thème de mémoire</label>
                                    <textarea class="form-control" name="theme_memoire" id="theme_memoire" rows="5"><?php echo old('theme_memoire'); ?> </textarea>
                                    <?php $__errorArgs = ['theme_memoire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="row mb-0">
                                    <div class="col-md-12 offset-md-0">
                                        <button type="submit" class="btn d-sm-inlin d-block btn-primary">
                                            <?php echo e(__('Sauvegarder')); ?>

                                        </button>


                                    </div>
                                </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\2022\alumni\resources\views/auth/enregistrement1.blade.php ENDPATH**/ ?>