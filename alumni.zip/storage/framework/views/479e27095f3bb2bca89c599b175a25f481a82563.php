<div class="form-group<?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
    <?php echo Form::label('title', 'Title', ['class' => 'control-label']); ?>

    <?php echo Form::text('title', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('title', '<p class="help-block">:message</p>'); ?>

</div>
<?php if($formMode === 'edit'): ?>
<div class="form-group<?php echo e($errors->has('slug') ? 'has-error' : ''); ?>">
    <?php echo Form::label('slug', 'Slug', ['class' => 'control-label']); ?>

    <?php echo Form::text('slug', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('slug', '<p class="help-block">:message</p>'); ?>

</div>
<?php endif; ?>
<div class="form-group<?php echo e($errors->has('image') ? 'has-error' : ''); ?>">
    <?php echo Form::label('image', 'Image', ['class' => 'control-label']); ?>

    <?php echo Form::file('image', ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    <?php echo $errors->first('image', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group mb-2 <?php echo e($errors->has('content') ? 'has-error' : ''); ?>">
    <?php echo Form::label('content', 'Content', ['class' => 'control-label']); ?>

    <?php echo Form::textarea('content', null, ['class' => 'form-control crud-richtext']); ?>

    <?php echo $errors->first('content', '<p class="help-block">:message</p>'); ?>

</div>
<div class="row clearfix form-group mb-4<?php echo e($errors->has('etat') ? 'has-error' : ''); ?>">
    <?php echo Form::label('etat', 'Activé', ['class' => 'float-start d-flex flex _control-label']); ?> 
    
    <div class="checkbox  col-sm-2 col-md-1">
    <label><?php echo Form::radio('etat', '1'); ?> Oui</label>
</div>
<div class="checkbox col-sm-3 col-md-1">
    <label><?php echo Form::radio('etat', '0', true); ?> Non</label>
</div>
    <?php echo $errors->first('etat', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group mt-4 mb-2">
    <?php echo Form::submit($formMode === 'edit' ? 'Mettre à jour' : 'Enrégistrer', ['class' => 'btn btn-primary']); ?>

</div>
<?php /**PATH C:\laragon\www\cfpsdonboscobenin\resources\views/admin/pages/form.blade.php ENDPATH**/ ?>