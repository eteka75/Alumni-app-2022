@extends('layouts.web')

@section('title', 'Annuaires')

@section('sidebar')
    <section class="breadcrumb-section py-5">
        <div class="container">
            <h2 class="h2">{{ 'Annuaires' }}</h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('Index')}}">Accueil</a></li>
                <li class="breadcrumb-item">Annuaires</li>
            </ol>
        </div><!-- /.container -->
    </section> 
    
@endsection

@section('content')

  
  <!-- Team-->
  <section class="container mb-5 pb-3 pb-lg-0 mb-lg-7">
    @if(isset($content))
    {!! $content !!}
    @endif
  </section>
  <!-- Clients-->
  
@endsection