@extends('layouts.web')

@section('title', 'Opportunités')

@section('sidebar')
    <section class="breadcrumb-section py-5">
        <div class="container">
            <h2 class="h2">{{ 'Opportunités' }}</h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('Index')}}">Accueil</a></li>
                <li class="breadcrumb-item">Opportunités</li>
            </ol>
        </div><!-- /.container -->
    </section> 
    
@endsection

@section('content')


@endsection