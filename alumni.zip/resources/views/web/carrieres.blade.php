@extends('layouts.web')

@section('title', 'Carrières')

@section('sidebar')
    <section class="breadcrumb-section py-5">
        <div class="container">
            <h2 class="h2">{{ 'Carrières' }}</h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('Index')}}">Accueil</a></li>
                <li class="breadcrumb-item">Carrières</li>
            </ol>
        </div><!-- /.container -->
    </section> 
    
@endsection

@section('content')
<section class="bg- py-5 mt-n4 mb-6 mt-lg-0 mb-lg-7">
   
  </section>
  <!-- Team-->

@endsection