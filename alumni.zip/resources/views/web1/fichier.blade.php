@extends('layouts.web')

@section('title', isset($data,$data['titre'])?$data['titre']:'Fichier')

@section('sidebar')
    @parent

    <section class="breadcrumb-section">
        <div class="container">
            <h1>{{ isset($data,$data['titre'])?$data['titre']:'Fichiers' }}
                <a href="{{ url($data->fichier) }}" class="btn btn-secondary btn-xs py-1 mt2 float-end" target="_blanck"><i class="fa fa-file-download"></i> Télécharger</a>
            </h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('Index')}}">Accueil</a></li>
                <li class="breadcrumb-item"><a href="{{route('fichiers-a-telecharger')}}">Fichiers téléchargeables</a></li>
                <li class="breadcrumb-item">{{ isset($data,$data['titre'])?$data['titre']:'Formation' }}</li>
            </ol>
        </div><!-- /.container -->
    </section> 
    
@endsection

@section('content')
<div class="sg-section">
    <div class="section-content course-details bg-white section-padding_ py-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="sa-course_">
                        <div class="course-thumb">
                            @isset($data,$data['image'])
                            <img src="{{ asset(isset($data,$data['image'])?$data['image']:'') }}" alt="Image" class="img-fluid">
                            @endif
                        </div>
                        <div class="course-info_ p-0 mb-4">
                        
                            {!! isset($data,$data['description'])?$data['description']:'-' !!}
                           
                        </div>
                    </div><!-- /.sa-course -->  
                    <hr class="my-4">
                    @if(isset($datas))
                    <div class="row">
                    @foreach($datas as $key => $d)
                    <div class="row border col-md-6 mx-1 shadow-sm mb-4">
                        <div class="col-12 col-sm-12 col-md-12">
                            <div class="sa-courses">                             

                                <div class="course-info_ px-2 py-3">
                                    <div class="info">
                                        <div><a href="{{ url($d->fichier) }}" class="btn btn-primary btn-xs py-1 mt2 float-end" target="_blanck"><i class="fa fa-file-download"></i> Télécharger</a></div>
                                        @isset($d->site)                                                
                                        <span class="badge bg-secondary rounded-pill">{{ $d->format}}</span>   <br>
                                        @endisset
                                        <h5 class="title fs-sm my-1"><a href="{{ route('fichier',($d->slug!="")?$d->slug:$d->id) }}">{{ $d->titre }}</a></h5>
                                        <h2 class="entry-title_ h6 text-muted fw-normal fs-xs"><a href="{{ route('fichier',($d->slug!="")?$d->slug:$d->id) }}">{!!  isset($d->description)? substr(strip_tags($d->description),0,300):'' !!}... </a></h2>
                                    </div>
                                </div><!-- /.course-info -->
                            </div><!-- /.sg-course -->                                      
                        </div>
                    </div>
                    @endforeach
                </div>
                        @endif                         
                </div>
                <div class="col-lg-4">
                   @include('includes.right')
                </div>
            </div><!-- /.row -->
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div>
@endsection