@extends('layouts.web')

@section('title',isset($data,$data['titre'])?"Communiqué : ".$data['titre']:'Communiqués')

@section('sidebar')
    @parent
    <section class="breadcrumb-section">
        <div class="container">
            <h1><span class="text-success">Communiqué : </span>{{ isset($data,$data['titre'])?$data['titre']:'-' }}</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('Index')}}">Accueil</a></li>
                <li class="breadcrumb-item"><a href="{{route('communiques')}}">Communiqués</a></li>
                <li class="breadcrumb-item">{{ isset($data,$data['titre'])?$data['titre']:'Communiqués' }}</li>
            </ol>
        </div><!-- /.container -->
    </section> 
    
@endsection

@section('content')
<div class="sg-section">
    <div class="section-content course-details bg-white section-padding_ py-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="sa-course_">
                        <div class="course-thumb">
                            @isset($data,$data['image'])
                            <img src="{{ asset(isset($data,$data['image'])?$data['image']:'') }}" alt="Image" class="img-fluid">
                            @endif
                        </div>
                        <div class="course-info_ p-0 mb-4">
                            {!! $data->contenu !!}
                              
                        </div>
                    </div><!-- /.sa-course -->  
                    <hr class="my-4">
                    @if(isset($datas))
                    <div class="row">
                    @foreach($datas as $key => $d)
                    <div class="col-md-6 ">
                    <div class="row border mx-1 rounded-3 shadow-sm mb-2">
                        <div class="col-12 col-sm-12">
                            <div class="sa-courses">                             

                                <div class="course-info_  h-100 px-2 py-3">
                                    <div class="info">
                                        <h5 class="title fs-sm mt-0"><a href="{{ route('communique',($d->slug!="")?$d->slug:$d->id) }}">{{ $d->titre }}</a></h5>
                                       <small class="text-muted">
                                           {{ substr(strip_tags($d->contenu),0,100) }}
                                       </small>
                                    </div>
                                </div><!-- /.course-info -->
                            </div><!-- /.sg-course -->                                      
                        </div>
                    </div>
                    </div>
                    @endforeach
                </div>
                        @endif                         
                </div>
                <div class="col-lg-4">
                   @include('includes.right')
                </div>
            </div><!-- /.row -->
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div>
@endsection