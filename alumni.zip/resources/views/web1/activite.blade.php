@extends('layouts.web')

@section('title', isset($data,$data['titre'])?$data['titre']:'Activité')

@section('sidebar')
    @parent

    <section class="breadcrumb-section">
        <div class="container">
            <h1>{{ isset($data,$data['titre'])?$data['titre']:'Activité' }}</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('Index')}}">Accueil</a></li>
                <li class="breadcrumb-item"><a href="{{route('activites')}}">Activités</a></li>
                <li class="breadcrumb-item">{{ isset($data,$data['titre'])?$data['titre']:'Activité' }}</li>
            </ol>
        </div><!-- /.container -->
    </section> 
    
@endsection

@section('content')
<div class="sg-section">
    <div class="section-content course-details bg-white section-padding_ py-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="sa-course_">
                        <div class="course-thumb">
                            @isset($data,$data['image'])
                            <img src="{{ asset(isset($data,$data['image'])?$data['image']:'') }}" alt="Image" class="img-fluid">
                            @endif
                        </div>
                        <blockquote class="py-2 border-start-3 ps-3 fs-5 bold border mt-3 font-weight-bold">
                            {!! isset($data,$data['resume'])?$data['resume']:'-' !!}
                        </blockquote>
                        <div class="course-info px-2 fs-5 ">
                            {!! isset($data,$data['contenu'])?$data['contenu']:'-' !!}
                           
                        </div>
                    </div><!-- /.sa-course -->                           
                </div>
                <div class="col-lg-4">
                    
                   @include('includes.right')
                </div>
            </div><!-- /.row -->
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div>
@endsection