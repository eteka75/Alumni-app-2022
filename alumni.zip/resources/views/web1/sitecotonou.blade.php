@extends('layouts.web')

@section('title', isset($data,$data['title'])?$data['title']:'Site de Cotonou')

@section('sidebar')
    @parent

    <section class="breadcrumb-section">
        <div class="container">
            <h1>{{ isset($data,$data['title'])?$data['title']:'Site de Cotonou' }}</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('Index')}}">Accueil</a></li>
                <li class="breadcrumb-item">{{ isset($data,$data['title'])?$data['title']:'Site de Cotonou' }}</li>
            </ol>
        </div><!-- /.container -->
    </section> 
    
@endsection

@section('content')
<div class="sg-section">
    <div class="section-content course-details bg-white section-padding_ py-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="sa-course_">
                        <div class="course-thumb">
                            @isset($data,$data['image'])
                            <img src="{{ asset(isset($data,$data['image'])?$data['image']:'') }}" alt="Image" class="img-fluid">
                            @endif
                        </div>
                        <div class="course-info">
                            {!! isset($data,$data['content'])?$data['content']:'-' !!}
                           
                        </div>
                    </div><!-- /.sa-course -->                           
                </div>
                <div class="col-lg-4">
                   @include('includes.right')
                </div>
            </div><!-- /.row -->
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div>
@endsection