<!DOCTYPE html>
<html lang="fr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Fiche de pré-inscription de {{ isset($etu)?$etu->nom." ".$etu->prenom:'fiche' }}</title>
    <style type="text/css">
    body{
        font-family: "helvetica",'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        font-size: 15px;
    }
        .table_inscription tr td, .table_inscription tr th, .table_inscription td,  .table_inscription tr>td, .table_inscription{
            border-collapse: collapse;
            padding: 0px;
        }
        .table_inscription{
            margin: auto;
            border:1px solid #999999;
            width: 100%;
            border-radius: 5px;
        }
        .btn-gray-200{
            background: #999999
        }
        .table_inscription .right{
            text-align: right;
            padding: 10px 20px;
            width:49% ;
        }
        .table_inscription .left{
            text-align: left
        }
        .centrer{
            text-align: center;
        }
        .capitalize{
            text-transform: capitalize;
        }
        .bge{
            background: #EEEEEE;
        }
        .u_photo{
            height: 65px;
            max-width: 200px;
            border: 4px solid #ffffff;
            border-radius: 10px;
            background: #ffff;
            padding: 5px;
            
        }
        .message{
            padding: 11px;
            display: block;
            font-size: 10px;
            color: #444444;
            background: #EEEEEE
        }
        .bold{
            font-weight: bold;
            text-transform: uppercase
        }
        .pad10{padding: 5px 15px;display: block; font-size: 12px; font-weight:bold }
    </style>
</head>
<body>
    @if(isset($etu) && $etu )
    <table class="table_inscription">
        <tr>
            <td colspan="2" class="centrer">
                <br>
                <br>
                <span class="bold">République du Bénin</span><br>
                ----------------<br>
                <span class="bold">Ministère des Enseignements Secondaires Technique et de la Formation Professionelle (MESTFP)</span><br>
                --------<br>
                <div class="">{{ config('app.nom_centre') }}</div>
                ----
               
                    
            </td>
        </tr>
        <tr>
            <th colspan="2" class="centrer bge" >
                <br>
                <br>
                <div>FICHE DE PRE-INSCRIPTION N° : {{ $etu->code }} </div>
                <br>
                <!--img src="{{ asset($etu->photo) }}" alt="{{ $etu->nom }}"  class="u_photo">
           <br-->
           <br>
            </th>
        </tr>
        <tr>
            <th class="right">Nom : </th>
            <td>{{ $etu->nom }}</td>
        </tr>
        <tr>
            <th class="right">Prénom : </th>
            <td>{{ $etu->nom }}</td>
        </tr>
        
        <tr>
            <th class="right">Sexe : </th>
            <td>{{ $etu->sexe=="M"?"Masculin":"Féminin" }}</td>
        </tr>
        <tr>
            <th class="right">Date et lieu de naissance : </th>
            <td>{{ date('d/m/Y', strtotime($etu->date_naissance)) }} à {{ $etu->lieu_naissance }}</td>
        </tr>
        <tr>
            <th class="right">Filière : </th>
            <td>{{ $etu->formation?$etu->formation->titre:'-' }}</td>
        </tr>
        <tr>
            <th class="right">Classe : </th>
            <td>{{ $etu->classe }}</td>
        </tr>

        <tr>
            <th class="right">Téléphone : </th>
            <td>{{ $etu->contact?$etu->contact:'-' }}</td>
        </tr>
        <tr>
            <th class="right">Email : </th>
            <td>{{ $etu->email?$etu->email:'-' }}</td>
        </tr>
        
        <tr>
            
            <td colspan="2">
                <small class="message">Cette fiche témoigne que vous vous êtes inscrit sur la site de notre centre formation {{ config('app.nom_centre') }}.
                <br>
               <b> DOSSIER A FOURNIR POUR LE TEST D’ENTREE :</b><br> 
- Fiche d’inscription à remplir au secrétariat de l’école<br>
- Les bulletins de la dernière classe<br>
- 01 photo d’identité<br>
- Droit d’inscription au test d’entrée<br>
• Garçon : 5.000 F<br>
• Fille : 3.000 F <br>
Les admis au test d’entrée doivent finaliser leur inscription dans la semaine suivant la proclamation des résultats en s’acquittant :<br>
- Des frais généraux<br>
- Des frais d’atelier<br>
- De la 1re tranche de la scolarité<br>
             </small>
             <br>
             
            </td>
        </tr>
        <tr>
            <td>
                
            </td>
            <td>
                Fait à ........................., le ......./......./{{ date('Y') }}
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <small class="pad10">Inscription effectuée le {{ date('d/m/Y à H\h:i\m s\s',strtotime($etu->created_at)) }}</small>
           
            <br>
            </td>
        </tr>
        
    </table>
    @endif
</body>
</html>