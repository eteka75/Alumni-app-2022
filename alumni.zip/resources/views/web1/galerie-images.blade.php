@extends('layouts.web')

@section('title', 'Galerie Images du CPET DON BOSCO '.config('app.site'))

@section('sidebar')
    @parent

    <section class="breadcrumb-section">
        <div class="container">
            <h1>Galerie Images</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('Index')}}">Accueil</a></li>
                <li class="breadcrumb-item">Galerie Images</li>
            </ol>
        </div><!-- /.container -->
    </section>    
    @section('scripts')
    <link rel="stylesheet" href="{{ asset('/storage/vendor/lightbox/css/lightbox.css') }}">
    
    <script src="{{ asset('/storage/vendor/lightbox/js/lightbox.js') }}"></script>
    @endsection
    @section('content')

    <div class="sg-section">
        <div class="section-content course-details bg-white section-padding_ py-4">
            <div class="container">
                <div class="row p-3">
                <div class="col-md-8  col-12 col-xl-8">
                    <div class="row ">
                    @foreach($datas as $key => $d)
                        @if($d->image && $d->image!="")
                        <div class="col-12  col-sm-4 px-0 col-lg-3  mb-1">
                            <div class="course-thumb">
                                
                                <a href="{{ asset($d->image) }}" data-lightbox="image-1" data-title="{{$d->titre .'-'.$d->description }}"> 
                                    <img src="{{ asset($d->image) }}" alt="{{$d->titre }}" class="img-fluid mx-1">
                                </a>
                            </div><!-- /.course-thumb -->
                        </div>
                        @endif
                        @endforeach
                    </div>
                    <div class="sg-pagination float-end  px-1 ">
                        {{ $datas->links() }}
                    </div> 
                </div>
                <div class="col-lg-4">
                    
                    @include('includes.right')
                 </div>
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.section-content -->
    </div>
    @endsection
    
@endsection

@section('content')

@endsection