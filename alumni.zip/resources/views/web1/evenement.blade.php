@extends('layouts.web')

@section('title', isset($data,$data['titre'])?$data['titre']:'Evènement')

@section('sidebar')
    @parent

    <section class="breadcrumb-section">
        <div class="container">
            <h1>{{ isset($data,$data['titre'])?$data['titre']:'Evènement' }}</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('Index')}}">Accueil</a></li>
                <li class="breadcrumb-item">{{ isset($data,$data['titre'])?$data['titre']:'Evènement' }}</li>
            </ol>
        </div><!-- /.container -->
    </section> 
    
@endsection

@section('content')
<div class="sg-section">
    <div class="section-content course-details bg-white section-padding_ py-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="sa-course_">
                        <div class="course-thumb">
                            @isset($data,$data['photo'])
                            <img src="{{ asset(isset($data,$data['photo'])?$data['photo']:'') }}" alt="Image" class="img-fluid">
                            @endif
                        </div>
                        <div class="course-info_ p-0 mb-4">
                            <h4 class="py-0 mb-1 ">Conditions</h4>
                            
                           <hr class="py-1 mt-0">
                           <div class="card_">
                                <div class="card-body">
                                    {!! isset($data,$data['conditions'])?$data['conditions']:'-' !!}
                                </div>
                           </div>
                           <h4 class="py-0 mb-1 ">Débouchés</h4>
                           <hr class="py-1 mt-0">
                           <div class="card_">
                                <div class="card-body">
                                    {!! isset($data,$data['debouches'])?$data['debouches']:'-' !!}
                                </div>
                           </div>
                           <h4 class="py-0 mb-1 ">Description</h4>
                           <hr class="py-1 mt-0 mb-1">
                            {!! isset($data,$data['description'])?$data['description']:'-' !!}
                           
                        </div>
                    </div><!-- /.sa-course -->  
                    <hr class="my-4">
                    @if(isset($datas))
                    <div class="row">
                    @foreach($datas as $key => $d)
                    <div class="col-md-12 ">
                    <div class="row border_ py-1 mx-1 mb-4 border-bottom">
                        <div class="col-12 col-sm-4 col-md-3 p-0">
                            <div class="course-thumb">
                                
                                <a href="{{ route('evenement',$d->id) }}"> 
                                    @if($d->photo && $d->photo!="")
                                    <img src="{{ asset($d->photo) }}" alt="{{$d->titre }}" class="img-fluid">
                                    @else
                                    <img src="{{ asset('assets/images/cpet/actualite-default.jpg') }}" alt="{{$d->titre }}" class="img-fluid">
                                    @endif
                                    </a>
                            </div><!-- /.course-thumb -->
                        </div>
                        <div class="col-12 col-sm-8 col-md-9">
                            <div class="sa-courses">                             

                                <div class="course-info_ px-2 py-3">
                                    <div class="info">
                                        
                                        <h5 class="title fs-sm mt-1"><a href="{{ route('evenement',($d->slug!="")?$d->slug:$d->id) }}">{{ $d->titre }}</a></h5>
                                        <ul class="list-inline mt-3pt-2 text-muted  h6 border-top_">
                                            <li class="list-inline-item"><small><i>DATE : {{ date('d/m/Y H:i',strtotime($d->date)) }}</i></small></li>
                                            <li class="list-inline-item"><small><i>LIEU : {{ $d->lieu }}</i></small></li>
                                        </ul>
                                        <h2 class="entry-title_ h6 text-muted fw-normal fs-xs"><a href="{{ route('evenement',($d->slug!="")?$d->slug:$d->id) }}">{!!  isset($d->description)? substr(strip_tags($d->description),0,200):'' !!}... </a></h2>
                                       
                                    </div>
                                </div><!-- /.course-info -->
                            </div><!-- /.sg-course -->                                      
                        </div>
                    </div>
                    </div>
                    @endforeach
                </div>
                        @endif                         
                </div>
                <div class="col-lg-4">
                   @include('includes.right')
                </div>
            </div><!-- /.row -->
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div>
@endsection