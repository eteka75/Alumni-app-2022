@extends('layouts.web')

@section('title', "Pré-inscription des apprenants")

@section('sidebar')
    @parent

    <section class="breadcrumb-section">
        <div class="container">
            <h1>Pré-inscription des apprenants</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('Index') }}">Accueil</a></li>
                <li class="breadcrumb-item">Inscription des apprenants</li>
            </ol>
        </div><!-- /.container -->
    </section>

@endsection

@section('content')
<style>
    .has-error label,.help-block{        
        color:  rgb(220,53,69);
    }
    .help-block{
        font-size: small;
        margin-bottom: 0px;
    }
</style>

    <div class="sg-section">
        <div class="section-content course-details bg-white section-padding_ py-4">
            <div class="container">
                <div class="row">
                        <div class="col-lg-8">
                            <div class="card-body">
                                
        
                                @if ($errors->any())
                                    <ul class="alert list-unstyled alert-danger">
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                @endif
        
                                {!! Form::open(['url' => '/inscription', 'class' => 'form-horizontal', 'files' => true]) !!}
        
                                @include ('includes.inscription-form', ['formMode' => "S'inscrire"])
        
                                {!! Form::close() !!}
        
                            </div>
                        </div>
                        <div class="col-lg-4">
                            @include('includes.right')
                        </div>
                    </div><!-- /.row -->
                </div><!-- /.container -->
            </div><!-- /.section-content -->
        </div>
    @endsection
