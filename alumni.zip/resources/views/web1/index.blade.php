@extends('layouts.web')

@section('title', 'Accueil')

@section('sidebar')
    @parent

@endsection

@section('content')
@if(isset($slides) && $slides->count() )
@php
    $n=$i=0;
@endphp
<div id="hero-slider" class="carousel slide hero-content" data-bs-ride="carousel">
    <div class="carousel-inner">
        @foreach($slides as $key => $slide)
        @php
            $t=$slide->titre;
            $tab_t=explode(" ",$t);
            $nb=count($tab_t);
           
            if($nb>1){
                
                $titre="";
                foreach ($tab_t as  $k=>$value) {
                    if($k==$nb-1){
                        $titre.=" <span>".$value."</span>";
                    }else{
                        $titre.=" ".$value;
                    }
                }
            }else{
                $titre=$t;
            }
        @endphp
        <div class="carousel-item text-center {{ $n++==0?'active':'' }}">
            <div class="carousel-item-content section-before"  style="background-image: url({{ asset($slide->image) }});">
                <div class="container">
                    <div class="hero-text">
                        <h1 data-animation="animated fadeInDown">{!! $titre !!} </h1>
                        <p data-animation="animated fadeInDown">{{ $slide->sous_titre }}</p>
                        <!--div class="buttons">
                            <a href="#" class="btn btn-primary"  data-animation="animated fadeInRight">Nos diplomés</a>
                            <a href="#" class="btn btn-white"  data-animation="animated fadeInLeft">En savoir plus</a>
                        </div-->
                    </div><!-- /.hero-text -->
                </div><!-- /.container -->
            </div><!-- /.carousel-item-content -->
        </div>
        @endforeach
        

    </div><!-- /.carousel-inner -->

    <div class="carousel-indicators">
        @foreach($slides as $s)
        <button type="button" data-bs-target="#hero-slider" data-bs-slide-to="{{ $i++ }}" class="{{ $i==1?'active':'' }}" aria-current="{{ $i==1?'true':'' }}" aria-label="{{ $s->trire }}"></button>
        @endforeach
    </div>

    <button class="carousel-control-prev" type="button" data-bs-target="#hero-slider" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#hero-slider" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div><!-- /#hero-slider -->
@endif
@if(isset($mot) && $mot->count())

<div class="sa-section py-5" >
    <div class="section-content sa-about">
        <div class="container">
            <div class="row">
                
                <div class="col-lg-6 order-md-1_ order-2 order-lg-1 align-self-center">
                    <div class="section-header">
                        <div class="title">
                            <h1>Mot de Bienvenue</h1>
                            <span>Mot de bienvenue</span>
                        </div>
                    </div>
                    <div class="about-info fs-5">
                        <h2 class="h4">{{ $mot->title }}</h2>
                        {!!  isset($mot)? substr(strip_tags($mot->content),0,650):'' !!}...
                        <br>
                        <a href="{{ route("page",$mot->slug) }}" class="btn btn-primary btn-sm mt-3">En savoir plus  <i class="fa fa-arrow-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-6 order-1 _order-sm-2">
                    @if($mot->image && $mot->image!='')
                    <div class="about-thumb">
                        <a href="{{ route("page",$mot->slug) }}"> <img src="{{ asset($mot->image) }}" alt="{{ $mot->title }}" class="img-fluid"></a>
                    </div>
                    @endif
                </div>
            </div>
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div>
    
@endisset


@if(isset($formations) && $formations->count())
<div class="sa-section bg-white mb-4 bg_actu__bg-secondary bg-white border-top_ bg-black-10shadow-sm py-5">
    <div class="section-content py-2">
        <div class="container">
            <div class="section-header justify-content-between">
                <div class="title">
                    <h1>Nos domaines de formation</h1>
                    <span>Nos domaines</span>
                </div>
                <div class="view-all align-self-center">
                    <a href="{{ route('formations') }}" class="btn btn-primary">Voir tout</a>
                </div>
            </div><!-- /.section-header -->

            <div class="sg-category-content row">
                @foreach($formations as $key => $f)
                <div class="col-sm-6 col-12 col-xl-4 mb-3 px-1">
                <div class=" cardborder-1_ shadow-sm h-100 rounded-2">
                <div class="row">
                    @php
                        $d=$f;
                    @endphp
                     <div class="course-thumb col-md-6 col-xl-5  col-sm-6 col-12">
                                
                        <a href="{{ route('formation',$d->id) }}"> 
                            @if($d->image && $d->image!="")
                            <img src="{{ asset($d->image) }}" alt="{{$d->titre }}" class="img-fluid">
                            @else
                            <img src="{{ asset('assets/images/cpet/actualite-default.jpg') }}" alt="{{$d->titre }}" class="img-fluid">
                            @endif
                            </a>
                    </div>
                    <div class="col-md-6 col-xl-7 col-sm-6 col-12 px-1">
                       <!-- /.course-thumb -->
                        <div class="py-3 ps-3 ps-sm-0 pe-3 h-100 ">
                            <a href="{{ route('formation',$f->slug?$f->slug:$f->id) }}">
                                <!--span class="icon">
                                    <i class="fas fa-desktop"></i>
                                </span-->
                                <div>
                                    <h5 class="mb-0" title="{{ $f->titre }}">{{ substr($f->titre,0,35) }}{{ strlen($f->titre)>35?'...':'' }}</h5>

                                </div>
                                <div class="py-1">
                                    <small class="text-muted">{!! substr(strip_tags($f->description),0,90) !!} ...<span class="text- bold font-weight-bold">[lire la suite]</span></small>
                                </div>
                            </a>
                        </div><!-- /.sg-category -->
                    </div>
                </div>
                </div>
                </div><!-- /.row -->
                    @endforeach
                    
            </div><!-- /.sg-category-content -->
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div><!-- /.sa-section -->
@endif
<div class="sa-section bg-darkens ">
    @php
        $bg = "assets/images/bg/bg-".strtolower(config('app.site')).".jpg"
    @endphp
    <div class="section-content sa-about style-1 section-padding jarallax" style="background-image: none;" data-jarallax-original-styles="background-image: url({{ asset($bg) }});">
        <div class="container">
            <div class="row">
                <div class="col-lg-6  py-3">
                    <img src="{{ asset($bg) }}" alt="Image" class="img-fluid rounded-3 shadow-lg">
                    
                </div>
                <div class="col-lg-6  py-3 offset-lg-6_">
                    <div class="section-header">
                        <div class="title">
                            <h1>Nos domaines de formation</h1>
                            <span>Formation</span>
                        </div>
                    </div>
                    <div class="about-info">
                        <h2>Nous formons pour l'emploi et l'auto-emploi</h2>
                        <p>«L’école doit former aussi bien pour l’emploi
                            que pour la fonction publique et le secteur
                            privé» (Article 9 de la Loi d’Orientation de
                            l’Education Nationale»</p>
                            <p><b>«Il suffit que vous soyez jeunes pour que je
                            vous aime beaucoup» DON BOSCO</b></p>
                            @if(isset($formations) && $formations->count())
                        <ul class="global-list">
                            @foreach($formations as $key => $f)
                            <li> <a class="read-more"   href="{{ route('formation',$f->id) }}"> {{ $f->titre }}</a></li>
                            @endforeach
                        </ul>
                        @endif
                        <a href="{{ route('formations') }}" class="btn bg-darkens text-white te  mt-2"> Toutes nos formations <span><i class="fa fa-chevron-right"></i></span></a>
                    </div>
                </div>
            </div>
        </div><!-- /.container -->
    <div id="jarallax-container-0" style="position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; overflow: hidden; z-index: -100;"><div style="background-position: 50% 50%; background-size: cover; background-repeat: no-repeat;  position: fixed; top: 0px; left: 0px; width: 1452px; height: 357.64px; overflow: hidden; pointer-events: none; transform-style: preserve-3d; backface-visibility: hidden; will-change: transform, opacity; margin-top: -31.82px; transform: translate3d(0px, 68.6625px, 0px);"></div></div></div><!-- /.section-content -->
</div>
@if(isset($activites) && $activites->count())
<div class="sa-section py-5 ">
    <div class="section-content section-padding padding-top-0 py-2">
        <div class="container">
            <div class="section-header text-center justify-content-between">
                <div class="title align-self-center">
                    <h1>Nos activités</h1>
                    <span>Activités</span>
                </div>
                <div class="view-all align-self-center">
                    <a href="{{ route('activites') }}" class="btn btn-primary">Voir Tout</a>
                </div>
            </div><!-- /.section-header -->

            <div class="sa-course-content">
                <div class="sa-course-sliders row">
                    @foreach($activites as $act)
                    @php
                        $data=$act
                    @endphp
                     <div class="col-lg-4  col-md-4 col-sm-6 col-12">
                        <div class="sa-post border-1">
                            <div class="entry-header">
                                <div class="entry-thumbnail">
                                    <a href="{{ route('activite',$data['slug']) }}"> 
                                    @if($act->image && $act->image!="")
                                    <img src="{{ asset($act->image) }}" alt="{{ $act->titre }}" class="img-fluid">
                                    @else
                                    <img src="{{ asset('assets/images/cpet/actualite-default.jpg') }}" alt="{{ $act->titre }}" class="img-fluid">
                                    @endif
                                    </a>
                                </div>
                                <div class="entry-meta">
                                    <a href="{{ route('activite',$data['slug']) }}">{{ date('d',strtotime($data['created_at'])) }} <span>{{ date('M.y',strtotime($data['created_at'])) }} </span></a>
                                </div>   
                            </div>                               
                            <div class="entry-content">  
                                @isset($data['site'])                                                
                                @endisset
                               <a href="{{ route('categorie',$data->categorie?$data->categorie->id:'-') }}"> <span class="badge bg-danger mt-n3 float-end rounded-pill">{{  isset($data->categorie)?$data->categorie->nom:''}}</span> </a>  <br>
                                <h2 class="entry-title_ h6"><a href="{{ route('activite',$data['slug']) }}">{{ $data['titre'] }} </a></h2>
                                
                                <a class="read-more" href="{{ route('activite',($data->slug!="")?$data->slug:$data->id) }}">En savoir plus <span class="fa fa-arrow-right"></span></a>
                            </div>
                        </div><!-- /.sa-post -->                            
                    </div>
                    <!--div class="sa-course card">

                        <div class="course-thumb border">
                        <div class="">
                            @if($act->image && $act->image!="")
                            <img src="{{ asset($act->image) }}" alt="{{ $act->titre }}" class="img-fluid">
                            @else
                            <img src="{{ asset('assets/images/cpet/actualite-default.jpg') }}" alt="{{ $act->titre }}" class="img-fluid">
                            @endif
                        </div>
                            <div class="overlay ">
                                <div class="icons">
                                    <ul class="global-list">
                                        <li><a href="{{ route('activite',$act->slug) }}" class="ms-4"><i class="fas fa-info"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rating-date bg-dark align-self-end">
                                <div class="date ">
                                    <small><i class="far fa-clock"></i>{{ date('d M Y H:i',strtotime($act->created_at)) }}</small>
                                </div>
                            </div>
                        </div>

                        <div class="course-info h-100 text-center">
                            <div class="info">
                                <h2 class="title fw-normal"><a href="{{ route('activite',$act->slug) }}">{{ $act->titre }}</a></h2>
                                <p><span class="badge">{{ isset($act->categorie)?$act->categorie->nom:'' }}</span></p>
                            </div>
                            <div class="sa-meta">
                                <ul class="global-list fw-normal fs-sm">
                                    <li><span><i class="far fa-user"></i></span>{{ isset($act->user)?$act->user->name:'' }}</span></li>
                                    <li><span><i class="far fa-eye"></i></span>{{ (int)$act->view_count }}</li>
                                </ul>
                            </div>
                        </div>
                    </div-->
                   @endforeach
                </div><!-- /.sg-course-slider -->
            </div><!-- /sg-course-content -->

        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div><!-- /.sa-section -->
@endif

@if(isset($enseignants) && $enseignants->count())
<div class="section-content download-content  section-before jarallax" style="background-image: none;" data-jarallax-original-styles="background-image: url({{ asset('assets/images/bg/bg2.jpg') }});">
<div class="sa-section py-5">
    <div class="section-content tutor-content text-center py-2">
        <div class="container">
            <div class="section-header justify-content-between">
                <div class="title align-self-center">
                    <h1>Nos enseignants </h1>
                    <span>Nos Enseignants</span>
                </div>
                <div class="view-all align-self-center">
                    <a href="{{ route('enseignants') }}" class="btn bg-white btn-sm px-3">Voir tout</a>
                </div>
            </div>

            <div class="tutor-slider row">
                
                @foreach($enseignants as $e)
                <div class="sa-tutor col-md-4 col-sm-6">
                    <a href="{{ route('enseignant',$e->slug?$e->slug:$e->id) }}">
                        <div class="tutor-thumb">
                            @if($e->photo && $e->photo!="")
                            <img src="{{ asset($e->photo) }}" alt="{{ $e->titre }}" class="img-fluid">
                            @else
                            <img src="{{ asset('assets/images/cpet/enseignant-default.jpg') }}" alt="{{ $e->titre }}" class="img-fluid">
                            @endif
                        </div><!-- /.tutor-thumb -->
                    </a>
                    <div class="tutor-info">
                        <h2><a href="{{ route('enseignant',$e->slug?$e->slug:$e->id) }}">{{ $e->nom .' '.$e->prenom }}</a></h2>
                        @if($e->specialite)
                        <small><b>Spécialité :</b>{{ $e->specialite }}</small><br>
                        @endif
                        @if($e->poste)
                        <small><b>Poste :</b> {{ $e->poste }}</small>
                        @endif
                        <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p> -->
                    </div>
                    @if(($e->lien_facebook && $e->lien_facebook!="") || ($e->lien_linkedin && $e->lien_linkedin!=""))
                    <div class="tutor-social">
                        <ul class="global-list">
                            @if($e->lien_facebook && $e->lien_facebook!="")
                            <li><a href="{{ ($e->lien_facebook) }}" target="_blanck"><i class="fab fa-facebook-f"></i></a></li>
                            @endif
                            @if($e->lien_linkedin && $e->lien_linkedin!="")
                            <li><a href="{{ ($e->lien_linkedin) }}" target="_blanck"><i class="fab fa-linkedin-in"></i></a></li>
                            @endif
                        </ul>
                    </div>
                    @endif
                </div><!-- /.sg-tutor -->
                 @endforeach
                
            </div><!-- /.tutor-slider -->
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div>
</div>
@endif

@if(isset($partenaires) && $partenaires->count())
<div class="sa-section">
    <div class="section-content section-padding text-center">
        <div class="container">
            <div class="section-header">
                <div class="title align-self-center">
                    <h1>Nos partenaires</h1>
                    <span>Partenaires</span>
                </div>
            </div>

            <div class="brand-slider">
                @foreach($partenaires as $p)
                <div class="brand">
                   <a href="{{ route('partenaire',$p->slug) }}" target="_blanck"> <img src="{{ asset($p->logo) }}" alt="Image" class="img-fluid"></a>
                </div>
                @endforeach
            </div><!-- /.tutor-slider -->
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div><!-- /.sa-section -->
@endif

@endsection