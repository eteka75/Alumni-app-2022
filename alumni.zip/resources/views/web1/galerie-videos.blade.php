@extends('layouts.web')

@section('title', 'Galerie Vidéos du CPET DON BOSCO '.config('app.site'))

@section('sidebar')
    @parent

    <section class="breadcrumb-section">
        <div class="container">
            <h1>Galerie Vidéos</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('Index')}}">Accueil</a></li>
                <li class="breadcrumb-item">Galerie Vidéos</li>
            </ol>
        </div><!-- /.container -->
    </section>    
    @section('scripts')
    <link rel="stylesheet" href="{{ asset('/storage/vendor/lightbox/css/lightbox.css') }}">
    
    <script src="{{ asset('/storage/vendor/lightbox/js/lightbox.js') }}"></script>
    @endsection
    @section('content')

    <div class="sg-section">
        <div class="section-content course-details bg-white section-padding_ py-4">
            <div class="container">
                <div class="row p-3">
                <div class="col-md-8 col-12 col-xl-8">
                    <div class="row ">
                    @foreach($datas as $key => $d)
                    
                        @if($d->url_video_youtube && $d->url_video_youtube!="")
                        <div class="mb-3 border-bottom_">
                            <h6>{{ $d->titre }}</h6>
                        <div class="col-12 col-sm-12  mb-4">
                            <div class="course-thumb">
                                
                               {!! $d->url_video_youtube !!}
                            </div><!-- /.course-thumb -->
                        </div>
                        <small>
                            {!!  $d->descripttion !!}
                        </small>
                    </div>
                        @endif
                        @endforeach
                    </div>
                    <div class="sg-pagination float-end  px-1 ">
                        {{ $datas->links() }}
                    </div> 
                </div>
                <div class="col-lg-4">
                    
                    @include('includes.right')
                 </div>
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.section-content -->
    </div>
    @endsection
    
@endsection

@section('content')

@endsection