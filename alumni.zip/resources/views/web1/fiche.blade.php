@extends('layouts.web')

@section('title', "Ma fiche d'inscription")

@section('sidebar')
    @parent

    <section class="breadcrumb-section">
        <div class="container">
            <h1 >Ma fiche d'inscription</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('Index') }}">Accueil</a></li>
                <li class="breadcrumb-item"><a href="{{ route('inscription') }}">Inscription</a></li>
                <li class="breadcrumb-item">Ma fiche d'inscription</li>
            </ol>
        </div><!-- /.container -->
    </section>

@endsection

@section('content')

    <div class="sg-section">
        <div class="section-content course-details bg-gray-400  section-padding_ py-4">
            <div class="container">
                <div class="row">
                <div class="col-12 col-md-8 col-xl-7 card mb-6 col-xxl-6 mx-auto py-10 border rounded-3 shadow-sm mb-20 my-5 px-5 py-5">
                <h2 class="text-primary"> Ma fiche d'inscription</h2>
                <small id="codeHelp" class="form-text text-muted mt-0 mb-3">NB: Veuillez sauvegarder votre code d'inscription dans un endroit sûr.</small>
                <hr class="my-0 mb-4 p-0">
                {!! Form::open(['url' => '/inscription/fiche', 'class' => 'form-horizontal','method'=>'GET', 'files' => true]) !!}
        
                    @if ($errors->any())
                    <ul class="alert list-unstyled alert-danger">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                @endif

                    <div class="form-group">
                    <div class="row">
                    <div class="col-md-8">
                      <label for="code">Code d'inscription</label>
                      <input type="search" class="form-control py-2" value="{{ request()->code}}" id="code" aria-describedby="codeHelp"  name="code" placeholder="Saisir votre code">
                      </div>
                    <div class="col-md-4">
                        <button type="submit" class="btn btn-gray-200 btn-secondary w-100 border-secondary border-3 mb-0 mt-4 py-2 btn-sm">Soumettre</button>
                    </div>
                    <div class="col-md-12">
                        @if(isset($etu) && $etu &&  request()->code)
                        <br>
                        <div class="alert alert-success  px-1 text-sm text-center">Votre fiche de pré-inscription est disponible !
                            <br> <a class="btn bg-gray text-sm  py-2 btn-sm px-5 text-uppercase mt-3 border" href="{{ url('inscription/fiche') }}?code={{request()->code  }}&show=1"><i class="fas fa-eye"></i> Visualiser ma fiche </a>
                        <a class="btn btn-primary btn-sm  text-sm py-2 mt-3 " href="{{ url('inscription/fiche') }}?code={{request()->code  }}&download=1"> <i class="fas fa-download"></i> Télécharger ma fiche </a>
                    </div>
                    @else
                    <br>
                    <div class="alert alert-danger py-1   px-1 text-sm text-center">
                        Aucune fiche ne correspond au code saisi. Essayez avec un code valide. MERCI !
                    </div>
                        @endif
                    </div>
                    </div>
                </form>
                </div><!-- /.row -->
                </div><!-- /.container -->
            </div><!-- /.section-content -->
        </div>
        
        <br>
        <br>
        <br>
    @endsection
