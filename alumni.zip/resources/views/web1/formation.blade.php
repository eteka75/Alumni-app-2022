@extends('layouts.web')

@section('title', isset($data, $data['titre']) ? $data['titre'] : 'Formation')

@section('sidebar')
    @parent

    <section class="breadcrumb-section">
        <div class="container">
            <h1>{{ isset($data, $data['titre']) ? $data['titre'] : 'Formation' }}</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('Index') }}">Accueil</a></li>
                <li class="breadcrumb-item"><a href="{{ route('formations') }}">Formations</a></li>
                <li class="breadcrumb-item">{{ isset($data, $data['titre']) ? $data['titre'] : 'Formation' }}</li>
            </ol>
        </div><!-- /.container -->
    </section>

@endsection

@section('content')

    <div class="sg-section">
        <div class="section-content course-details bg-white section-padding_ py-4">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="sa-course_">
                            <div class="course-thumb">
                                @isset($data, $data['image'])
                                    <img src="{{ asset(isset($data, $data['image']) ? $data['image'] : '') }}" alt="Image"
                                        class="img-fluid">
                                    @endif
                                </div>
                                <div class="course-info_ p-0 mb-4">
                                    @if ($data->description)
                                        <div class="border-bottom  mb-2">
                                            <h4 class="py-0 mb-1 ">Description</h4>
                                        </div>
                                        {!! isset($data, $data->description) ? $data->description : '-' !!}
                                    @endif
                                    @if ($data->debouches)
                                        <div class="border-bottom mb-2">
                                            <h4 class="py-0 mb-1 ">Débouchés</h4>
                                        </div>

                                        <div class="card_">
                                            <div class="card-body">
                                                {!! isset($data, $data->debouches) ? $data->debouches : '-' !!}
                                            </div>
                                        </div>
                                    @endif
                                    @if (isset($data->conditions))
                                        <div class="border-bottom mb-2">
                                            <h4 class="py-0 mb-1 ">Conditions</h4>
                                        </div>
                                        <div class="card_">
                                            <div class="card-body">
                                                {!! isset($data, $data->conditions) ? $data->conditions : '-' !!}
                                            </div>
                                        </div>
                                    @endif



                                </div>
                            </div><!-- /.sa-course -->
                            <hr class="my-4">
                            @if (isset($datas))
                                <div class="row">
                                    @foreach ($datas as $key => $d)
                                        <div class="col-sm-6 col-12 col-md-6 mb-3 px-1">
                                            <div class=" card border-1 shadow-sm h-100 rounded-2">
                                                <div class="row">
                                                    @php
                                                        $f = $d;
                                                    @endphp
                                                    <div class="course-thumb col-md-5 col-sm-6 col-6 pe-0">

                                                        <a href="{{ route('formation', $d->id) }}">
                                                            @if ($d->image && $d->image != '')
                                                                <img src="{{ asset($d->image) }}" alt="{{ $d->titre }}"
                                                                    class="img-fluid">
                                                            @else
                                                                <img src="{{ asset('assets/images/cpet/actualite-default.jpg') }}"
                                                                    alt="{{ $d->titre }}" class="img-fluid">
                                                            @endif
                                                        </a>
                                                    </div>
                                                    <div class="col-md-7  col-sm-6 col-6 px-1">
                                                        <!-- /.course-thumb -->
                                                        <div class="px-1 py-2 h-100  ">
                                                            <a href="{{ route('formation', $f->slug ? $f->slug : $f->id) }}">
                                                                <!--span class="icon">
                                                    <i class="fas fa-desktop"></i>
                                                </span-->
                                                                <div>
                                                                    <h5 class="mb-0  h6">{{ $f->titre }}</h5>

                                                                </div>
                                                                <div class="py-1">
                                                                    <small
                                                                        class="text-muted">{{ substr(strip_tags($f->description), 0, 50) }}
                                                                        ...<span
                                                                            class="text-promary bold  font-weight-bold">[lire la
                                                                            suite]</span></small>
                                                                </div>
                                                            </a>
                                                        </div><!-- /.sg-category -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- /.row -->
                                    @endforeach
                                </div>
                            @endif
                        </div>
                        <div class="col-lg-4">
                            @include('includes.right')
                        </div>
                    </div><!-- /.row -->
                </div><!-- /.container -->
            </div><!-- /.section-content -->
        </div>
    @endsection
