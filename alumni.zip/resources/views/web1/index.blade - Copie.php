@extends('layouts.web')

@section('title', 'Accueil')

@section('sidebar')
    @parent

    
@endsection

@section('content')
<div id="hero-slider" class="carousel slide hero-content" data-bs-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item text-center active">
            <div class="carousel-item-content section-before"  style="background-image: url(assets/images/slides/slide1.jpg);">
                <div class="container">
                    <div class="hero-text">
                        <h1 data-animation="animated fadeInDown">Des salles de cours <span>modernes</span></h1>
                        <p data-animation="animated fadeInDown">Nos apprenants apprennent dans des salles très équipées.</p>
                        <!--div class="buttons">
                            <a href="#" class="btn btn-primary"  data-animation="animated fadeInRight">Nos diplomés</a>
                            <a href="#" class="btn btn-white"  data-animation="animated fadeInLeft">En savoir plus</a>
                        </div-->
                    </div><!-- /.hero-text -->
                </div><!-- /.container -->
            </div><!-- /.carousel-item-content -->
        </div>
        <div class="carousel-item text-center">
            <div class="carousel-item-content section-before" style="background-image: url(assets/images/slides/slide5.jpg);">
                <div class="container">
                    <div class="hero-text">
                        <h1 data-animation="animated fadeInDown">De meilleurs cadres <span> pour vous</span></h1>
                        <p data-animation="animated fadeInDown">Nous offrons de meilleurs cadres pour nos apprenants afin de stimuler en eux le le gout du travail et la créactivité.</p>
                        <!--div class="buttons">
                            <a href="#" class="btn btn-primary"  data-animation="animated fadeIn">S'inscrire</a>
                            <a href="#" class="btn btn-white"  data-animation="animated fadeIn">En savoir plus</a>
                        </div-->
                    </div><!-- /.hero-text -->
                </div><!-- /.container -->
            </div>
        </div>
        <div class="carousel-item text-center">
            <div class="carousel-item-content section-before" style="background-image: url(assets/images/slides/slide3.jpg);">
                <div class="container">
                    <div class="hero-text">
                        <h1 data-animation="animated fadeInUp">Des ateliers <span>pratiques</span></h1>
                        <p data-animation="animated fadeInUp">Nos formations combinent théories et pratiques afin de d'outiller nos apprenants aux réalités de l'emploi et de l'entreprenariat.</p>
                        <!--div class="buttons">
                            <a href="#" class="btn btn-primary"  data-animation="animated fadeInRight">Nos ateliers</a>
                        </div-->
                    </div><!-- /.hero-text -->
                </div><!-- /.container -->
            </div>
        </div>
        <div class="carousel-item text-center">
            <div class="carousel-item-content section-before" style="background-image: url(assets/images/slides/slide4.jpg);">
                <div class="container">
                    <div class="hero-text">
                        <h1 data-animation="animated fadeInUp">Des ateliers <span>pratiques</span></h1>
                        <p data-animation="animated fadeInUp">Nos formations combinent théories et pratiques afin de d'outiller nos apprenants aux réalités de l'emploi et de l'entreprenariat.</p>
                        <!--div class="buttons">
                            <a href="#" class="btn btn-primary"  data-animation="animated fadeInRight">Nos ateliers</a>
                        </div-->
                    </div><!-- /.hero-text -->
                </div><!-- /.container -->
            </div>
        </div>
        <div class="carousel-item text-center">
            <div class="carousel-item-content section-before" style="background-image: url(assets/images/slides/slide5.jpg);">
                <div class="container">
                    <div class="hero-text">
                        <h1 data-animation="animated fadeInUp">Des ateliers <span>pratiques</span></h1>
                        <p data-animation="animated fadeInUp">Nos formations combinent théories et pratiques afin de d'outiller nos apprenants aux réalités de l'emploi et de l'entreprenariat.</p>
                        <!--div class="buttons">
                            <a href="#" class="btn btn-primary"  data-animation="animated fadeInRight">Nos ateliers</a>
                        </div-->
                    </div><!-- /.hero-text -->
                </div><!-- /.container -->
            </div>
        </div>
        <div class="carousel-item text-center">
            <div class="carousel-item-content section-before" style="background-image: url(assets/images/slides/slide6.jpg);">
                <div class="container">
                    <div class="hero-text">
                        <h1 data-animation="animated fadeInUp">Des ateliers <span>pratiques</span></h1>
                        <p data-animation="animated fadeInUp">Nos formations combinent théories et pratiques afin de d'outiller nos apprenants aux réalités de l'emploi et de l'entreprenariat.</p>
                        <!--div class="buttons">
                            <a href="#" class="btn btn-primary"  data-animation="animated fadeInRight">Nos ateliers</a>
                        </div-->
                    </div><!-- /.hero-text -->
                </div><!-- /.container -->
            </div>
        </div>

        <div class="carousel-item text-center">
            <div class="carousel-item-content section-before" style="background-image: url(assets/images/slides/slide7.jpg);">
                <div class="container">
                    <div class="hero-text">
                        <h1 data-animation="animated fadeInUp">Des ateliers <span>pratiques</span></h1>
                        <p data-animation="animated fadeInUp">Nos formations combinent théories et pratiques afin de d'outiller nos apprenants aux réalités de l'emploi et de l'entreprenariat.</p>
                        <!--div class="buttons">
                            <a href="#" class="btn btn-primary"  data-animation="animated fadeInRight">Nos ateliers</a>
                        </div-->
                    </div><!-- /.hero-text -->
                </div><!-- /.container -->
            </div>
        </div>
    </div><!-- /.carousel-inner -->

    <div class="carousel-indicators">
        <button type="button" data-bs-target="#hero-slider" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
        <button type="button" data-bs-target="#hero-slider" data-bs-slide-to="1" aria-label="Slide 2"></button>
        <button type="button" data-bs-target="#hero-slider" data-bs-slide-to="2" aria-label="Slide 3"></button>
        <button type="button" data-bs-target="#hero-slider" data-bs-slide-to="3" aria-label="Slide 4"></button>
        <button type="button" data-bs-target="#hero-slider" data-bs-slide-to="4" aria-label="Slide 5"></button>
        <button type="button" data-bs-target="#hero-slider" data-bs-slide-to="5" aria-label="Slide 6"></button>
        <button type="button" data-bs-target="#hero-slider" data-bs-slide-to="6" aria-label="Slide 7"></button>
    </div>

    <button class="carousel-control-prev" type="button" data-bs-target="#hero-slider" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#hero-slider" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div><!-- /#hero-slider -->

<div class="sa-section">
    <div class="section-content sa-about section-padding">
        <div class="container">
            <div class="row">
                
                <div class="col-lg-6 align-self-center">
                    <div class="section-header">
                        <div class="title">
                            <h1></h1>
                            <span>A propos DE NOUS</span>
                        </div>
                    </div>
                    <div class="about-info">
                        <h2>We provide exclusive Courses</h2>
                        <p>We can help you create positive and permanent changes in your life. Let’s Create Something new and awesome Togeather. High Performance WordPress Theme. Let’s Create Something new and awesome Togeather & Best Services. We are the first and trusted Business Consulting company in your city. The best service is our goal.</p>
                        <ul class="global-list">
                            <li> High Quality Education </li>
                            <li> You can learn anything online</li>
                            <li> We list your options by state</li>
                        </ul>
                        <a href="#" class="btn btn-primary">En savoir plus</a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about-thumb">
                        
                    </div>
                </div>
            </div>
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div>
<div class="sa-section mt-0">
    <div class="section-content sa-about section-padding_ mb-5">
        <div class="container">
            <div class="row">


                <div class="col-lg-6 text-center">
                    <div class="section-header">
                        <div class="title">
                            <h1>SITE DE COTONOU</h1>
                            <span>COTONOU</span>
                        </div>
                    </div>
                    <div class="about-thumb">
                       <a href="#"> <img src="assets/images/blog/1.jpg" alt="Image" class="img-fluid"></a>
                    </div>
                </div>
                <div class="col-lg-6  text-center">
                    <div class="section-header">
                        <div class="title">
                            <h1>SITE DE PARAKOU</h1>
                            <span>PARAKOU</span>
                        </div>
                    </div>
                    <div class="about-thumb">
                        <a href="#"> <img src="assets/images/blog/3.jpg" alt="Image" class="img-fluid"></a>
                    </div>
                </div>
            </div>
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div><!-- /.sa-section -->

<div class="sa-section">
    <div class="section-content bg-darkens feature-content section-padding jarallax section-before" style="background-image: url(assets/s/images/slides/slide3.jpg);">
        <div class="container">
            <div class="section-header">
                <div class="title align-self-center">
                    <h1>Pourquoi nous rejoindre</h1>
                    <span>Nous rejoindre</span>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="feature">
                        <div class="icon">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <div class="text">
                            <h2>Des enseignants qualifiés</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illo at tempora quos illum voluptatum quisquam qui, architecto repellendus, a officiis adipisci.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="feature">
                        <div class="icon">
                            <i class="fa fa-compress"></i>
                        </div>
                        <div class="text">
                            <h2>Un cadre idéal pour apprendre</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illo at tempora quos illum voluptatum quisquam qui, architecto repellendus, a officiis adipisci.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="feature">
                        <div class="icon">
                            <i class="far fa-folder-open"></i>
                        </div>
                        <div class="text">
                            <h2>Plus de 3000 livres disponibles </h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illo at tempora quos illum voluptatum quisquam qui, architecto repellendus, a officiis adipisci.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="feature">
                        <div class="icon">
                            <i class="fas fa-external-link-alt"></i>
                        </div>
                        <div class="text">
                            <h2>Access gratuit aux ateliers de pratique</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illo at tempora quos illum voluptatum quisquam qui, architecto repellendus, a officiis adipisci.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="feature">
                        <div class="icon">
                            <i class="far fa-edit"></i>
                        </div>
                        <div class="text">
                            <h2>Des cours théoriques et pratiques</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illo at tempora quos illum voluptatum quisquam qui, architecto repellendus, a officiis adipisci.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="feature">
                        <div class="icon">
                            <i class="fas fa-hand-holding-usd"></i>
                        </div>
                        <div class="text">
                            <h2>Payements allégés de la scolarité</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illo at tempora quos illum voluptatum quisquam qui, architecto repellendus, a officiis adipisci.</p>
                        </div>
                    </div>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div><!-- /.sa-section -->

<div class="sa-section">
    <div class="section-content section-padding">
        <div class="container">
            <div class="section-header justify-content-between">
                <div class="title">
                    <h1>Nos domaines de formation</h1>
                    <span>Nos domaines</span>
                </div>
            </div><!-- /.section-header -->

            <div class="sg-category-content">
                <div class="row">
                    <div class="col-sm-6 col-lg-3">
                        <div class="sg-category">
                            <a href="#catagory">
                                <span class="icon">
                                    <i class="fas fa-desktop"></i>
                                </span>
                                <span>IT & Software</span>
                            </a>
                        </div><!-- /.sg-category -->
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="sg-category">
                            <a href="#catagory">
                                <span class="icon">
                                    <i class="fas fa-chart-line"></i>
                                </span>
                                <span>Business</span>
                            </a>
                        </div><!-- /.sg-category -->
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="sg-category">
                            <a href="#catagory">
                                <span class="icon">
                                    <i class="fas fa-layer-group"></i>
                                </span>
                                <span>Graphic Design</span>
                            </a>
                        </div><!-- /.sg-category -->
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="sg-category">
                            <a href="#catagory">
                                <span class="icon">
                                    <i class="fas fa-bullseye"></i>
                                </span>
                                <span>Marketing</span>
                            </a>
                        </div><!-- /.sg-category -->
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="sg-category">
                            <a href="#catagory">
                                <span class="icon">
                                    <i class="far fa-file-code"></i>
                                </span>
                                <span>Development</span>
                            </a>
                        </div><!-- /.sg-category -->
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="sg-category">
                            <a href="#catagory">
                                <span class="icon">
                                    <i class="fab fa-codepen"></i>
                                </span>
                                <span>Web Design</span>
                            </a>
                        </div><!-- /.sg-category -->
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="sg-category">
                            <a href="#catagory">
                                <span class="icon">
                                    <i class="fas fa-camera"></i>
                                </span>
                                <span>Photography</span>
                            </a>
                        </div><!-- /.sg-category -->
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="sg-category">
                            <a href="#catagory">
                                <span class="icon">
                                    <i class="fas fa-music"></i>
                                </span>
                                <span>Video & Music</span>
                            </a>
                        </div><!-- /.sg-category -->
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="sg-category">
                            <a href="#catagory">
                                <span class="icon">
                                    <i class="fas fa-language"></i>
                                </span>
                                <span>Language</span>
                            </a>
                        </div><!-- /.sg-category -->
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="sg-category">
                            <a href="#catagory">
                                <span class="icon">
                                    <i class="fab fa-accusoft"></i>
                                </span>
                                <span>Software</span>
                            </a>
                        </div><!-- /.sg-category -->
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="sg-category">
                            <a href="#catagory">
                                <span class="icon">
                                    <i class="fas fa-people-arrows"></i>
                                </span>
                                <span>Social Media</span>
                            </a>
                        </div><!-- /.sg-category -->
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="sg-category">
                            <a href="#catagory">
                                <span class="icon">
                                    <i class="far fa-comments"></i>
                                </span>
                                <span>Communication</span>
                            </a>
                        </div><!-- /.sg-category -->
                    </div>
                </div><!-- /.row -->
            </div><!-- /.sg-category-content -->
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div><!-- /.sa-section -->

<div class="sa-section">
    <div class="section-content section-padding padding-top-0">
        <div class="container">
            <div class="section-header text-center justify-content-between">
                <div class="title align-self-center">
                    <h1>Nos activités</h1>
                    <span>Activités</span>
                </div>
                <div class="view-all align-self-center">
                    <a href="course-grid.html" class="btn btn-primary">Voir Tout</a>
                </div>
            </div><!-- /.section-header -->

            <div class="sa-course-content">
                <div class="sa-course-slider">
                    <div class="sa-course">

                        <div class="course-thumb">
                            <img src="assets/images/course/1.jpg" alt="Image" class="img-fluid">
                            <div class="overlay">
                                <div class="icons">
                                    <ul class="global-list">
                                        <li><a href="course-details.html"><i class="fas fa-link"></i></a></li>
                                        <li><a href="#"><i class="fas fa-cart-plus"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rating-date align-self-end">
                                <div class="date">
                                    <span><i class="far fa-clock"></i>20 Mai 2021</span>
                                </div>
                            </div><!-- /.rating-price -->
                        </div><!-- /.course-thumb -->

                        <div class="course-info">
                            <div class="info">
                                <h2 class="title"><a href="course-details.html">Visual Basic Web Course With Live Project</a></h2>
                                <p>web development</p>
                            </div>
                            <div class="sa-meta">
                                <ul class="global-list">
                                    <li><a href="#"><span><i class="far fa-user"></i></span>5000 Students</a></li>
                                    <li><a href="#"><span><i class="far fa-comments"></i></span>350</a></li>
                                </ul>
                            </div>
                        </div><!-- /.course-info -->
                    </div><!-- /.sg-course -->

                    <div class="sa-course">
                        <div class="course-thumb">
                            <img src="assets/images/course/2.jpg" alt="Image" class="img-fluid">
                            <div class="overlay">
                                <div class="icons">
                                    <ul class="global-list">
                                        <li><a href="course-details.html"><i class="fas fa-link"></i></a></li>
                                        <li><a href="#"><i class="fas fa-cart-plus"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rating-date align-self-end">
                                <div class="date">
                                    <span><i class="far fa-clock"></i>18 May 2021</span>
                                </div>
                            </div><!-- /.rating-price -->
                        </div><!-- /.course-thumb -->

                        <div class="course-info">
                            <div class="info">
                                <h2 class="title"><a href="course-details.html">Computer Technologies Course With Live Project</a></h2>
                                <p>Computer Technologies</p>
                            </div>
                            <div class="sa-meta">
                                <ul class="global-list">
                                    <li><a href="#"><span><i class="far fa-user"></i></span>3000 Students</a></li>
                                    <li><a href="#"><span><i class="far fa-comments"></i></span>2550</a></li>
                                </ul>
                            </div>
                        </div><!-- /.course-info -->
                    </div><!-- /.sg-course -->

                    <div class="sa-course">
                        <div class="course-thumb">
                            <img src="assets/images/course/3.jpg" alt="Image" class="img-fluid">
                            <div class="overlay">
                                <div class="icons">
                                    <ul class="global-list">
                                        <li><a href="course-details.html"><i class="fas fa-link"></i></a></li>
                                        <li><a href="#"><i class="fas fa-cart-plus"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rating-date align-self-end">
                                <div class="date">
                                    <span><i class="far fa-clock"></i>19 May 2021</span>
                                </div>
                            </div><!-- /.rating-price -->
                        </div><!-- /.course-thumb -->

                        <div class="course-info">
                            <div class="info">
                                <h2 class="title"><a href="course-details.html">Electrical & Electronic Course With Live Project</a></h2>
                                <p>Electronic</p>
                            </div>
                            <div class="sa-meta">
                                <ul class="global-list">
                                    <li><a href="#"><span><i class="far fa-user"></i></span>1000 Students</a></li>
                                    <li><a href="#"><span><i class="far fa-comments"></i></span>630</a></li>
                                </ul>
                            </div>
                        </div><!-- /.course-info -->
                    </div><!-- /.sg-course -->

                    <div class="sa-course">
                        <div class="course-thumb">
                            <img src="assets/images/course/4.jpg" alt="Image" class="img-fluid">
                            <div class="overlay">
                                <div class="icons">
                                    <ul class="global-list">
                                        <li><a href="course-details.html"><i class="fas fa-link"></i></a></li>
                                        <li><a href="#"><i class="fas fa-cart-plus"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rating-date align-self-end">
                                <div class="date">
                                    <span><i class="far fa-clock"></i>21 May 2021</span>
                                </div>
                            </div><!-- /.rating-price -->
                        </div><!-- /.course-thumb -->

                        <div class="course-info">
                            <div class="info">
                                <h2 class="title"><a href="course-details.html">Visual Basic Web Course With Live Project</a></h2>
                                <p>Web Design</p>
                            </div>
                            <div class="sa-meta">
                                <ul class="global-list">
                                    <li><a href="#"><span><i class="far fa-user"></i></span>4000 Students</a></li>
                                    <li><a href="#"><span><i class="far fa-comments"></i></span>400</a></li>
                                </ul>
                            </div>
                        </div><!-- /.course-info -->
                    </div><!-- /.sg-course -->

                    <div class="sa-course">
                        <div class="course-thumb">
                            <img src="assets/images/course/5.jpg" alt="Image" class="img-fluid">
                            <div class="overlay">
                                <div class="icons">
                                    <ul class="global-list">
                                        <li><a href="course-details.html"><i class="fas fa-link"></i></a></li>
                                        <li><a href="#"><i class="fas fa-cart-plus"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rating-date align-self-end">
                                <div class="date">
                                    <span><i class="far fa-clock"></i>20 May 2021</span>
                                </div>
                            </div><!-- /.rating-price -->
                        </div><!-- /.course-thumb -->

                        <div class="course-info">
                            <div class="info">
                                <h2 class="title"><a href="course-details.html">Build a Business Plan With Live</a></h2>
                                <p>Business</p>
                            </div>
                            <div class="sa-meta">
                                <ul class="global-list">
                                    <li><a href="#"><span><i class="far fa-user"></i></span>7000 Students</a></li>
                                    <li><a href="#"><span><i class="far fa-comments"></i></span>800</a></li>
                                </ul>
                            </div>
                        </div><!-- /.course-info -->
                    </div><!-- /.sg-course -->

                    <div class="sa-course">
                        <div class="course-thumb">
                            <img src="assets/images/course/6.jpg" alt="Image" class="img-fluid">
                            <div class="overlay">
                                <div class="icons">
                                    <ul class="global-list">
                                        <li><a href="course-details.html"><i class="fas fa-link"></i></a></li>
                                        <li><a href="#"><i class="fas fa-cart-plus"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rating-date align-self-end">
                                <div class="date">
                                    <span><i class="far fa-clock"></i>22 May 2021</span>
                                </div>
                            </div><!-- /.rating-price -->
                        </div><!-- /.course-thumb -->

                        <div class="course-info">
                            <div class="info">
                                <h2 class="title"><a href="course-details.html">Fox nymphs grab quick-jived waltz.</a></h2>
                                <p>Art and Design</p>
                            </div>
                            <div class="sa-meta">
                                <ul class="global-list">
                                    <li><a href="#"><span><i class="far fa-user"></i></span>4500 Students</a></li>
                                    <li><a href="#"><span><i class="far fa-comments"></i></span>510</a></li>
                                </ul>
                            </div>
                        </div><!-- /.course-info -->
                    </div><!-- /.sg-course -->

                    <div class="sa-course">
                        <div class="course-thumb">
                            <img src="assets/images/course/7.jpg" alt="Image" class="img-fluid">
                            <div class="overlay">
                                <div class="icons">
                                    <ul class="global-list">
                                        <li><a href="course-details.html"><i class="fas fa-link"></i></a></li>
                                        <li><a href="#"><i class="fas fa-cart-plus"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rating-date align-self-end">
                                <div class="date">
                                    <span><i class="far fa-clock"></i>19 May 2021</span>
                                </div>
                            </div><!-- /.rating-price -->
                        </div><!-- /.course-thumb -->

                        <div class="course-info">
                            <div class="info">
                                <h2 class="title"><a href="course-details.html">Duis rhoncus dui venenatis consequat porttito</a></h2>
                                <p>Art and Design</p>
                            </div>
                            <div class="sa-meta">
                                <ul class="global-list">
                                    <li><a href="#"><span><i class="far fa-user"></i></span>4500 Students</a></li>
                                    <li><a href="#"><span><i class="far fa-comments"></i></span>510</a></li>
                                </ul>
                            </div>
                        </div><!-- /.course-info -->
                    </div><!-- /.sg-course -->
                </div><!-- /.sg-course-slider -->
            </div><!-- /sg-course-content -->

        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div><!-- /.sa-section -->

<div class="sa-section">
    <div class="section-content tutor-content text-center">
        <div class="container">
            <div class="section-header justify-content-between">
                <div class="title align-self-center">
                    <h1>Nos enseignants populaires</h1>
                    <span>Nos Enseignants</span>
                </div>
                <div class="view-all align-self-center">
                    <a href="tutor.html" class="btn btn-primary">View All</a>
                </div>
            </div>

            <div class="tutor-slider">
                <div class="sa-tutor">
                    <div class="tutor-thumb">
                        <a href="tutor-details.html"><img src="assets/images/tutor/1.jpg" alt="Image" class="img-fluid"></a>
                    </div><!-- /.tutor-thumb -->
                    <div class="tutor-info">
                        <h2><a href="tutor-details.html">Ahmed Kerial</a></h2>
                        <span>Enseignant de mathématiques</span>
                        <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p> -->
                    </div>
                    <div class="tutor-social">
                        <ul class="global-list">
                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        </ul>
                    </div>
                </div><!-- /.sg-tutor -->

                <div class="sa-tutor">
                    <div class="tutor-thumb">
                        <a href="tutor-details.html"><img src="assets/images/tutor/2.jpg" alt="Image" class="img-fluid"></a>
                    </div><!-- /.tutor-thumb -->
                    <div class="tutor-info">
                        <h2><a href="tutor-details.html">Field Supervisor</a></h2>
                        <span>Published 310 Courses</span>
                        <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p> -->
                    </div>
                    <div class="tutor-social">
                        <ul class="global-list">
                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        </ul>
                    </div>
                </div><!-- /.sg-tutor -->

                <div class="sa-tutor">
                    <div class="tutor-thumb">
                        <a href="tutor-details.html"><img src="assets/images/tutor/3.jpg" alt="Image" class="img-fluid"></a>
                    </div><!-- /.tutor-thumb -->
                    <div class="tutor-info">
                        <h2><a href="tutor-details.html">Kate HAMISSOU</a></h2>
                        <span>Enseignant de Philosophie</span>
                        <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p> -->
                    </div>
                    <div class="tutor-social">
                        <ul class="global-list">
                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        </ul>
                    </div>
                </div><!-- /.sg-tutor -->

                <div class="sa-tutor">
                    <div class="tutor-thumb">
                        <a href="tutor-details.html"><img src="assets/images/tutor/4.jpg" alt="Image" class="img-fluid"></a>
                    </div><!-- /.tutor-thumb -->
                    <div class="tutor-info">
                        <h2><a href="tutor-details.html">Michael BANOUTO</a></h2>
                        <span>Enseignant de Sciences Physiques</span>
                        <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p> -->
                    </div>
                    <div class="tutor-social">
                        <ul class="global-list">
                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        </ul>
                    </div>
                </div><!-- /.sg-tutor -->

                <div class="sa-tutor">
                    <div class="tutor-thumb">
                        <a href="tutor-details.html"><img src="assets/images/tutor/5.jpg" alt="Image" class="img-fluid"></a>
                    </div><!-- /.tutor-thumb -->
                    <div class="tutor-info">
                        <h2><a href="tutor-details.html">Jeanine TAME</a></h2>
                        <span>Published 810 Courses</span>
                        <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p> -->
                    </div>
                    <div class="tutor-social">
                        <ul class="global-list">
                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        </ul>
                    </div>
                </div><!-- /.sg-tutor -->

            </div><!-- /.tutor-slider -->
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div><!-- /.sa-section -->



<div class="sa-section">
    <div class="section-content section-padding text-center jarallax section-before" style="background-image: url(assets/images/slides/slide1.jpg);">
        <div class="container">
            <div class="testimonial-slider">
                <div class="testimonial">
                    <div class="testimonial-info">
                        <div class="icon">
                            <span><i class="fas fa-quote-left"></i></span>
                        </div>
                        <h2>Allowing for field strengths are and ceramic magnets, but these are also amongweakesttypes the ferrite magnets are mainly.</h2>
                        <div class="testimonial-footer">
                            <div class="author">
                                <img src="images/others/0.png" alt="Image" class="img-fluid img-circle">
                            </div>
                            <div class="testimonial-text">
                                <div class="testimonial-ratings">
                                    <ul class="global-list">
                                        <li class="checked"><i class="fa fa-star"></i></li>
                                        <li class="checked"><i class="fa fa-star"></i></li>
                                        <li class="checked"><i class="fa fa-star"></i></li>
                                        <li class="checked"><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                    </ul>
                                </div>
                                <div class="testimonial-title">
                                    <h3>Jeff Sanders</h3>
                                    <span>Founder, Sonvaocas</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- /.testimonial -->
                <div class="testimonial">
                    <div class="testimonial-info">
                        <div class="icon">
                            <span><i class="fas fa-quote-left"></i></span>
                        </div>
                        <h2>Allowing for field strengths are and ceramic magnets, but these are also amongweakesttypes the ferrite magnets are mainly.</h2>
                        <div class="testimonial-footer">
                            <div class="author">
                                <img src="images/others/1.png" alt="Image" class="img-fluid img-circle">
                            </div>
                            <div class="testimonial-text">
                                <div class="testimonial-ratings">
                                    <ul class="global-list">
                                        <li class="checked"><i class="fa fa-star"></i></li>
                                        <li class="checked"><i class="fa fa-star"></i></li>
                                        <li class="checked"><i class="fa fa-star"></i></li>
                                        <li class="checked"><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                    </ul>
                                </div>
                                <div class="testimonial-title">
                                    <h3>Nancy Doll</h3>
                                    <span>Director</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- /.testimonial -->
                <div class="testimonial">
                    <div class="testimonial-info">
                        <div class="icon">
                            <span><i class="fas fa-quote-left"></i></span>
                        </div>
                        <h2>Allowing for field strengths are and ceramic magnets, but these are also amongweakesttypes the ferrite magnets are mainly.</h2>
                        <div class="testimonial-footer">
                            <div class="author">
                                <img src="images/others/0.png" alt="Image" class="img-fluid img-circle">
                            </div>
                            <div class="testimonial-text">
                                <div class="testimonial-ratings">
                                    <ul class="global-list">
                                        <li class="checked"><i class="fa fa-star"></i></li>
                                        <li class="checked"><i class="fa fa-star"></i></li>
                                        <li class="checked"><i class="fa fa-star"></i></li>
                                        <li class="checked"><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                    </ul>
                                </div>
                                <div class="testimonial-title">
                                    <h3>David Rasky</h3>
                                    <span>Manager</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- /.testimonial -->
            </div><!-- /.tutor-slider -->
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div><!-- /.sa-section -->


<div class="sa-section">
    <div class="section-content section-padding text-center">
        <div class="container">
            <div class="section-header">
                <div class="title align-self-center">
                    <h1>Nos partenaires</h1>
                    <span>Partenaires</span>
                </div>
            </div>

            <div class="brand-slider">
                <div class="brand">
                    <img src="assets/images/brand/1.png" alt="Image" class="img-fluid">
                </div>
                <div class="brand">
                    <img src="assets/images/brand/2.png" alt="Image" class="img-fluid">
                </div>
                <div class="brand">
                    <img src="assets/images/brand/3.png" alt="Image" class="img-fluid">
                </div>
                <div class="brand">
                    <img src="assets/images/brand/4.png" alt="Image" class="img-fluid">
                </div>
                <div class="brand">
                    <img src="assets/images/brand/5.png" alt="Image" class="img-fluid">
                </div>
                <div class="brand">
                    <img src="assets/images/brand/6.png" alt="Image" class="img-fluid">
                </div>
            </div><!-- /.tutor-slider -->
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div><!-- /.sa-section -->


@endsection