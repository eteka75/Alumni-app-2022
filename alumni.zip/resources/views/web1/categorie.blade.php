@extends('layouts.web')

@section('title', isset($data, $data['nom']) ? $data['nom'] : 'Catégories')

@section('sidebar')
    @parent

    <section class="breadcrumb-section">
        <div class="container">
            <h1><span class="text-success">Catégorie: </span> {{ isset($data, $data['nom']) ? $data['nom'] : '-' }}</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('Index') }}">Accueil</a></li>
                <li class="breadcrumb-item"><a href="{{ route('activites') }}">Activités</a></li>
                <li class="breadcrumb-item"><a href="{{ route('categories') }}">Catégories</a></li>
                <li class="breadcrumb-item">{{ isset($data, $data['nom']) ? $data['nom'] : 'Catégorie' }}</li>
            </ol>
        </div><!-- /.container -->
    </section>

@endsection

@section('content')
    <div class="sg-section">
        <div class="section-content course-details bg-white section-padding_ py-4">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="row">
                            @if (isset($activites) && $activites->count())
                                @foreach ($activites as $key => $data)
                                    <div class="col-lg-6">
                                        <div class="sa-post border-1">
                                            <div class="entry-header">
                                                <div class="entry-thumbnail">
                                                    <a href="{{ route('activite', $data['slug']) }}">
                                                        @if ($data['image'] && $data['image'] != '')
                                                            <img src="{{ asset($data['image']) }}"
                                                                alt="{{ $data['titre'] }}" class="img-fluid">
                                                        @else
                                                            <img src="{{ asset('assets/images/cpet/actualite-default.jpg') }}"
                                                                alt="{{ $data['titre'] }}" class="img-fluid">
                                                        @endif
                                                    </a>
                                                </div>
                                                <div class="entry-meta">
                                                    <a href="{{ route('activite', $data['slug']) }}">{{ date('M', strtotime($data['created_at'])) }}
                                                        <span>{{ date('Y', strtotime($data['created_at'])) }} </span></a>
                                                </div>
                                            </div>
                                            <div class="entry-content">
                                                @isset($data['categorie'])

                                                <a href="{{ route('categorie',$data->categorie?$data->categorie->id:'-') }}"> <span class="badge bg-danger mt-n3 float-end rounded-pill">{{  isset($data->categorie)?$data->categorie->nom:''}}</span> </a>  <br>
                                                
                                                @endisset
                                                <h2 class="entry-title"><a
                                                        href="{{ route('activite', $data['slug']) }}">{{ $data['titre'] }}
                                                    </a></h2>
                                                <p>{{ substr($data['resume'], 0, 200) }}</p>
                                                <a class="read-more"
                                                    href="{{ route('activite', $data['slug'] ? $data['slug'] : $data['id']) }}">En
                                                    savoir plus <span class="fa fa-arrow-right"></span></a>
                                            </div>
                                        </div><!-- /.sa-post -->
                                    </div>

                                @endforeach
                                @else
                                <div class=" col-md-12">
                                <div class=" card">
                                <div class="card-body text-center">
                                    <h5>Aucune activité dans cette catégorie !</h5>
                                <small>Les activité de la catégorie <b>{{ isset($data['nom']) ? $data['nom']:'' }}</b> apparaissent ici...</small>
                                    </div>
                                </div>
                                </div>
                            @endif

                        </div><!-- /.row -->

                        <div class="sg-pagination float-end  px-1  ">
                            {{ $activites->links() }}
                        </div>
                        <hr class="my-4">
                        @if (isset($datas))
                            <div class="row">
                                @foreach ($datas as $key => $d)
                                    <div class="col-md-6  h-100 ">
                                        <div class="row border  mx-1 rounded-3 shadow-sm mb-2">
                                            <div class="col-12 col-sm-12">
                                                <div class="sa-courses">

                                                    <div class="course-info_ px-2 py-3">
                                                        <div class="info">

                                                            <h5 class="title fs-sm mt-0"><a
                                                                    href="{{ route('categorie', $d->slug != '' ? $d->slug : $d->id) }}">{{ $d->nom }}</a>
                                                            </h5>
                                                            <small class="text-muted">
                                                                @php
                                                                    $n=$d->activites?$d->activites->count():0;
                                                                @endphp
                                                              <div class="text-danger">{{ $n }}  Activité{{ $n>1?"s":'' }} </div>
                                                                {{ substr(strip_tags($d->description), 0, 100) }}
                                                            </small>
                                                        </div>
                                                    </div><!-- /.course-info -->
                                                </div><!-- /.sg-course -->
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        @endif
                    </div>
                    <div class="col-lg-4">
                        @include('includes.right')
                    </div>
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.section-content -->
    </div>
@endsection
