@extends('layouts.web')

@section('title', 'Site de Parakou')

@section('sidebar')
    @parent

    <section class="breadcrumb-section">
        <div class="container">
            <h1>CFPS DON BOSCO COTONOU</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('Index')}}">Accueil</a></li>
                <li class="breadcrumb-item">Site de Cotonou</li>
            </ol>
        </div><!-- /.container -->
    </section> 
    
@endsection

@section('content')

@endsection