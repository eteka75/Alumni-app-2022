@extends('layouts.web')

@section('title', isset($data,$data['nom'],$data['prenom'])?$data['nom'].' '.$data['prenom']:'Membre')

@section('sidebar')
    @parent

    <section class="breadcrumb-section">
        <div class="container">
            <h1>{{ isset($data,$data['nom'],$data['prenom'])?$data['nom'].' '.$data['prenom']:'Membre' }}</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('Index')}}">Accueil</a></li>
                <li class="breadcrumb-item"><a href="{{route('membres-administratifs')}}">Membres administratifs</a></li>
                <li class="breadcrumb-item">{{ isset($data,$data['nom'],$data['prenom'])?$data['nom'].' '.$data['prenom']:'Membres' }}</li>
            </ol>
        </div><!-- /.container -->
    </section> 
    
@endsection

@section('content')
<div class="sg-section">
    <div class="section-content course-details bg-white section-padding_ py-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="sa-course_">
                        <div class="course-thumb">
                            @isset($data,$data['image'])
                            <img src="{{ asset(isset($data,$data['image'])?$data['image']:'') }}" alt="Image" class="img-fluid">
                            @endif
                        </div>
                        <div class="course-info_ p-0 mb-4">
                            @isset($data,$data['photo'])
                            <img src="{{ asset(isset($data,$data['photo'])?$data['photo']:'') }}" alt="Image" class="img-fluid shadow-sm rounded-3 mb-4">
                            @endif
                            <table class="tableborder table-responsive_  table-striped_">
                                @if($data->site)
                               <tr>
                                   <th class="col-2">Site</th>
                                   <td>{{ $data->site }}</td>
                               </tr>
                               @endif
                                @if($data->nom)
                               <tr>
                                   <th class="col-2">Nom</th>
                                   <td>{{ $data->nom }}</td>
                               </tr>
                               @endif
                               @if($data->prenom)
                               <tr>
                                   <th class="col-2">Prénom</th>
                                   <td>{{ $data->prenom }}</td>
                               </tr>
                               @endif
                               <tr>
                                   <th class="col-2">Sexe</th>
                                   <td>{{ $data->sexe=='M'?'Masculin':'Féminin' }}</td>
                                </tr>
                                @if($data->email)
                                <tr>
                                    <th class="col-2">Email</th>
                                    <td><a href="mailto:{{ $data->email }}" class="text-primary">{{ $data->email }}</a></td>
                                </tr>
                                @endif
                                @if($data->tel)
                                <tr>
                                    <th class="col-2">Tél</th>
                                    <td>{{ $data->tel }}</td>
                                </tr>
                                @endif
                                @if($data->lien_facebook)
                                <tr>
                                    <th class="col-2">Lien facebook</th>
                                    <td>{{ $data->lien_facebook }}</td>
                                </tr>
                                @endif
                                @if($data->lien_linkedin)
                                <tr>
                                    <th class="col-2">Lien LinkedIn</th>
                                    <td>{{ $data->lien_linkedin }}</td>
                                </tr>
                                @endif
                            </table>
                            {!! $data->biographie !!}
                              
                        </div>
                    </div><!-- /.sa-course -->  
                    <hr class="my-4">
                    @if(isset($datas))
                    <div class="row">
                    @foreach($datas as $key => $d)
                   
                    <div class="col-md-4 mb-4">
                        <div class="row border_  rounded-3 shadow-sm mb-2 ">
                            <div class="col-12 col-sm-12">
                                <div class="sa-courses card_membre ">                             
                                    <div class="entry-thumbnail">
                                        <a href="{{ route('membre',$d['id']) }}"> 
                                            @if($d['photo'] && $d['photo']!="")
                                            <img src="{{ asset($d['photo']) }}" alt="{{ $d['titre'] }}" class="img-fluid rounded-3 shadow-sm img-avatar img-fluid-100">
                                            @else
                                            <img src="{{ asset('assets/images/cpet/actualite-default.jpg') }}" alt="{{ $d['titre'] }}" class="img-fluid">
                                            @endif
                                            </a>
                                    </div>
                                    <div class="course-info_ px-2 py-3">
                                        <div class="info text-center">
                                            @isset($d->site)                                                
                                            <span class="badge bg-secondary rounded-pill fs-xs fw-semibold text-lowercase">SITE DE {{ $d->site}}</span>   <br-->
                                            @endisset
                                            <h5 class="title fs-sm mt-0 mb-0"><a href="{{ route('membre',($d->slug!="")?$d->slug:$d->id) }}">{{ $d->nom.' '.$d->prenom }}</a></h5>
                                            <small><b>Poste:</b> {{ $d->poste }}</small>
                                           <small class="text-muted">
                                               {{ substr(strip_tags($d->contenu),0,100) }}
                                           </small>
                                        </div>
                                    </div><!-- /.course-info -->
                                </div><!-- /.sg-course -->                                      
                            </div>
                        </div>
                        </div> 
                    @endforeach
                </div>
                        @endif                         
                </div>
                <div class="col-lg-4">
                   @include('includes.right')
                </div>
            </div><!-- /.row -->
        </div><!-- /.container -->
    </div><!-- /.section-content -->
</div>
@endsection