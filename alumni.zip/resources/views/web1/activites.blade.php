@extends('layouts.web')

@section('title', 'Nos activités au CPET DON BOSCO '.config('app.site'))

@section('sidebar')
    @parent

    <section class="breadcrumb-section">
        <div class="container">
            <h1>Nos Activités</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('Index')}}">Accueil</a></li>
                <li class="breadcrumb-item">Nos activités</li>
            </ol>
        </div><!-- /.container -->
    </section> 
    
@endsection

@section('content')
<div class="sg-page-content">         
    <div class="sa-section">
        <div class="section-content section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="row">
                            @if(isset($datas))
                                @foreach($datas as $key => $data)                
 <div class="col-lg-6"> 
                                    <div class="sa-post border-1">
                                        <div class="entry-header">
                                            <div class="entry-thumbnail">
                                                <a href="{{ route('activite',$data['slug']) }}"> 
                                                    @if($data['image'] && $data['image']!="")
                                                    <img src="{{ asset($data['image']) }}" alt="{{ $data['titre'] }}" class="img-fluid">
                                                    @else
                                                    <img src="{{ asset('assets/images/cpet/actualite-default.jpg') }}" alt="{{ $data['titre'] }}" class="img-fluid">
                                                    @endif
                                                    </a>
                                            </div>
                                            <div class="entry-meta">
                                                <a href="{{ route('activite',$data['slug']) }}">{{ date('M',strtotime($data['created_at'])) }} <span>{{ date('Y',strtotime($data['created_at'])) }} </span></a>
                                            </div>   
                                        </div>                               
                                        <div class="entry-content">  
                                            @isset($data['site'])          
                                                                               
                                            <span class="badge bg-danger rounded-pill">{{ isset($data->categorie)?$data->categorie->nom:''}}</span>   <br>
                                            @endisset
                                            <h2 class="entry-title"><a href="{{ route('activite',$data['slug']) }}">{{ $data['titre'] }} </a></h2>
                                            <p>{{ substr($data['resume'],0,200) }}</p>   
                                            <a class="read-more"  href="{{ route('activite',$data['slug']?$data['slug']:$data['id']) }}">En savoir plus <span class="fa fa-arrow-right"></span></a>
                                        </div>
                                    </div><!-- /.sa-post -->                            
                                </div>                               
                                   
                                @endforeach
                                @endif
                                
                            </div><!-- /.row --> 

                        <div class="sg-pagination float-end  px-1  ">
                            {{ $datas->links() }}
                        </div>                                                                 
                    </div>
                    <div class="col-lg-4">
                        @include('includes.right')
                    </div>
                </div><!-- /.row -->                     
            </div><!-- /.container -->
        </div><!-- /.section-content -->
    </div><!-- /.sa-section -->
</div>
@endsection