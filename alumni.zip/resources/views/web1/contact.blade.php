@extends('layouts.web')

@section('title', 'Contact')

@section('sidebar')
    @parent

    <section class="breadcrumb-section">
        <div class="container">
            <h1>Nous contacter</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('Index')}}">Accueil</a></li>
                <li class="breadcrumb-item">Contact</li>
            </ol>
        </div><!-- /.container -->
    </section> 
    <div class="contact-section section-padding_ py-5">
        <div class="container">
            <div class="address-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="mb-2">
                            <div class="address">
                                <iframe class="embed-responsive img-fuid" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2109.654690650017!2d2.6364840141342367!3d9.354953976451261!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x10321aa0586a3fd1%3A0x86ca99d3f6986c56!2sCentre%20Don%20Bosco!5e0!3m2!1sfr!2sbj!4v1645914789052!5m2!1sfr!2sbj" width="100%"  height="350" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                            </div> 
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="address">
                            <div class="icon">
                                <i class="fas fa-map-signs"></i>
                            </div>
                            <div class="text">
                                <h3>Localisation</h3>
                                <p><b>Parakou :</b> Quartier Tranza</p>
                            </div>                                    
                        </div>
                        <div class="address">
                            <div class="icon">
                                <i class="fas fa-envelope-open"></i>
                            </div>
                            <div class="text">
                                <h3>Email address</h3>
                                <a href="mailto:adafo.bj@adafo-sdb.org"> adafo.bj@adafo-sdb.org</a> |
                                <a href="mailto:parakou@cfpsdonboscobenin.com">parakou@cfpsdonboscobenin.com</a>
                           </div>
                        </div> 
                        
                    </div>
                    <div class="col-md-8">

                        
                        {!! Form::open(['url' => '/contact', 'class' => 'contact-form','id'=>'contactform', 'files' => true]) !!}
                        <h4 class="mb-5">Envoyez nous un message</h4>

                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group mb-4">
                                        <input type="text" class="form-control" name="nom" required="" placeholder="Votre nom et prénoms">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group mb-4">
                                        <input type="email" class="form-control " name="email" required="" placeholder="Votre adresse électronique (Email)">
                                    </div>
                                </div>
                            </div><!-- /.row -->
                            <div class="form-group mb-4">
                                <input type="text" class="form-control" name="objet" required="" placeholder="Objet du message">
                            </div>
                            <div class="form-group mb-4">
                                <textarea class="form-control" name="message" required="" placeholder="Contenu de votre message"></textarea>
                            </div>
                            <div class="form-group mb-4">
                                <div class="flashinfo"></div>
                                <button class="btn btn-primary btn-l" name="submit" type="submit">Envoyer</button>
                            </div>
                        </form>  
                    </div>
                </div>
            </div>                    
                               
        </div>
    </div>
    
@endsection

@section('content')

@endsection