@extends('layouts.web')

@section('title', 'Membres administratifs du CPET DON BOSCO '.config('app.site'))

@section('sidebar')
    @parent

    <section class="breadcrumb-section">
        <div class="container">
            <h1>Membres administratifs</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('Index')}}">Accueil</a></li>
                <li class="breadcrumb-item">Membres de l'administrations</li>
            </ol>
        </div><!-- /.container -->
    </section> 
    
@endsection

@section('content')
<div class="sg-page-content">         
    <div class="sa-section">
        <div class="section-content section-padding_ py-5 mt-2">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="row">
                            @if(isset($datas))
                                @foreach($datas as $key => $d) 
                                <div class="col-md-4 mb-4">
                                    <div class=" border_  rounded-3 shadow-sm border mb-2 ">
                                        <div class="col-12 col-sm-12">
                                            <div class="sa-courses card_membre ">                             
                                                <div class="entry-thumbnail p-2">
                                                    <a href="{{ route('membre',$d['id']) }}"> 
                                                        @if($d['photo'] && $d['photo']!="")
                                                        <img src="{{ asset($d['photo']) }}" alt="{{ $d['titre'] }}" class="img-fluid rounded-3 shadow-sm img-avatar img-fluid-100">
                                                        @else
                                                        <img src="{{ asset('assets/images/cpet/actualite-default.jpg') }}" alt="{{ $d['titre'] }}" class="img-fluid ">
                                                        @endif
                                                        </a>
                                                </div>
                                                <div class="course-info_ px-2 py-3">
                                                    <div class="info text-center">
                                                        
                                                        <h5 class="title fs-sm mt-0 mb-0"><a href="{{ route('membre',($d->slug!="")?$d->slug:$d->id) }}">{{ $d->nom.' '.$d->prenom }}</a></h5>
                                                        <small><b>Poste:</b> {{ $d->poste }}</small>
                                                       <small class="text-muted">
                                                           {{ substr(strip_tags($d->contenu),0,100) }}
                                                       </small>
                                                    </div>
                                                </div><!-- /.course-info -->
                                            </div><!-- /.sg-course -->                                      
                                        </div>
                                    </div>
                                    </div>                               
                                   
                                @endforeach
                                @endif
                                
                            </div><!-- /.row --> 

                            <div class="sg-pagination float-end  px-1 ">
                                {{ $datas->links() }}
                            </div>                                                                 
                    </div>
                    <div class="col-lg-4">
                        @include('includes.right')
                    </div>
                </div><!-- /.row -->                     
            </div><!-- /.container -->
        </div><!-- /.section-content -->
    </div><!-- /.sa-section -->
</div>
@endsection