@extends('layouts.web')

@section('title', 'Les enseignants du CPET DON BOSCO '.config('app.site'))

@section('sidebar')
    @parent

    <section class="breadcrumb-section">
        <div class="container">
            <h1>Nos enseignants</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('Index')}}">Accueil</a></li>
                <li class="breadcrumb-item">Nos enseignants</li>
            </ol>
        </div><!-- /.container -->
    </section> 
    
@endsection

@section('content')
<div class="sg-page-content">         
    <div class="sa-section">
        <div class="section-content section-padding_ py-5 mt-2">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="row">
                            @if(isset($datas))
                                @foreach($datas as $key => $d) 
                                <div class="col-md-4 p-1 mb-3">
                                    <div class="row border mx-1 rounded-3 shadow-sm mb-2">
                                        <div class="col-12 col-sm-12 px-0">
                                            <div class="sa-courses card_membre ">                             
                                                <div class="entry-thumbnail px-0">
                                                    <a href="{{ route('enseignant',$d['id']) }}"> 
                                                        @if($d['photo'] && $d['photo']!="")
                                                        <img src="{{ asset($d['photo']) }}" alt="{{ $d['titre'] }}" class="img-fluid ">
                                                        @else
                                                        <img src="{{ asset('assets/images/cpet/actualite-default.jpg') }}" alt="{{ $d['titre'] }}" class="img-fluid">
                                                        @endif
                                                        </a>
                                                </div>
                                                <div class="course-info_ px-2 py-3">
                                                    <a href="{{ route('enseignant',$d['id']) }}">
                                                    <div class="info text-center">
                                                        @isset($d->site)                                                
                                                        <span class="badgebg-secondary rounded-pill fs-xs fw-semibold text-lowercase">SITE DE {{ $d->site}}</span>   <br-->
                                                        @endisset
                                                        <h5 class="title fs-sm mt-0 mb-0"><a href="{{ route('enseignant',($d->slug!="")?$d->slug:$d->id) }}">{{ $d->nom.' '.$d->prenom }}</a></h5>
                                                        <small><b>Spécialité:</b> {{ $d->specialite }}</small>
                                                       <small class="text-muted">
                                                           {{ substr(strip_tags($d->contenu),0,100) }}
                                                       </small>
                                                    </div>
                                                    </a>
                                                </div><!-- /.course-info -->
                                            </div><!-- /.sg-course -->                                      
                                        </div>
                                    </div>
                                    </div>                               
                                   
                                @endforeach
                                @endif
                                
                            </div><!-- /.row --> 

                            <div class="sg-pagination float-end  px-1 ">
                                {{ $datas->links() }}
                            </div>                                                                  
                    </div>
                    <div class="col-lg-4">
                        @include('includes.right')
                    </div>
                </div><!-- /.row -->                     
            </div><!-- /.container -->
        </div><!-- /.section-content -->
    </div><!-- /.sa-section -->
</div>
@endsection