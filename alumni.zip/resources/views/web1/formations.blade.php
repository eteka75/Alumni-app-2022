@extends('layouts.web')

@section('title', 'Nos Formations au CPET DON BOSCO '.config('app.site'))

@section('sidebar')
    @parent

    <section class="breadcrumb-section">
        <div class="container">
            <h1>Nos Formations</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('Index')}}">Accueil</a></li>
                <li class="breadcrumb-item">Nos formations</li>
            </ol>
        </div><!-- /.container -->
    </section>    
    
    @section('content')
    <div class="sg-section">
        <div class="section-content course-details bg-white section-padding_ py-4">
            <div class="container">
                <div class="row p-0">
                <div class="col-md-8 col-sm-12 col-12 col-xl-8">
                    @foreach($datas as $key => $d)
                    <div class="row border mx-1 shadow-sm mb-2">
                        <div class="col-12 col-sm-4 col-md-3 p-0">
                            <div class="course-thumb">
                                
                                <a href="{{ route('formation',$d->id) }}"> 
                                    @if($d->image && $d->image!="")
                                    <img src="{{ asset($d->image) }}" alt="{{$d->titre }}" class="img-fluid">
                                    @else
                                    <img src="{{ asset('assets/images/cpet/actualite-default.jpg') }}" alt="{{$d->titre }}" class="img-fluid">
                                    @endif
                                    </a>
                            </div><!-- /.course-thumb -->
                        </div>
                        <div class="col-12 col-sm-8 col-md-9">
                            <div class="sa-courses">                             

                                <div class="course-info_ px-2 py-3">
                                    <div class="info">
                                        
                                        <h5 class="title fs-sm mt-1 mb-0"><a href="{{ route('formation',($d->slug!="")?$d->slug:$d->id) }}">{{ $d->titre }}</a></h5>
                                        <div><small class="text-success">{{ $d->created_at->diffForHumans() }}</small></div>
                                        <h2 class="entry-title_ h6 text-muted fw-normal fs-xs"><a href="{{ route('formation',($d->slug!="")?$d->slug:$d->id) }}">{!!  isset($d->description)? substr(strip_tags($d->description),0,300):'' !!}... </a></h2>
                                        <a class="read-more text-primary"  href="{{ route('formation',($d->slug!="")?$d->slug:$d->id) }}">En savoir plus <span class="fa fa-arrow-right"></span></a>
                                       
                                    </div>
                                </div><!-- /.course-info -->
                            </div><!-- /.sg-course -->                                      
                        </div>
                    </div>
                        @endforeach
                        <div class="sg-pagination float-end  px-1 ">
                            {{ $datas->links() }}
                        </div>  
                </div>
                <div class="col-lg-4 col-sm-12 col-12 col-xl-4">
                    
                    @include('includes.right')
                 </div>
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.section-content -->
    </div>
    @endsection
    
@endsection

@section('content')

@endsection