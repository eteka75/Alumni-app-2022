@extends('layouts.web')

@section('title', 'Communiqués au CPET DON BOSCO '.config('app.site'))

@section('sidebar')
    @parent

    <section class="breadcrumb-section">
        <div class="container">
            <h1>Communiqués</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('Index')}}">Accueil</a></li>
                <li class="breadcrumb-item">Communiqués</li>
            </ol>
        </div><!-- /.container -->
    </section> 
    
@endsection

@section('content')
<div class="sg-page-content">         
    <div class="sa-section">
        <div class="section-content section-padding_ py-5 mt-2">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="row">
                            @if(isset($datas))
                                @foreach($datas as $key => $d) 
                                <div class="col-md-6 px-1">
                                    <div class="row border mx-1 rounded-3 shadow-sm mb-2">
                                        <div class="col-12 col-sm-12">
                                            <div class="sa-courses">                             
                
                                                <div class="course-info_ px-2 py-3">
                                                    <div class="info">
                                                       
                                                        <h5 class="title fs-sm mt-0"><a href="{{ route('communique',($d->slug!="")?$d->slug:$d->id) }}">{{ $d->titre }}</a></h5>
                                                       <small class="text-muted">
                                                           {{ substr(strip_tags($d->contenu),0,100) }}
                                                       </small>
                                                    </div>
                                                </div><!-- /.course-info -->
                                            </div><!-- /.sg-course -->                                      
                                        </div>
                                    </div>
                                    </div>                               
                                   
                                @endforeach
                                @endif
                                
                            </div><!-- /.row --> 

                            <div class="sg-pagination float-end  px-1 ">
                                {{ $datas->links() }}
                            </div>                                                                 
                    </div>
                    <div class="col-lg-4">
                        @include('includes.right')
                    </div>
                </div><!-- /.row -->                     
            </div><!-- /.container -->
        </div><!-- /.section-content -->
    </div><!-- /.sa-section -->
</div>
@endsection