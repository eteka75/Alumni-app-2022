@extends('layouts.web')

@section('title', 'Fichiers à télécharger')

@section('sidebar')
    @parent

    <section class="breadcrumb-section">
        <div class="container">
            <h1>Fichiers à téléchargeables</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('Index')}}">Accueil</a></li>
                <li class="breadcrumb-item">Fichiers à téléchargeables</li>
            </ol>
        </div><!-- /.container -->
    </section>    
    
    @section('content')
    <div class="sg-section">
        <div class="section-content course-details bg-white section-padding_ py-4">
            <div class="container">
                <div class="row p-3">
                <div class="col-md-8 col-12 col-xl-8">
                    @foreach($datas as $key => $d)
                    <div class="row border_ mx-1 shadow-sm border rounded-2 mb-4">
                        <div class="col-12 col-sm-4 col-md-3 p-0">
                            <div class="course-thumb">
                                
                                <a href="{{ route('fichier',$d->id) }}"> 
                                    @if($d->image && $d->image!="")
                                    <img src="{{ asset($d->image) }}" alt="{{$d->titre }}" class="img-fluid">
                                    @else
                                    <img src="{{ asset('assets/images/cpet/doc.jpg') }}" alt="{{$d->titre }}" class="p-1 px-3 img-fluid">
                                    @endif
                                    </a>
                            </div><!-- /.course-thumb -->
                        </div>
                        <div class="col-12 col-sm-8 col-md-9">
                            <div class="sa-courses">                             

                                <div class="course-info_ px-2 py-3">
                                    <div class="info">
                                        <div><a href="{{ url($d->fichier) }}" class="btn btn-primary btn-xs py-1 mt2 float-end" target="_blanck"><i class="fa fa-file-download"></i> Télécharger</a></div>
                                        @isset($d->site)                                                
                                        <span class="badge bg-secondary rounded-pill">{{ $d->format}}</span>   <br>
                                        @endisset
                                        <h5 class="title fs-sm my-1"><a href="{{ route('fichier',($d->slug!="")?$d->slug:$d->id) }}">{{ $d->titre }}</a></h5>
                                        <h2 class="entry-title_ h6 text-muted fw-normal fs-xs"><a href="{{ route('fichier',($d->slug!="")?$d->slug:$d->id) }}">{!!  isset($d->description)? substr(strip_tags($d->description),0,300):'' !!}... </a></h2>
                                    </div>
                                </div><!-- /.course-info -->
                            </div><!-- /.sg-course -->                                      
                        </div>
                    </div>
                        @endforeach
                       <br>
                        {{ $datas->links() }}
                </div>
                <div class="col-lg-4">
                    
                    @include('includes.right')
                 </div>
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.section-content -->
    </div>
    @endsection
    
@endsection

@section('content')

@endsection